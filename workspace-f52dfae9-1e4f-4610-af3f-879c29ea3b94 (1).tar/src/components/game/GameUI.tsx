"use client";

// HUD + seluruh panel UI game. Semua data dari state singleton (bukan React state).
import { useCallback, useEffect, useMemo, useRef, useState, useSyncExternalStore } from "react";
import { subscribe, getSnapshot, state as gamestate, rupiah, timeStr, dayName, weatherName, seasonName, seasonIcon } from "@/game/core/state";
import { bus, EV } from "@/game/core/bus";
import { ITEMS, SHOPS, item } from "@/game/data/items";
import { NPCS } from "@/game/data/npcs";
import { QUESTS, questById } from "@/game/data/quests";
import { JOBS } from "@/game/data/jobs";
import { STAGES, stageOf, INV_SLOTS, DATE_OPTIONS, ROMANCE } from "@/game/core/constants";
import { useItem as consumeItem, moveSlot, dropSlot, countItem } from "@/game/systems/inventory";
import { chatWith, giveGift, helpNpc, inviteTogether, rel, confess, goOnDate, breakUp, canConfess, pacarOf } from "@/game/systems/social";
import { activateQuest, questReady, objectiveDone, turnInQuestsFor } from "@/game/systems/quests";
import { finishShift, paketCount } from "@/game/systems/jobs";
import { achievementProgress } from "@/game/systems/achievements";
import { spendMoney, earnMoney, applyNeeds, pushPhone, toast } from "@/game/systems/systems";
import { MAP_W, MAP_H, OUT_GRID, BUILDINGS } from "@/game/data/mapdata";
import { joyVector, knobOffset } from "@/game/core/joy";
import { useIsTouch, useMediaQuery } from "@/hooks/use-touch";
import type { GameState, InvSlot } from "@/game/core/types";

type Panel = null | "inventory" | "phone" | "journal" | "map" | "menu" | "shop" | "dialog" | "settings" | "warung" | "minimarket" | "wardrobe" | "sleep";

function useGame(): GameState {
  return useSyncExternalStore(subscribe, getSnapshot);
}

// Modul start (berisi Phaser) dimuat dinamis agar tak masuk bundle UI awal;
// promise di-cache agar setiap event pointer tidak memuat ulang modul.
let startModP: Promise<typeof import("@/game/start")> | null = null;
const startMod = () => (startModP ??= import("@/game/start"));

function toggleFullscreen() {
  try {
    if (document.fullscreenElement) void document.exitFullscreen();
    else void document.documentElement.requestFullscreen?.();
  } catch { /* tidak didukung (mis. iOS Safari) — abaikan */ }
}

const NEED_META = [
  { key: "lapar", label: "Lapar", color: "#e0b080" },
  { key: "energi", label: "Energi", color: "#8fd4c8" },
  { key: "kebersihan", label: "Bersih", color: "#a8c8d8" },
  { key: "mood", label: "Mood", color: "#d9a0ac" },
] as const;

// ---------- Geometri canvas ----------
// Semua elemen HUD & gamepad menempel DI ATAS layar game (canvas Phaser),
// bukan sudut layar browser — persis gaya eFootball Mobile saat ada letterbox.
type CanvasRect = { left: number; top: number; right: number; bottom: number; width: number; height: number; vw: number; vh: number };

function measureCanvas(): CanvasRect | null {
  if (typeof document === "undefined" || typeof window === "undefined") return null;
  const cv = document.querySelector<HTMLElement>("#game-root canvas");
  if (!cv) return null;
  const r = cv.getBoundingClientRect();
  if (r.width < 4 || r.height < 4) return null;
  return { left: r.left, top: r.top, right: r.right, bottom: r.bottom, width: r.width, height: r.height, vw: window.innerWidth, vh: window.innerHeight };
}

function viewportRect(): CanvasRect {
  const vw = typeof window !== "undefined" ? window.innerWidth : 1280;
  const vh = typeof window !== "undefined" ? window.innerHeight : 720;
  return { left: 0, top: 0, right: vw, bottom: vh, width: vw, height: vh, vw, vh };
}

function useCanvasRect(): CanvasRect {
  const [rect, setRect] = useState<CanvasRect | null>(null);
  useEffect(() => {
    let alive = true;
    const apply = () => {
      if (!alive) return;
      const m = measureCanvas();
      if (!m) return;
      setRect((prev) => (prev && prev.left === m.left && prev.top === m.top && prev.width === m.width && prev.height === m.height && prev.vw === m.vw && prev.vh === m.vh ? prev : m));
    };
    const raf = requestAnimationFrame(apply);
    const t1 = setTimeout(apply, 250);
    const t2 = setTimeout(apply, 800); // setelah scale.refresh() awal Phaser
    const ro = new ResizeObserver(apply);
    const root = document.getElementById("game-root");
    if (root) ro.observe(root);
    const cv = document.querySelector<HTMLElement>("#game-root canvas");
    if (cv) ro.observe(cv);
    window.addEventListener("resize", apply);
    window.addEventListener("orientationchange", apply);
    document.addEventListener("fullscreenchange", apply);
    return () => {
      alive = false;
      cancelAnimationFrame(raf);
      clearTimeout(t1);
      clearTimeout(t2);
      ro.disconnect();
      window.removeEventListener("resize", apply);
      window.removeEventListener("orientationchange", apply);
      document.removeEventListener("fullscreenchange", apply);
    };
  }, []);
  return rect ?? viewportRect();
}

// ---------- Ikon HUD (SVG inline — tampilan game, bukan huruf) ----------
const HUD_ICONS = {
  inventory: ["M5 9a3 3 0 0 1 3-3h8a3 3 0 0 1 3 3v9a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2z", "M9 6V5a3 3 0 0 1 6 0v1", "M9 13h6"],
  journal: ["M4 19.5V5a2 2 0 0 1 2-2h14v16H6.5A2.5 2.5 0 0 0 4 21.5z", "M8 7h8"],
  map: ["M9 4 3 6.5v14L9 18l6 3 6-2.5v-14L15 7z", "M9 4v14", "M15 7v14"],
  phone: ["M7 3h10a1 1 0 0 1 1 1v16a1 1 0 0 1-1 1H7a1 1 0 0 1-1-1V4a1 1 0 0 1 1-1z", "M11 18h2"],
  expand: ["M8 3H5a2 2 0 0 0-2 2v3", "M16 3h3a2 2 0 0 1 2 2v3", "M3 16v3a2 2 0 0 0 2 2h3", "M21 16v3a2 2 0 0 1-2 2h-3"],
  menu: ["M4 6h16", "M4 12h16", "M4 18h16"],
} as const;
type HudIconName = keyof typeof HUD_ICONS;

function HudIconSvg({ name }: { name: HudIconName }) {
  return (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2} strokeLinecap="round" strokeLinejoin="round" className="w-[17px] h-[17px]" aria-hidden="true">
      {HUD_ICONS[name].map((d, i) => (
        <path key={i} d={d} />
      ))}
    </svg>
  );
}

function CoinIcon() {
  return (
    <svg viewBox="0 0 24 24" className="w-4 h-4 shrink-0" aria-hidden="true">
      <circle cx="12" cy="12" r="9" fill="#d9c4a0" />
      <circle cx="12" cy="12" r="5.2" fill="none" stroke="#8a6d3f" strokeWidth="1.8" />
      <path d="M12 6.8v10.4" stroke="#8a6d3f" strokeWidth="1.4" strokeLinecap="round" />
    </svg>
  );
}

export function GameUI() {
  const s = useGame();
  const touch = useIsTouch();
  const portrait = useMediaQuery("(orientation: portrait)");
  const [panel, setPanel] = useState<Panel>(null);
  const [hint, setHint] = useState<string | null>(null);
  const [toasts, setToasts] = useState<{ id: number; text: string; kind: string }[]>([]);
  const [, forceTick] = useState(0);
  const [rotDismissed, setRotDismissed] = useState(false);

  const R = useCanvasRect();
  const gate = touch && portrait && !rotDismissed; // gerbang lanskap gaya eFootball

  // pause scene saat panel terbuka / gerbang lanskap tampil
  useEffect(() => {
    (async () => {
      const { setPaused } = await import("@/game/start");
      setPaused(panel !== null || gate);
    })();
  }, [panel, gate]);

  useEffect(() => {
    const offHint = bus.on(EV.INTERACT_HINT, (h) => setHint((h as string | null) ?? null));
    const offToast = bus.on(EV.TOAST, (p) => {
      const { text, kind } = p as { text: string; kind: string };
      const id = Date.now() + Math.random();
      setToasts((t) => [...t.slice(-3), { id, text, kind: kind ?? "info" }]);
      setTimeout(() => setToasts((t) => t.filter((x) => x.id !== id)), 3200);
    });
    const offShop = bus.on(EV.SHOP_OPEN, (p) => {
      lastShop = (p as { shopId: string }) ?? { shopId: "warung" };
      setPanel("shop");
    });
    const offDialog = bus.on("npc_talk", (p) => {
      lastTalkNpc = (p as { npcId: string })?.npcId ?? "mas_tony";
      setPanel("dialog");
    });
    const offWardrobe = bus.on(EV.WARDROBE_OPEN, () => setPanel("wardrobe"));
    const offSleepAsk = bus.on("ask_sleep", () => setPanel("sleep"));
    const offWarung = bus.on(EV.JOB_MINIGAME, (p) => {
      const jobId = (p as { jobId: string }).jobId;
      setPanel(jobId === "warung" ? "warung" : jobId === "minimarket" ? "minimarket" : null);
    });
    const offSlept = bus.on("slept", () => setPanel(null));
    const clock = setInterval(() => forceTick((n) => n + 1), 1000);
    // keyboard UI
    const kd = (e: KeyboardEvent) => {
      if (e.repeat) return;
      const k = e.key.toLowerCase();
      if (k === "escape") {
        e.preventDefault();
        setPanel((p) => (p ? null : "menu"));
      } else if (k === "i") setPanel((p) => (p === "inventory" ? null : "inventory"));
      else if (k === "j") setPanel((p) => (p === "journal" ? null : "journal"));
      else if (k === "m") setPanel((p) => (p === "map" ? null : "map"));
      else if (k === "p") setPanel((p) => (p === "phone" ? null : "phone"));
    };
    window.addEventListener("keydown", kd);
    return () => {
      offHint(); offToast(); offShop(); offDialog(); offWardrobe(); offSleepAsk(); offWarung(); offSlept();
      clearInterval(clock);
      window.removeEventListener("keydown", kd);
    };
  }, []);

  const shiftChip = useMemo(() => {
    if (!s.shift) return null;
    if (s.shift.jobId === "kurir") return `SHIFT KURIR • paket: ${paketCount()}`;
    return `SHIFT ${JOBS[s.shift.jobId].name.toUpperCase()} BERLANGSUNG`;
  }, [s.shift, s]);

  return (
    <div className="absolute inset-0 pointer-events-none select-none" style={{ fontFamily: "var(--font-geist-sans)" }}>
      {/* ===== HUD kiri-atas — menempel di sudut LAYAR GAME (canvas) ===== */}
      <div className="absolute flex flex-col items-start" style={{ left: R.left + 8, top: R.top + 8 }}>
        <div style={{ marginTop: "env(safe-area-inset-top)", marginLeft: "env(safe-area-inset-left)" }}>
          <div className="kk-hud rounded-2xl px-3 py-2 leading-tight pointer-events-none min-w-[10.75rem]">
            <div className="flex items-baseline gap-2">
              <span className="font-black text-sage text-[15px] tracking-wide tabular-nums">{timeStr(s.timeMin)}</span>
              <span className="text-white/75 font-semibold text-[10.5px]">{dayName(s.day)}, Hari {s.day}</span>
            </div>
            <div className="mt-1.5 flex items-center gap-1.5">
              <span className="px-1.5 py-0.5 rounded-md bg-white/10 font-bold text-white/85 text-[10px]">{seasonIcon(s.season)} {seasonName(s.season)}</span>
              <span className="px-1.5 py-0.5 rounded-md bg-white/10 font-bold text-white/85 text-[10px]">{weatherName(s.weather)}</span>
            </div>
            <p className="mt-1 text-[8.5px] uppercase tracking-[0.22em] text-white/40">{s.scene?.map === "outdoor" || !s.scene ? "Arunika Tengah" : s.scene.map}</p>
            {touch && portrait && <LowestNeed />}
            {shiftChip && <p className="mt-1.5 text-sand-deep font-black text-[9.5px] uppercase tracking-[0.12em]">{shiftChip}</p>}
          </div>
          {touch && !portrait && <NeedBars compact className="mt-1.5 w-40" />}
        </div>
      </div>

      {/* ===== HUD kanan-atas — dompet + tombol ikon, menempel di layar game ===== */}
      <div className="absolute flex flex-col items-end" style={{ right: R.vw - R.right + 8, top: R.top + 8 }}>
        <div className="flex flex-col items-end gap-1.5" style={{ marginTop: "env(safe-area-inset-top)", marginRight: "env(safe-area-inset-right)" }}>
          <div className="kk-hud rounded-full pl-2.5 pr-3 py-1.5 flex items-center gap-1.5 pointer-events-none">
            <CoinIcon />
            <span className="text-[13px] font-black text-[#F0DFAE] tabular-nums">{rupiah(s.money)}</span>
          </div>
          <div className={`${touch && portrait ? "grid grid-cols-3 gap-1.5 justify-items-end" : "flex gap-1.5"} pointer-events-auto`}>
            <HudBtn icon="inventory" label="I" title="Inventory" big={touch && !portrait} onClick={() => setPanel((p) => (p === "inventory" ? null : "inventory"))} />
            <HudBtn icon="journal" label="J" title="Jurnal Misi" big={touch && !portrait} onClick={() => setPanel((p) => (p === "journal" ? null : "journal"))} />
            <HudBtn icon="map" label="M" title="Peta" big={touch && !portrait} onClick={() => setPanel((p) => (p === "map" ? null : "map"))} />
            <HudBtn icon="phone" label="P" title="Ponsel" big={touch && !portrait} onClick={() => setPanel((p) => (p === "phone" ? null : "phone"))} />
            <HudBtn icon="expand" label="⛶" title="Layar Penuh" big={touch && !portrait} onClick={toggleFullscreen} />
            <HudBtn icon="menu" label="≡" title="Menu (Esc)" big={touch && !portrait} onClick={() => setPanel("menu")} />
          </div>
          {!(touch && portrait) && (
            <a href="#/store" className="pointer-events-auto px-2.5 py-1 rounded-full bg-rosekk/85 text-[#12141A] text-[9px] font-black uppercase tracking-[0.14em] hover:brightness-110 active:scale-95 transition">
              + Top Up Gems
            </a>
          )}
        </div>
      </div>

      {/* Kebutuhan — desktop: kiri-bawah di atas layar game */}
      {!touch && <NeedBars className="absolute w-48" style={{ left: R.left + 10, bottom: R.vh - R.bottom + 10 }} />}

      {/* Hint interaksi — desktop: pil bergaya game dengan badge tombol */}
      {hint && !touch && (
        <div className="absolute" style={{ left: R.left + R.width / 2, bottom: R.vh - R.bottom + 58, transform: "translateX(-50%)" }}>
          <div className="kk-hud rounded-xl pl-1.5 pr-3.5 py-1.5 flex items-center gap-2 pointer-events-none whitespace-nowrap">
            <span className="w-6 h-6 rounded-lg bg-sage text-[#12141A] grid place-items-center text-[11px] font-black shadow-[0_0_14px_-2px_rgba(169,194,162,0.7)]">E</span>
            <span className="text-[13px] font-bold text-white/90">{hint}</span>
          </div>
        </div>
      )}

      {/* Toasts — notifikasi gaya game di tengah atas layar game */}
      <div className="absolute space-y-1.5 w-80 max-w-[80vw] pointer-events-none" style={{ left: R.left + R.width / 2, top: R.top + 10, transform: "translateX(-50%)" }}>
        {toasts.map((t) => (
          <div key={t.id} className={`kk-toast kk-hud rounded-xl pl-2.5 pr-3 py-2 text-xs font-semibold flex items-center gap-2 justify-center ${t.kind === "sukses" ? "text-emerald-200" : t.kind === "peringatan" ? "text-orange-200" : "text-white/85"}`}>
            <span className="w-1.5 h-1.5 rounded-full shrink-0" style={{ background: t.kind === "sukses" ? "#7cc9a3" : t.kind === "peringatan" ? "#e0a060" : "#a9c2a2" }} />
            {t.text}
          </div>
        ))}
      </div>

      {/* ===== Gamepad sentuh gaya eFootball — overlay di atas canvas ===== */}
      {touch && panel === null && !gate && <TouchControls hint={hint} rect={R} compact={portrait} />}

      {/* Panel */}
      {panel && (
        <div className="absolute inset-0 bg-black/55 backdrop-blur-[2px] pointer-events-auto flex items-center justify-center p-3" style={{ padding: "calc(0.75rem + env(safe-area-inset-top)) calc(0.75rem + env(safe-area-inset-right)) calc(0.75rem + env(safe-area-inset-bottom)) calc(0.75rem + env(safe-area-inset-left))" }} onClick={() => setPanel(null)}>
          <div className="kk-pop w-full max-w-lg max-h-full overflow-y-auto kk-scroll kk-game-window text-white" onClick={(e) => e.stopPropagation()}>
            {panel === "inventory" && <InventoryPanel close={() => setPanel(null)} />}
            {panel === "phone" && <PhonePanel close={() => setPanel(null)} />}
            {panel === "journal" && <JournalPanel close={() => setPanel(null)} />}
            {panel === "map" && <MapPanel close={() => setPanel(null)} />}
            {panel === "menu" && <PauseMenu close={() => setPanel(null)} />}
            {panel === "shop" && <ShopPanel close={() => setPanel(null)} />}
            {panel === "dialog" && <DialogPanel close={() => setPanel(null)} />}
            {panel === "settings" && <SettingsPanel close={() => setPanel(null)} />}
            {panel === "wardrobe" && <WardrobePanel close={() => setPanel(null)} />}
            {panel === "sleep" && <SleepPanel close={() => setPanel(null)} />}
            {panel === "warung" && <WarungGame close={() => setPanel(null)} />}
            {panel === "minimarket" && <MinimarketGame close={() => setPanel(null)} />}
          </div>
        </div>
      )}

      {/* Gerbang lanskap gaya eFootball — fullscreen saat HP portrait */}
      {gate && <LandscapeGate onSkip={() => setRotDismissed(true)} />}
    </div>
  );
}

// payload toko terakhir (diset sebelum panel dibuka)
let lastShop: { shopId: string } = { shopId: "warung" };
// NPC terakhir yang diajak bicara (dibaca DialogPanel saat mount — event npc_talk
// dipancarkan sebelum panel ter-mount, sehingga listener di dalam panel tak sempat mendaftar)
let lastTalkNpc = "mas_tony";

function HudBtn({ icon, label, title, onClick, big }: { icon: HudIconName; label: string; title: string; onClick: () => void; big?: boolean }) {
  return (
    <button title={title} aria-label={title} onClick={onClick}
      className={`kk-icon-btn relative ${big ? "w-11 h-11" : "w-9 h-9"} text-white/85`}>
      <HudIconSvg name={icon} />
      {!big && (
        <span className="absolute -bottom-1 -right-1 px-1 rounded-md bg-black/85 border border-white/20 text-[8px] font-black text-white/70 leading-[1.25]">{label}</span>
      )}
    </button>
  );
}

// Bar kebutuhan (lapar/energi/bersih/mood) — gaya game: label mikro + bar bercahaya lembut.
function NeedBars({ className, compact, horizontal, style }: { className?: string; compact?: boolean; horizontal?: boolean; style?: React.CSSProperties }) {
  const s = useGame();
  return (
    <div className={`kk-hud rounded-2xl px-3 py-2 pointer-events-none ${className ?? ""}`} style={style}>
      <div className={horizontal ? "grid grid-cols-4 gap-2.5" : ""}>
        {NEED_META.map((n) => (
          <div key={n.key} className={compact && !horizontal ? "mb-1.5 last:mb-0" : horizontal ? "" : "mb-1.5 last:mb-0"}>
            <div className="flex justify-between items-baseline">
              <span className="text-[8px] uppercase tracking-[0.18em] text-white/55 font-black">{n.label}</span>
              {!compact && <span className="text-[9px] text-white/40 tabular-nums">{Math.round(s.needs[n.key])}%</span>}
            </div>
            <div className={`mt-0.5 h-1.5 rounded-full bg-black/50 overflow-hidden border border-white/5 ${horizontal ? "w-full" : ""}`}>
              <div
                className="h-full rounded-full transition-all"
                style={{ width: `${s.needs[n.key]}%`, background: `linear-gradient(90deg, ${n.color}88, ${n.color})`, boxShadow: `0 0 8px ${n.color}55` }}
              />
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

// Kebutuhan terendah — baris hemat tempat untuk mode portrait
function LowestNeed() {
  const s = useGame();
  const lowest = NEED_META.reduce((a, b) => (s.needs[b.key] < s.needs[a.key] ? b : a));
  const v = Math.round(s.needs[lowest.key]);
  return (
    <p className="mt-1.5 flex items-center gap-1.5 text-[10px] font-bold text-white/80">
      <span className="w-1.5 h-1.5 rounded-full shrink-0" style={{ background: lowest.color, boxShadow: `0 0 6px ${lowest.color}` }} />
      {lowest.label}
      <span className="text-white/50 tabular-nums">{v}%</span>
    </p>
  );
}

// ---------- Kontrol sentuh gaya eFootball: overlay DI ATAS canvas, menempel ke tepi layar game ----------
function TouchControls({ hint, rect, compact }: { hint: string | null; rect: CanvasRect; compact: boolean }) {
  const baseRef = useRef<HTMLDivElement>(null);
  const knobRef = useRef<HTMLDivElement>(null);
  const joyId = useRef<number | null>(null);
  const [runHeld, setRunHeld] = useState(false);
  const [joyOn, setJoyOn] = useState(false);

  // Pastikan lari/gerak berhenti saat gamepad hilang (panel terbuka, keluar scene, dsb.)
  useEffect(() => {
    return () => {
      startMod().then((m) => {
        m.setJoy(0, 0);
        m.setRun(false);
      });
    };
  }, []);

  // Ukuran eFootball-style: besar & nyaman di lanskap, ramping di portrait
  const JOY = compact ? 100 : 148;
  const KNOB = compact ? 42 : 58;
  const E = compact ? 60 : 86;
  const RUN = compact ? 46 : 58;
  const M = compact ? 8 : 12;

  const letterboxBottom = rect.vh - rect.bottom; // jarak canvas → bawah layar
  const letterboxRight = rect.vw - rect.right;

  const setKnob = (dx: number, dy: number) => {
    if (knobRef.current) knobRef.current.style.transform = `translate(${dx}px, ${dy}px)`;
  };

  const joyMove = (e: React.PointerEvent) => {
    const el = baseRef.current;
    if (!el || joyId.current !== e.pointerId) return;
    const r = el.getBoundingClientRect();
    const cx = r.left + r.width / 2;
    const cy = r.top + r.height / 2;
    const radius = r.width / 2;
    const v = joyVector({ cx, cy, x: e.clientX, y: e.clientY, radius });
    const k = knobOffset({ cx, cy, x: e.clientX, y: e.clientY, radius });
    setKnob(k.x, k.y);
    startMod().then((m) => m.setJoy(v.x, v.y));
  };

  const joyStart = (e: React.PointerEvent) => {
    if (joyId.current !== null) return;
    joyId.current = e.pointerId;
    e.currentTarget.setPointerCapture(e.pointerId);
    setJoyOn(true);
    joyMove(e);
  };

  const joyEnd = (e: React.PointerEvent) => {
    if (joyId.current !== e.pointerId) return;
    joyId.current = null;
    setJoyOn(false);
    setKnob(0, 0);
    startMod().then((m) => m.setJoy(0, 0));
  };

  const runDown = (e: React.PointerEvent) => {
    e.preventDefault();
    setRunHeld(true);
    startMod().then((m) => m.setRun(true));
  };
  const runUp = () => {
    if (!runHeld) return;
    setRunHeld(false);
    startMod().then((m) => m.setRun(false));
  };

  return (
    <>
      {/* Joystick gerak analog — kiri-bawah layar game */}
      <div
        ref={baseRef}
        aria-label="Joystick gerak"
        className={`absolute rounded-full pointer-events-auto touch-none select-none kk-joy-base ${joyOn ? "ring-2 ring-sage/50" : ""}`}
        style={{
          width: JOY,
          height: JOY,
          left: rect.left + M,
          bottom: letterboxBottom + M,
          marginBottom: "env(safe-area-inset-bottom)",
          marginLeft: "env(safe-area-inset-left)",
        }}
        onPointerDown={joyStart}
        onPointerMove={joyMove}
        onPointerUp={joyEnd}
        onPointerCancel={joyEnd}
        onContextMenu={(e) => e.preventDefault()}
      >
        {/* tick arah halus ala eFootball */}
        {[0, 90, 180, 270].map((deg) => (
          <span
            key={deg}
            className="absolute left-1/2 top-1/2 w-1 h-1 rounded-full bg-white/25"
            style={{ transform: `translate(-50%,-50%) rotate(${deg}deg) translateY(-${JOY / 2 - 13}px)` }}
          />
        ))}
        <div
          ref={knobRef}
          className="absolute left-1/2 top-1/2 rounded-full kk-joy-knob will-change-transform"
          style={{ width: KNOB, height: KNOB, marginLeft: -KNOB / 2, marginTop: -KNOB / 2 }}
        />
      </div>

      {/* Tombol LARI — arc kiri-atas dari tombol aksi (posisi sprint eFootball) */}
      <button
        aria-label="Lari (tahan)"
        className={`absolute rounded-full kk-pad-btn pointer-events-auto touch-none select-none font-black tracking-widest ${runHeld ? "is-hot scale-95" : "text-white/75"}`}
        style={{
          width: RUN,
          height: RUN,
          fontSize: compact ? 9 : 10,
          left: rect.right - M - E - RUN + 6,
          bottom: letterboxBottom + M + E - RUN + 12,
          marginBottom: "env(safe-area-inset-bottom)",
        }}
        onPointerDown={runDown}
        onPointerUp={runUp}
        onPointerCancel={runUp}
        onPointerLeave={runUp}
        onContextMenu={(e) => e.preventDefault()}
      >
        LARI
      </button>

      {/* Tombol aksi utama — kanan-bawah layar game; menyala saat ada aksi terdekat */}
      <button
        aria-label="Aksi / interaksi"
        className={`absolute rounded-full kk-pad-btn pointer-events-auto touch-none select-none grid place-items-center ${hint ? "is-live" : "opacity-60"}`}
        style={{
          width: E,
          height: E,
          right: letterboxRight + M,
          bottom: letterboxBottom + M,
          marginRight: "env(safe-area-inset-right)",
          marginBottom: "env(safe-area-inset-bottom)",
        }}
        onPointerDown={() => bus.emit("interact_press")}
        onContextMenu={(e) => e.preventDefault()}
      >
        <span className={`font-black leading-none ${hint ? "text-sage" : "text-white/45"}`} style={{ fontSize: compact ? 24 : 32 }}>E</span>
      </button>

      {/* Label aksi terdekat — melayang di atas tombol E */}
      {hint && (
        <div
          className="absolute max-w-[46vw] text-right pointer-events-none"
          style={{ right: letterboxRight + M + 2, bottom: letterboxBottom + M + E + 14, marginRight: "env(safe-area-inset-right)" }}
        >
          <span className="kk-hud rounded-lg px-2 py-1 text-[11px] font-bold text-sage inline-block">{hint}</span>
        </div>
      )}
    </>
  );
}

// ---------- Gerbang lanskap (gaya eFootball): HP portrait → minta diputar ----------
function LandscapeGate({ onSkip }: { onSkip: () => void }) {
  return (
    <div
      className="absolute inset-0 z-50 pointer-events-auto flex flex-col items-center justify-center gap-7 px-8 text-center"
      style={{ background: "linear-gradient(180deg, #0B0E14 0%, #10141C 55%, #0B0E14 100%)" }}
    >
      <div className="kk-float">
        <div className="kk-rotate-phone relative w-14 h-24 rounded-[14px] border-2 border-white/25 bg-white/5 shadow-[0_0_44px_-8px_rgba(169,194,162,0.4)]">
          <span className="absolute left-1/2 -translate-x-1/2 top-1.5 w-6 h-1 rounded-full bg-white/25" />
          <span className="absolute inset-x-2 top-5 bottom-2 rounded-lg bg-gradient-to-b from-sage/25 to-sand/15" />
        </div>
      </div>
      <div>
        <p className="text-[10px] tracking-[0.4em] text-sage font-black">KOTA KITA · LIFE BEYOND</p>
        <h2 className="text-2xl font-black mt-2">Putar HP kamu</h2>
        <p className="text-white/55 text-[13px] mt-2 max-w-[17rem] leading-relaxed">
          Game ini dimainkan mode lanskap — joystick dan tombol aksi tampil menempel di atas layar game, seperti game console sungguhan.
        </p>
      </div>
      <button
        onClick={onSkip}
        className="px-5 py-2.5 rounded-xl bg-white/10 border border-white/15 text-[13px] font-bold hover:bg-white/15 active:scale-95 transition"
      >
        Tetap main di mode portrait
      </button>
    </div>
  );
}

// ---------- Panel: Inventory ----------
function InventoryPanel({ close }: { close: () => void }) {
  const s = useGame();
  const [sel, setSel] = useState<number | null>(null);
  const [moveFrom, setMoveFrom] = useState<number | null>(null);
  const slot = sel !== null ? s.inventory[sel] : null;
  const def = slot ? item(slot.itemId) : null;

  const action = (fn: () => boolean) => {
    if (!fn()) return;
    setSel(null);
  };

  return (
    <PanelShell title="Inventory" close={close}>
      <div className="grid grid-cols-6 gap-1.5 p-4">
        {Array.from({ length: INV_SLOTS }).map((_, i) => {
          const sl: InvSlot | null = s.inventory[i];
          return (
            <button
              key={i}
              onClick={() => {
                if (moveFrom !== null && moveFrom !== i) {
                  action(() => moveSlot(moveFrom, i));
                  setMoveFrom(null);
                  return;
                }
                setSel(i === sel ? null : i);
              }}
              className={`aspect-square rounded-lg border flex items-center justify-center relative transition ${i === sel ? "border-sage bg-sage/10" : moveFrom === i ? "border-yellow-400 bg-yellow-400/10" : "border-white/10 bg-white/5 hover:border-white/30"}`}
            >
              {sl && <IconView itemId={sl.itemId} />}
              {sl && sl.qty > 1 && <span className="absolute bottom-0.5 right-1 text-[9px] font-black text-white/90">{sl.qty}</span>}
            </button>
          );
        })}
      </div>
      {slot && def && (
        <div className="px-4 pb-4">
          <div className="rounded-xl bg-white/5 p-3">
            <p className="font-bold">{def.name} <span className="text-white/40 text-xs">({def.cat})</span></p>
            <p className="text-xs text-white/60 mt-1">{def.desc}</p>
            <p className="text-[10px] text-white/40 mt-1">Nilai jual: {rupiah(def.sell)} • Tumpuk: {def.stack}</p>
            <div className="mt-3 flex flex-wrap gap-2">
              {def.effects && <ActBtn onClick={() => action(() => consumeItem(sel!))}>Gunakan</ActBtn>}
              {def.furniture && (
                <ActBtn onClick={() => {
                  bus.emit(EV.FURNITURE_MODE, { itemId: def.id });
                  close();
                }}>Tempatkan di Kamar</ActBtn>
              )}
              {def.outfit && (
                <ActBtn onClick={() => {
                  gamestate.get().outfit = def.outfit!;
                  bus.emit("outfit_changed");
                  toast(`${def.name} dipakai.`, "sukses");
                }}>Pakai Sekarang</ActBtn>
              )}
              <ActBtn onClick={() => { setMoveFrom(sel); setSel(null); }}>Pindah</ActBtn>
              <ActBtn danger onClick={() => action(() => dropSlot(sel!))}>Buang</ActBtn>
            </div>
          </div>
        </div>
      )}
      <p className="px-4 pb-4 text-[10px] text-white/35">Klik item lalu pilih aksi. Klik dua slot untuk menukar posisi.</p>
    </PanelShell>
  );
}

function IconView({ itemId }: { itemId: string }) {
  const def = ITEMS[itemId];
  if (!def) return null;
  if (def.furniture) {
    return <img src={`/game/assets/${def.furniture}.png`} alt={def.name} className="w-8 h-8 object-contain" style={{ imageRendering: "pixelated" }} />;
  }
  const frame = ICON_FRAME[def.icon] ?? 0;
  return (
    <div
      className="w-6 h-6"
      style={{
        imageRendering: "pixelated",
        backgroundImage: "url(/game/assets/icons.png)",
        backgroundSize: "192px 72px",
        backgroundPosition: `-${(frame % 8) * 24}px -${Math.floor(frame / 8) * 24}px`,
        transform: "scale(1.2)",
      }}
      role="img"
      aria-label={def.name}
    />
  );
}

const ICON_ORDER = ["nasi_goreng","ayam_geprek","mie_instan","roti","nasi_bungkus","jus_jeruk","es_teh","kopi","air_botol","telur","cabai","beras","sabun","obat","buku","sketchbook","kaos","jaket","paket","sparepart","sampah","kucing","hadiah_bunga","hadiah_kue"];
const ICON_FRAME = Object.fromEntries(ICON_ORDER.map((id, i) => [id, i]));

// ---------- Panel: Toko ----------
function ShopPanel({ close }: { close: () => void }) {
  const s = useGame();
  const [tab, setTab] = useState<"beli" | "jual">("beli");
  const [shop, setShop] = useState(SHOPS[lastShop.shopId] ?? SHOPS.warung);
  useEffect(() => {
    const off = bus.on(EV.SHOP_OPEN, (p) => {
      const id = (p as { shopId: string }).shopId;
      setShop(SHOPS[id] ?? SHOPS.warung);
    });
    return off;
  }, []);

  const buy = (itemId: string) => {
    const def = item(itemId);
    if (s.money < def.price) {
      toast("Uang tidak cukup.", "peringatan");
      bus.emit("sfx", { name: "reject" });
      return;
    }
    import("@/game/systems/inventory").then(({ addItem }) => {
      if (addItem(itemId, 1)) {
        spendMoney(def.price, `Beli ${def.name}`);
        const gs = gamestate.get();
        gs.stats.itemsBought += 1;
        if (def.outfit) gs.flags[`outfit_${def.outfit}`] = true;
        checkBuyQuests(itemId);
        bus.emit("sfx", { name: "coin" });
        toast(`${def.name} dibeli.`, "sukses");
      }
    });
  };

  const sell = (index: number) => {
    const sl = s.inventory[index];
    if (!sl) return;
    const def = item(sl.itemId);
    if (def.sell <= 0) {
      toast(`${def.name} tidak bisa dijual.`, "peringatan");
      return;
    }
    import("@/game/systems/inventory").then(({ removeItem }) => {
      if (removeItem(sl.itemId, 1)) {
        earnMoney(def.sell, `Jual ${def.name}`);
        bus.emit("sfx", { name: "coin" });
      }
    });
  };

  return (
    <PanelShell title={`Toko — ${shop.name}`} close={close}>
      <div className="flex gap-2 px-4 pt-3">
        <TabBtn active={tab === "beli"} onClick={() => setTab("beli")}>Beli</TabBtn>
        <TabBtn active={tab === "jual"} onClick={() => setTab("jual")}>Jual</TabBtn>
        <span className="ml-auto text-yellow-300 font-black text-sm self-center">{rupiah(s.money)}</span>
      </div>
      <div className="p-4 space-y-2 max-h-80 overflow-y-auto">
        {tab === "beli" &&
          shop.items.map((id) => {
            const d = item(id);
            return (
              <div key={id} className="flex items-center gap-3 rounded-xl bg-white/5 p-2.5">
                <IconView itemId={id} />
                <div className="flex-1 min-w-0">
                  <p className="font-bold text-sm">{d.name}</p>
                  <p className="text-[10px] text-white/45 truncate">{d.desc}</p>
                </div>
                <button onClick={() => buy(id)} className="px-3 py-1.5 rounded-lg bg-sage text-[#12141A] text-xs font-black hover:bg-sage-deep">
                  {rupiah(d.price)}
                </button>
              </div>
            );
          })}
        {tab === "jual" &&
          s.inventory.map((sl, i) =>
            sl ? (
              <div key={i} className="flex items-center gap-3 rounded-xl bg-white/5 p-2.5">
                <IconView itemId={sl.itemId} />
                <div className="flex-1">
                  <p className="font-bold text-sm">{item(sl.itemId).name} ×{sl.qty}</p>
                </div>
                <button onClick={() => sell(i)} className="px-3 py-1.5 rounded-lg bg-white/10 text-xs font-black hover:bg-white/20">
                  Jual {rupiah(item(sl.itemId).sell)}
                </button>
              </div>
            ) : null
          )}
      </div>
    </PanelShell>
  );
}

function checkBuyQuests(itemId: string) {
  import("@/game/systems/quests").then(({ checkQuestObjective }) => {
    if (["nasi_goreng", "ayam_geprek", "mie_instan", "roti", "nasi_bungkus"].includes(itemId)) checkQuestObjective("buy_food", 1);
    if (itemId === "kopi") checkQuestObjective("buy_kopi", 1);
  });
}

// ---------- Panel: Dialog NPC ----------
function DialogPanel({ close }: { close: () => void }) {
  const s = useGame();
  const [npcId, setNpcId] = useState(lastTalkNpc);
  const [lines, setLines] = useState<string[]>([]);
  const [tab, setTab] = useState<"talk" | "gift">("talk");
  const [doneQuests, setDoneQuests] = useState<string[]>(() => turnInQuestsFor(lastTalkNpc));
  const [showDates, setShowDates] = useState(false);
  const [confirmPutus, setConfirmPutus] = useState(false);

  useEffect(() => {
    const off = bus.on("npc_talk", (p) => {
      const id = (p as { npcId: string }).npcId;
      setNpcId(id);
      setTab("talk");
      setLines([]);
      setShowDates(false);
      setConfirmPutus(false);
      const done = turnInQuestsFor(id);
      setDoneQuests(done);
    });
    return off;
  }, []);

  const npc = NPCS.find((n) => n.id === npcId)!;
  const r = rel(npcId);
  const stage = stageOf(r.score);
  const dating = r.dating === true;
  const romanceable = npc.romanceable === true;
  const bisaNembak = romanceable && !dating && canConfess(npcId, s).ok;
  const punyaPacarLain = pacarOf(s) !== null && !dating;

  return (
    <PanelShell title="Percakapan" close={close}>
      <div className="px-4 pt-3 flex items-start gap-3">
        {/* Potret pixel NPC — frame hadap-depan dari spritesheet */}
        <div
          aria-hidden="true"
          className="shrink-0 rounded-xl border border-white/15 bg-[#0B0E14]"
          style={{
            imageRendering: "pixelated",
            width: 56,
            height: 84,
            backgroundImage: `url(/game/assets/npc_${npc.id}.png)`,
            backgroundSize: "400% 400%",
            backgroundPosition: "0 0",
            backgroundRepeat: "no-repeat",
            boxShadow: "inset 0 0 18px rgba(0,0,0,0.55)",
          }}
        />
        <div className="flex-1 min-w-0 pt-0.5">
          <p className="font-black text-[15px] leading-tight">{npc.name}</p>
          <p className="text-[10px] uppercase tracking-[0.16em] text-white/45 mt-0.5">{npc.jobTitle}</p>
          <div className="mt-2 flex items-center gap-1.5 flex-wrap">
            <span className="px-2 py-0.5 rounded-full bg-white/10 font-bold text-[10px]">{stage.name}</span>
            {dating && <span className="px-2 py-0.5 rounded-full bg-pink-500/25 text-pink-300 font-black text-[10px]">♥ Pacar</span>}
          </div>
          <div className="mt-2 flex items-center gap-2">
            <div className="flex-1 h-1.5 rounded-full bg-white/10 overflow-hidden">
              <div className="h-full rounded-full transition-all" style={{ width: `${r.score}%`, background: dating ? "#f472b6" : "#8fd4c8", boxShadow: dating ? "0 0 8px rgba(244,114,182,0.5)" : "0 0 8px rgba(143,212,200,0.35)" }} />
            </div>
            <span className="text-white/40 text-[10px] tabular-nums">{Math.round(r.score)}/100</span>
          </div>
        </div>
      </div>
      {doneQuests.length > 0 && (
        <p className="mx-4 mt-2 text-xs text-emerald-300 bg-emerald-400/10 rounded-lg px-3 py-2">Misi selesai: {doneQuests.join(", ")} — hadiah diterima!</p>
      )}
      <div className="flex gap-2 px-4 pt-3">
        <TabBtn active={tab === "talk"} onClick={() => setTab("talk")}>Bicara</TabBtn>
        <TabBtn active={tab === "gift"} onClick={() => setTab("gift")}>Hadiah</TabBtn>
      </div>
      <div className="p-4 space-y-3">
        {tab === "talk" ? (
          <>
            <div className="rounded-xl bg-white/5 p-3 text-sm min-h-16">
              {lines.length === 0 ? "…" : lines.map((l, i) => <p key={i} className="mb-1 last:mb-0">{l}</p>)}
            </div>
            <div className="flex flex-wrap gap-2">
              <ActBtn onClick={() => {
                const res = chatWith(npcId);
                setLines((ls) => [...ls, res.line]);
                bus.emit("sfx", { name: "pop" });
              }}>Mengobrol</ActBtn>
              <ActBtn onClick={() => setLines((ls) => [...ls, helpNpc(npcId)])}>Menawarkan Bantuan</ActBtn>
              <ActBtn onClick={() => setLines((ls) => [...ls, inviteTogether(npcId)])}>Mengajak Jalan</ActBtn>
              {bisaNembak && (
                <button onClick={() => {
                  const res = confess(npcId);
                  setLines((ls) => [...ls, res.line]);
                }} className="px-3 py-1.5 rounded-lg text-xs font-black bg-pink-500/90 text-white hover:bg-pink-400 transition">♥ Sampaikan Perasaan</button>
              )}
              {dating && (
                <button onClick={() => setShowDates((v) => !v)} className="px-3 py-1.5 rounded-lg text-xs font-black bg-pink-500/20 text-pink-300 border border-pink-400/40 hover:bg-pink-500/30 transition">Ajak Date</button>
              )}
              {dating && (
                confirmPutus ? (
                  <span className="flex items-center gap-2">
                    <span className="text-[11px] text-white/60">Yakin putus dengan {npc.name}?</span>
                    <ActBtn danger onClick={() => {
                      const res = breakUp(npcId);
                      setLines([res.line]);
                      setConfirmPutus(false);
                    }}>Ya, Putus</ActBtn>
                    <ActBtn onClick={() => setConfirmPutus(false)}>Batal</ActBtn>
                  </span>
                ) : (
                  <ActBtn danger onClick={() => setConfirmPutus(true)}>Putus</ActBtn>
                )
              )}
            </div>
            {showDates && dating && (
              <div className="space-y-2">
                <p className="text-[10px] text-white/45">Pilih gaya date — 1x sehari. Mood & kedekatan naik, energi dipakai.</p>
                {DATE_OPTIONS.map((d) => (
                  <button key={d.id} onClick={() => {
                    const res = goOnDate(npcId, d.id);
                    setLines((ls) => [...ls, res.line]);
                    setShowDates(false);
                  }} className="w-full text-left rounded-xl border border-pink-400/25 bg-pink-400/5 p-3 hover:border-pink-400/70 transition">
                    <p className="text-sm font-bold">{d.label} <span className="ml-1 text-[10px] text-yellow-300 font-black">{d.cost > 0 ? rupiah(d.cost) : "Gratis"}</span></p>
                    <p className="text-[10px] text-white/50">{d.desc}</p>
                  </button>
                ))}
              </div>
            )}
            {romanceable && !dating && r.score < ROMANCE.MIN_SCORE && r.score >= 60 && (
              <p className="text-[10px] text-pink-300/80">Kedekatanmu dengan {npc.name} sudah dalam. Capai {ROMANCE.MIN_SCORE} untuk menyampaikan perasaan{punyaPacarLain ? " (putus dulu bila ganti hati)" : ""}.</p>
            )}
            {!romanceable && r.score >= 60 && !punyaPacarLain && (
              <p className="text-[10px] text-white/30">{npc.name} menganggapmu keluarga — hubungan kalian murni persahabatan.</p>
            )}
            {s.needs.kebersihan < 25 && <p className="text-[10px] text-sand-deep">Kamu kurang segar — respons orang sedikit menurun. Mandi dulu, yuk.</p>}
          </>
        ) : (
          <>
            <p className="text-xs text-white/50">Suka: {npc.likes.map((l) => item(l).name).join(", ") || "-"} • Hindari: {npc.dislikes.map((l) => item(l).name).join(", ") || "-"}</p>
            <div className="grid grid-cols-4 gap-2">
              {s.inventory.filter(Boolean).map((sl, i) => {
                const idx = s.inventory.indexOf(sl);
                const d = item(sl!.itemId);
                if (d.cat === "furnitur") return null;
                return (
                  <button key={idx} onClick={() => {
                    const res = giveGift(npcId, sl!.itemId);
                    setLines([res.line]);
                    bus.emit("sfx", { name: res.ok ? "success" : "reject" });
                  }} className="rounded-lg bg-white/5 border border-white/10 p-2 flex flex-col items-center gap-1 hover:border-sage/50">
                    <IconView itemId={sl!.itemId} />
                    <span className="text-[9px] text-white/60 truncate w-full text-center">{d.name}</span>
                  </button>
                );
              })}
            </div>
            {dating && <p className="text-[10px] text-pink-300/80">Tips: hadiah yang disukai pacar memberi efek lebih besar untuk hubungan kalian.</p>}
            {lines.length > 0 && <div className="rounded-xl bg-white/5 p-3 text-sm">{lines[lines.length - 1]}</div>}
          </>
        )}
      </div>
    </PanelShell>
  );
}

// ---------- Panel: Ponsel ----------
function PhonePanel({ close }: { close: () => void }) {
  const s = useGame();
  const [tab, setTab] = useState<"pesan" | "kontak">("pesan");
  const contacts = useMemo(() => {
    const list = [...NPCS.map((n) => ({ id: n.id, name: n.name, title: n.jobTitle }))];
    list.push({ id: "sistem", name: "Pengumuman Kos", title: "Sistem" });
    list.push({ id: "kerja", name: "Info Kerja", title: "Papan Kerja" });
    return list;
  }, []);
  const unread = s.phone.filter((m) => !m.read).length;

  return (
    <PanelShell title="Ponsel" close={close}>
      <div className="flex gap-2 px-4 pt-3">
        <TabBtn active={tab === "pesan"} onClick={() => setTab("pesan")}>Pesan {unread > 0 && <span className="ml-1 px-1.5 rounded-full bg-orange-400 text-[#12141A] text-[9px] font-black">{unread}</span>}</TabBtn>
        <TabBtn active={tab === "kontak"} onClick={() => setTab("kontak")}>Kontak</TabBtn>
      </div>
      <div className="p-4 space-y-2 max-h-80 overflow-y-auto">
        {tab === "pesan" && (
          s.phone.length === 0 ? (
            <p className="text-white/40 text-sm text-center py-6">Belum ada pesan. Pesan datang dari event nyata: misi, kerja, dan pengumuman.</p>
          ) : (
            s.phone.map((m) => {
              const c = contacts.find((x) => x.id === m.from);
              return (
                <div key={m.id} className={`rounded-xl p-3 text-sm ${m.read ? "bg-white/5" : "bg-sage/10 border border-sage/30"}`}>
                  <p className="text-[10px] font-bold text-sage">{c?.name ?? m.from} • hari {m.day} {timeStr(m.time)}</p>
                  <p className="text-white/80 mt-1">{m.text}</p>
                </div>
              );
            })
          )
        )}
        {tab === "kontak" && contacts.map((c) => (
          <div key={c.id} className="rounded-xl bg-white/5 p-3 flex items-center justify-between">
            <div>
              <p className="font-bold text-sm">{c.name}</p>
              <p className="text-[10px] text-white/40">{c.title}</p>
            </div>
            {NPCS.some((n) => n.id === c.id) && (
              rel(c.id).dating ? (
                <span className="text-[10px] px-2 py-0.5 rounded-full bg-pink-500/25 text-pink-300 font-black">♥ Pacar</span>
              ) : (
                <span className="text-[10px] px-2 py-0.5 rounded-full bg-white/10">{stageOf(rel(c.id).score).name}</span>
              )
            )}
          </div>
        ))}
        {s.shift && (
          <div className="rounded-xl bg-sand/10 border border-sand/30 p-3 text-sm">
            <p className="font-bold text-sand-deep">Shift aktif: {JOBS[s.shift.jobId].name}</p>
            <p className="text-white/60 text-xs mt-1">{s.shift.jobId === "kurir" ? `Sisa paket: ${paketCount()}` : "Selesaikan minigame di tempat kerja."}</p>
          </div>
        )}
      </div>
    </PanelShell>
  );
}

// ---------- Panel: Jurnal ----------
function JournalPanel({ close }: { close: () => void }) {
  const s = useGame();
  const [tab, setTab] = useState<"misi" | "stat" | "dompet">("misi");
  const avail = QUESTS.filter((q) => s.quests[q.id]?.status === "tersedia");
  const active = s.activeQuests.map((id) => questById(id));
  const done = QUESTS.filter((q) => s.quests[q.id]?.status === "selesai");

  return (
    <PanelShell title="Jurnal" close={close}>
      <div className="flex gap-2 px-4 pt-3">
        <TabBtn active={tab === "misi"} onClick={() => setTab("misi")}>Misi</TabBtn>
        <TabBtn active={tab === "stat"} onClick={() => setTab("stat")}>Statistik</TabBtn>
        <TabBtn active={tab === "dompet"} onClick={() => setTab("dompet")}>Dompet</TabBtn>
      </div>
      <div className="p-4 space-y-3 max-h-96 overflow-y-auto">
        {tab === "misi" && (
          <>
            {active.map((q) => (
              <div key={q.id} className="rounded-xl bg-sage/10 border border-sage/30 p-3">
                <p className="font-bold text-sm text-cyan-200">{q.name} <span className="text-[9px] bg-sage text-[#12141A] px-1.5 py-0.5 rounded-full ml-1 font-black">AKTIF</span></p>
                <p className="text-xs text-white/60 mt-1">{q.desc}</p>
                <ul className="mt-2 space-y-1">
                  {q.objectives.map((o) => {
                    const doneO = objectiveDone(q.id, o.id);
                    const cnt = s.quests[q.id]?.counts[o.id] ?? 0;
                    return (
                      <li key={o.id} className={`text-xs ${doneO ? "text-emerald-300" : "text-white/60"}`}>
                        {doneO ? "✓" : "○"} {o.desc} {o.target && o.target > 1 && !doneO && `(${cnt}/${o.target})`}
                      </li>
                    );
                  })}
                </ul>
                {q.turnInAt && questReady(q.id) && <p className="text-[10px] text-yellow-300 mt-2">Laporkan ke {NPCS.find((n) => n.id === q.turnInAt)?.name}.</p>}
              </div>
            ))}
            {avail.map((q) => (
              <div key={q.id} className="rounded-xl bg-white/5 p-3">
                <p className="font-bold text-sm">{q.name}</p>
                <p className="text-xs text-white/50 mt-1">{q.desc}</p>
                <button onClick={() => activateQuest(q.id)} className="mt-2 px-3 py-1.5 rounded-lg bg-sage text-[#12141A] text-xs font-black hover:bg-sage-deep">Ambil Misi</button>
              </div>
            ))}
            {done.length > 0 && (
              <div className="rounded-xl bg-white/5 p-3">
                <p className="text-xs font-bold text-white/50 mb-1">SELESAI ({done.length})</p>
                <p className="text-xs text-white/40">{done.map((q) => q.name).join(" • ")}</p>
              </div>
            )}
          </>
        )}
        {tab === "stat" && (
          <div className="grid grid-cols-2 gap-2 text-sm">
            {[
              ["Hari dimainkan", s.stats.daysPlayed],
              ["Uang didapat", rupiah(s.stats.moneyEarned)],
              ["Uang dibelanjakan", rupiah(s.stats.moneySpent)],
              ["Shift kerja", s.stats.shiftsWorked],
              ["Paket terkirim", s.stats.deliveriesDone],
              ["Makan", s.stats.mealsEaten],
              ["Ngobrol", s.stats.chatCount],
              ["Hadiah diberi", s.stats.giftsGiven],
              ["Sampah dikumpulkan", s.stats.trashCollected],
              ["Misi selesai", s.stats.questsDone],
            ].map(([k, v]) => (
              <div key={k as string} className="rounded-xl bg-white/5 p-2.5">
                <p className="text-[10px] text-white/40">{k}</p>
                <p className="font-black">{v as string}</p>
              </div>
            ))}
            <div className="col-span-2">
              <p className="text-[10px] text-white/40 mb-1">PENCAPAIAN</p>
              <div className="flex flex-wrap gap-1.5">
                {achievementProgress(s).map((a) => (
                  <span key={a.id} title={a.desc} className={`px-2 py-1 rounded-lg text-[10px] font-bold ${a.done ? "bg-yellow-400/20 text-yellow-300" : "bg-white/5 text-white/30"}`}>
                    {a.done ? "★" : "☆"} {a.name}
                  </span>
                ))}
              </div>
            </div>
          </div>
        )}
        {tab === "dompet" && (
          <div className="space-y-1.5">
            {s.ledger.length === 0 && <p className="text-white/40 text-sm text-center py-6">Belum ada transaksi.</p>}
            {s.ledger.slice(0, 12).map((l) => (
              <div key={l.id} className="flex justify-between rounded-lg bg-white/5 px-3 py-2 text-sm">
                <div>
                  <p>{l.label}</p>
                  <p className="text-[10px] text-white/40">Hari {l.day} • {timeStr(l.time)}</p>
                </div>
                <p className={`font-black ${l.amount >= 0 ? "text-emerald-300" : "text-red-300"}`}>{l.amount >= 0 ? "+" : ""}{rupiah(l.amount)}</p>
              </div>
            ))}
          </div>
        )}
      </div>
    </PanelShell>
  );
}

// ---------- Panel: Peta ----------
function MapPanel({ close }: { close: () => void }) {
  const s = useGame();
  const ref = useRef<HTMLCanvasElement>(null);
  useEffect(() => {
    const cv = ref.current;
    if (!cv) return;
    const ctx = cv.getContext("2d")!;
    const px = 6;
    cv.width = MAP_W * px;
    cv.height = MAP_H * px;
    const colors: Record<string, string> = {
      ".": "#5d7d3a", ",": "#6e9448", f: "#7ab55e", d: "#b09468", r: "#4a4a54", "-": "#4a4a54", "|": "#4a4a54",
      x: "#8a8a94", s: "#c6bfae", w: "#4e9db0", g: "#96968c",
    };
    for (let y = 0; y < MAP_H; y++) {
      for (let x = 0; x < MAP_W; x++) {
        ctx.fillStyle = colors[OUT_GRID[y][x]] ?? "#5d7d3a";
        ctx.fillRect(x * px, y * px, px, px);
      }
    }
    // bangunan
    ctx.font = "bold 8px sans-serif";
    for (const b of BUILDINGS) {
      ctx.fillStyle = "#e8b06a";
      ctx.fillRect(b.tx * px, b.ty * px, Math.ceil(b.w / 32) * px, Math.ceil(b.h / 32) * px);
      ctx.fillStyle = "#12141A";
      const short = b.name.replace(/Kafe |Minimarket |Bengkel |Warung |Kos |Gazebo /, "").slice(0, 6);
      ctx.fillText(short, b.tx * px + 2, b.ty * px + 8);
    }
    // pemain
    const pxs = s.scene;
    if (pxs) {
      const tx = (pxs.x / 32) * px;
      const ty = (pxs.y / 32) * px;
      ctx.fillStyle = "#8fd4c8";
      ctx.beginPath();
      ctx.arc(tx, ty, 4, 0, Math.PI * 2);
      ctx.fill();
      ctx.strokeStyle = "#fff";
      ctx.lineWidth = 1.5;
      ctx.stroke();
    }
  }, [s.scene]);

  return (
    <PanelShell title="Peta Arunika Tengah" close={close}>
      <div className="p-4">
        <canvas ref={ref} className="w-full rounded-xl border border-white/10" style={{ imageRendering: "pixelated" }} />
        <div className="mt-3 flex flex-wrap gap-2 text-[10px] text-white/60">
          {[["#e8b06a", "Bangunan"], ["#8fd4c8", "Kamu"], ["#c6bfae", "Trotoar"], ["#4a4a54", "Jalan"], ["#4e9db0", "Air"]].map(([c, l]) => (
            <span key={l} className="flex items-center gap-1"><span className="w-3 h-3 rounded-sm" style={{ background: c }} />{l}</span>
          ))}
        </div>
      </div>
    </PanelShell>
  );
}

// ---------- Panel: Pause menu ----------
function PauseMenu({ close }: { close: () => void }) {
  const [view, setView] = useState<"home" | "save" | "settings">("home");
  const [slots, setSlots] = useState<(string | null)[]>([null, null, null]);
  const [msg, setMsg] = useState("");

  useEffect(() => {
    if (view === "save") {
      const id = setTimeout(() => {
        const arr = [1, 2, 3].map((i) => {
        const raw = localStorage.getItem(`kk_meta_slot_${i}`);
        if (!raw) return null;
        try {
          const m = JSON.parse(raw);
          return `${m.name} — hari ${m.day}`;
          } catch {
            return null;
          }
        });
        setSlots(arr);
      }, 0);
      return () => clearTimeout(id);
    }
  }, [view]);

  const save = async (slot: number) => {
    const { saveGame } = await import("@/game/core/save");
    localStorage.setItem("kk_last_slot", String(slot));
    await saveGame(slot, true);
    setMsg(`Tersimpan di slot ${slot}.`);
  };

  const quit = () => {
    bus.emit(EV.QUIT_TO_MENU);
    window.location.hash = "#/play";
    setTimeout(() => window.location.reload(), 60);
  };

  return (
    <PanelShell title="Menu Jeda" close={close}>
      {view === "home" ? (
        <div className="p-4 space-y-2">
          <button onClick={close} className="w-full py-3 rounded-xl bg-sage text-[#12141A] font-extrabold hover:bg-sage-deep">Lanjut Bermain</button>
          <button onClick={() => setView("save")} className="w-full py-3 rounded-xl bg-white/10 font-bold hover:bg-white/15">Simpan Progres</button>
          <button onClick={() => setView("settings")} className="w-full py-3 rounded-xl bg-white/10 font-bold hover:bg-white/15">Pengaturan</button>
          <a href="#/store" className="block w-full py-3 rounded-xl bg-white/10 font-bold hover:bg-white/15 text-center">KOTA KITA STORE</a>
          <button onClick={quit} className="w-full py-3 rounded-xl bg-red-400/15 text-red-300 font-bold hover:bg-red-400/25">Keluar ke Menu Utama</button>
        </div>
      ) : (
        <div className="p-4 space-y-2">
          {slots.map((s, i) => (
            <button key={i} onClick={() => save(i + 1)} className="w-full text-left rounded-xl bg-white/5 border border-white/10 p-3 hover:border-sage/50">
              <p className="font-bold text-sm">Slot {i + 1}</p>
              <p className="text-xs text-white/40">{s ?? "kosong"}</p>
            </button>
          ))}
          {msg && <p className="text-emerald-300 text-sm">{msg}</p>}
          <button onClick={() => setView("home")} className="w-full py-3 rounded-xl bg-white/10 font-bold hover:bg-white/15">← Kembali</button>
        </div>
      )}
      {view === "settings" && (
        <div className="p-4">
          <SettingsBody />
        </div>
      )}
    </PanelShell>
  );
}

function SettingsBody() {
  const [music, setMusic] = useState(() => {
    try {
      const st = JSON.parse(localStorage.getItem("kk_settings") || "{}");
      return st.music ?? 0.5;
    } catch { return 0.5; }
  });
  const [sfx, setSfx] = useState(() => {
    try {
      const st = JSON.parse(localStorage.getItem("kk_settings") || "{}");
      return st.sfx ?? 0.8;
    } catch { return 0.8; }
  });
  const [muted, setMuted] = useState(() => {
    try {
      const st = JSON.parse(localStorage.getItem("kk_settings") || "{}");
      return st.muted ?? false;
    } catch { return false; }
  });

  const persist = (m: number, sfxv: number, mute: boolean) => {
    localStorage.setItem("kk_settings", JSON.stringify({ music: m, sfx: sfxv, muted: mute }));
  };

  return (
    <div className="p-4 space-y-4">
        <div>
          <p className="text-sm flex justify-between"><span>Volume Musik</span><span>{Math.round(music * 100)}%</span></p>
          <input type="range" min={0} max={1} step={0.05} value={music} onChange={(e) => { const v = Number(e.target.value); setMusic(v); persist(v, sfx, muted); }} className="w-full accent-cyan-400" />
        </div>
        <div>
          <p className="text-sm flex justify-between"><span>Volume Efek</span><span>{Math.round(sfx * 100)}%</span></p>
          <input type="range" min={0} max={1} step={0.05} value={sfx} onChange={(e) => { const v = Number(e.target.value); setSfx(v); persist(music, v, muted); }} className="w-full accent-cyan-400" />
        </div>
        <label className="flex items-center gap-2 text-sm">
          <input type="checkbox" checked={muted} onChange={(e) => { setMuted(e.target.checked); persist(music, sfx, e.target.checked); (window as unknown as { __phaserMute?: (m: boolean) => void }).__phaserMute?.(e.target.checked); }} className="accent-cyan-400" />
          Bisukan semua suara
        </label>
        <p className="text-[10px] text-white/35">Pengaturan tersimpan otomatis di perangkat ini.</p>
      </div>
  );
}

function SettingsPanel({ close }: { close: () => void }) {
  return (
    <PanelShell title="Pengaturan" close={close}>
      <SettingsBody />
    </PanelShell>
  );
}

// ---------- Panel: Lemari (wardrobe) ----------
function WardrobePanel({ close }: { close: () => void }) {
  const s = useGame();
  const owned = useMemo(() => {
    const o = new Set<string>(["default"]);
    if (s.flags.outfit_kaos_merah) o.add("kaos_merah");
    if (s.flags.outfit_jaket_denim) o.add("jaket_denim");
    for (const sku of s.flags.gem_skus ? String(s.flags.gem_skus).split(",") : []) {
      if (sku === "skin.golden") o.add("golden");
      if (sku === "outfit.cyber") o.add("cyber");
      if (sku === "outfit.sunset") o.add("sunset");
    }
    return [...o];
  }, [s.flags]);
  const labels: Record<string, string> = {
    default: "Kaos Default",
    kaos_merah: "Kaos Merah",
    jaket_denim: "Jaket Denim",
    golden: "Skin Emas Arunika",
    cyber: "Jaket Neon Cyber",
    sunset: "Kostum Sunset",
  };

  return (
    <PanelShell title="Lemari Pakaian" close={close}>
      <div className="p-4 grid grid-cols-3 gap-2">
        {owned.map((o) => (
          <button key={o} onClick={() => {
            gamestate.get().outfit = o;
            bus.emit("outfit_changed");
            toast("Outfit diganti!", "sukses");
          }} className={`rounded-xl p-3 border flex flex-col items-center gap-2 ${s.outfit === o ? "border-sage bg-sage/10" : "border-white/10 bg-white/5 hover:border-white/30"}`}>
            <img src={`/game/assets/player_${o}.png`} alt={labels[o]} className="h-16" style={{ imageRendering: "pixelated" }} />
            <span className="text-[10px] text-white/70 text-center">{labels[o] ?? o}</span>
          </button>
        ))}
      </div>
      <p className="px-4 pb-4 text-[10px] text-white/35">Outfit premium dari Gems muncul di sini setelah dibeli di store.</p>
    </PanelShell>
  );
}

// ---------- Panel: Tidur ----------
function SleepPanel({ close }: { close: () => void }) {
  const s = useGame();
  return (
    <PanelShell title="Tidur" close={close}>
      <div className="p-4 text-sm text-white/70 space-y-3">
        <p>Waktu sekarang {timeStr(s.timeMin)}. Tidur akan memajukan waktu ke pukul 07.00 dan memulihkan energi.</p>
        <p className="text-xs text-white/40">Progres otomatis tersimpan (slot terakhir).</p>
        <div className="flex gap-2">
          <button onClick={close} className="flex-1 py-3 rounded-xl bg-white/10 font-bold hover:bg-white/15">Nanti Dulu</button>
          <button onClick={() => {
            close();
            bus.emit("sleep_request");
            pushPhone("sistem", "Kamu mimpi tentang kota yang lebih ramai...", "silent");
            applyNeeds({ mood: 2 });
          }} className="flex-1 py-3 rounded-xl bg-sage text-[#12141A] font-extrabold hover:bg-sage-deep">Tidur</button>
        </div>
      </div>
    </PanelShell>
  );
}

// ---------- Minigame: Warung ----------
function WarungGame({ close }: { close: () => void }) {
  const s = useGame();
  const [serves, setServes] = useState(0);
  const [misses, setMisses] = useState(0);
  const MENU = ["nasi_goreng", "ayam_geprek", "nasi_bungkus", "es_teh", "jus_jeruk"];
  const makeOrder = () => {
    const n = 1 + Math.floor(Math.random() * 3);
    return Array.from({ length: n }, () => MENU[Math.floor(Math.random() * MENU.length)]);
  };
  const [order, setOrder] = useState<string[]>(makeOrder);
  const [timeLeft, setTimeLeft] = useState(90);
  const [result, setResult] = useState<null | { serve: number }>(null);
  const servesRef = useRef(serves);
  useEffect(() => {
    servesRef.current = serves;
  }, [serves]);

  useEffect(() => {
    if (result) return;
    const t = setInterval(() => {
      setTimeLeft((v) => {
        if (v <= 1) {
          clearInterval(t);
          finishShift({ correctServe: servesRef.current });
          setResult({ serve: servesRef.current });
          return 0;
        }
        return v - 1;
      });
    }, 1000);
    return () => clearInterval(t);
  }, [result]);

  const serve = (id: string) => {
    if (result) return;
    if (order.includes(id)) {
      const idx = order.indexOf(id);
      const next = [...order.slice(0, idx), ...order.slice(idx + 1)];
      if (next.length === 0) {
        setServes((v) => v + 1);
        bus.emit("sfx", { name: "coin" });
        setOrder(makeOrder());
      } else {
        setOrder(next);
      }
    } else {
      setMisses((m) => m + 1);
      bus.emit("sfx", { name: "reject" });
    }
  };

  return (
    <PanelShell title={`Shift Warung — melayani pembeli (${Math.floor(timeLeft / 60)}:${String(timeLeft % 60).padStart(2, "0")})`} close={close}>
      {result ? (
        <ResultView
          lines={[`Pesanan tersaji: ${result.serve}`, `Kesalahan: ${misses}`, `Level skill warung: ${s.jobs.warung.level}`]}
          onClose={close}
        />
      ) : (
        <div className="p-4">
          <div className="rounded-xl bg-white/5 p-4 text-center">
            <p className="text-xs text-white/50 mb-2">PEMBELI MEMESAN:</p>
            <div className="flex justify-center gap-2 flex-wrap min-h-12">
              {order.map((id, i) => (
                <div key={i} className="rounded-lg border border-orange-400/50 bg-sand/10 p-2">
                  <IconView itemId={id} />
                </div>
              ))}
            </div>
          </div>
          <div className="mt-4 grid grid-cols-5 gap-2">
            {MENU.map((id) => (
              <button key={id} onClick={() => serve(id)} className="rounded-xl bg-white/5 border border-white/10 p-2 flex flex-col items-center gap-1 hover:border-sage/60 active:scale-95">
                <IconView itemId={id} />
                <span className="text-[8px] text-white/60 text-center leading-tight">{item(id).name}</span>
              </button>
            ))}
          </div>
          <p className="mt-3 text-center text-xs text-white/50">Tersaji: <b className="text-emerald-300">{serves}</b> • Salah: <b className="text-red-300">{misses}</b></p>
        </div>
      )}
    </PanelShell>
  );
}

// ---------- Minigame: Minimarket ----------
function MinimarketGame({ close }: { close: () => void }) {
  const s = useGame();
  const ROUNDS = 5;
  const SEQ_LEN = 4;
  const [round, setRound] = useState(0);
  const [seq, setSeq] = useState<number[]>([]);
  const [flash, setFlash] = useState(-1);
  const [inputIdx, setInputIdx] = useState(0);
  const [correct, setCorrect] = useState(0);
  const [showing, setShowing] = useState(true);
  const [result, setResult] = useState<null | { accuracy: number }>(null);
  const GEMS = [0, 1, 2, 3];
  const COLORS = ["#e0b080", "#8fd4c8", "#d9a0ac", "#f0d060"];

  useEffect(() => {
    if (result) return;
    const kick = setTimeout(() => {
      const next = Array.from({ length: SEQ_LEN }, () => Math.floor(Math.random() * 4));
      setSeq(next);
      setInputIdx(0);
      setShowing(true);
      let i = 0;
      const t = setInterval(() => {
        setFlash(next[i]);
        setTimeout(() => setFlash(-1), 320);
        i += 1;
        if (i >= SEQ_LEN) {
          clearInterval(t);
          setTimeout(() => setShowing(false), 350);
        }
      }, 520);
    }, 30);
    return () => clearTimeout(kick);
  }, [round, result]);

  const press = (g: number) => {
    if (showing || result) return;
    if (seq[inputIdx] === g) {
      const ni = inputIdx + 1;
      if (ni >= SEQ_LEN) {
        setCorrect((c) => c + 1);
        bus.emit("sfx", { name: "success" });
        if (round + 1 >= ROUNDS) {
          const accuracy = (correct + 1) / ROUNDS;
          finishShift({ accuracy });
          setResult({ accuracy });
        } else {
          setRound((r) => r + 1);
        }
      } else {
        setInputIdx(ni);
        bus.emit("sfx", { name: "click" });
      }
    } else {
      bus.emit("sfx", { name: "reject" });
      if (round + 1 >= ROUNDS) {
        const acc = correct / ROUNDS;
        finishShift({ accuracy: acc });
        setResult({ accuracy: acc });
      } else {
        setRound((r) => r + 1);
      }
    }
  };

  return (
    <PanelShell title={`Shift Minimarket — isi rak (${round + 1}/${ROUNDS})`} close={close}>
      {result ? (
        <ResultView lines={[`Akurasi: ${Math.round(result.accuracy * 10)}/10`, `Level skill minimarket: ${s.jobs.minimarket.level}`]} onClose={close} />
      ) : (
        <div className="p-4">
          <p className="text-xs text-white/50 text-center mb-3">{showing ? "Hafalkan urutan barang yang diambil dari gudang…" : "Ulangi urutannya!"}</p>
          <div className="grid grid-cols-4 gap-2">
            {GEMS.map((g) => (
              <button key={g} onClick={() => press(g)} disabled={showing}
                className="aspect-square rounded-xl border-2 transition"
                style={{ background: flash === g ? COLORS[g] : "rgba(255,255,255,0.06)", borderColor: flash === g ? "#fff" : "rgba(255,255,255,0.15)" }} />
            ))}
          </div>
          <p className="mt-3 text-center text-xs text-white/50">Benar: <b className="text-emerald-300">{correct}</b> dari {ROUNDS} putaran</p>
        </div>
      )}
    </PanelShell>
  );
}

function ResultView({ lines, onClose }: { lines: string[]; onClose: () => void }) {
  return (
    <div className="p-6 text-center">
      <div className="mx-auto w-14 h-14 rounded-2xl bg-gradient-to-b from-sage to-sage-deep grid place-items-center shadow-[0_0_30px_-6px_rgba(169,194,162,0.6)]">
        <svg viewBox="0 0 24 24" className="w-7 h-7 text-[#12141A]" fill="none" stroke="currentColor" strokeWidth={2.6} strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
          <path d="M4.5 12.5l5 5 10-11" />
        </svg>
      </div>
      <p className="font-black uppercase tracking-[0.18em] text-lg mt-3">Shift Selesai</p>
      <div className="mt-3 space-y-1">
        {lines.map((l, i) => <p key={i} className="text-sm text-white/70">{l}</p>)}
      </div>
      <p className="text-xs text-white/40 mt-3">Upah masuk dompet. Periksa jurnal untuk riwayat.</p>
      <button onClick={onClose} className="mt-4 w-full py-3 rounded-xl bg-sage text-[#12141A] font-extrabold hover:bg-sage-deep transition">Selesai</button>
    </div>
  );
}

// ---------- Shell panel umum — jendela gaya game ----------
function PanelShell({ title, close, children }: { title: string; close: () => void; children: React.ReactNode }) {
  return (
    <div>
      <div className="flex items-center justify-between pl-4 pr-3 py-3 bg-white/[0.04] border-b border-white/10">
        <div className="flex items-center gap-2.5 min-w-0">
          <span className="w-1.5 h-5 rounded-full bg-gradient-to-b from-sage to-sand shrink-0" />
          <p className="font-black text-[13px] uppercase tracking-[0.08em] text-white/90 truncate">{title}</p>
        </div>
        <button onClick={close} aria-label="Tutup" className="kk-icon-btn w-8 h-8 text-white/70 shrink-0">
          <svg viewBox="0 0 24 24" className="w-3.5 h-3.5" fill="none" stroke="currentColor" strokeWidth={2.4} strokeLinecap="round" aria-hidden="true">
            <path d="M6 6l12 12M18 6L6 18" />
          </svg>
        </button>
      </div>
      {children}
    </div>
  );
}

function TabBtn({ active, onClick, children }: { active: boolean; onClick: () => void; children: React.ReactNode }) {
  return (
    <button onClick={onClick} className={`px-3 py-1.5 rounded-lg text-xs font-bold transition ${active ? "bg-sage text-[#12141A]" : "bg-white/10 hover:bg-white/15 text-white/70"}`}>
      {children}
    </button>
  );
}

function ActBtn({ children, onClick, danger }: { children: React.ReactNode; onClick: () => void; danger?: boolean }) {
  return (
    <button onClick={onClick} className={`px-3 py-1.5 rounded-lg text-xs font-bold transition ${danger ? "bg-red-400/15 text-red-300 hover:bg-red-400/25" : "bg-white/10 hover:bg-white/20"}`}>
      {children}
    </button>
  );
}
