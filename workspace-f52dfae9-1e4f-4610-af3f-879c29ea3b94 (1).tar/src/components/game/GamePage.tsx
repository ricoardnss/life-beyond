"use client";
import { authHeaders } from "@/lib/client-session";

// Halaman #/play — menu utama, pemilihan slot, lalu game.
import { useCallback, useEffect, useState } from "react";
import { state as gamestate, subscribe } from "@/game/core/state";
import { GameUI } from "@/components/game/GameUI";
import { SAVE_SLOTS } from "@/game/core/constants";

interface SlotMeta {
  slot: number;
  name: string;
  day: number;
  money: number;
  savedAt: number;
  from: string;
}

function listLocalSlots(): (SlotMeta | null)[] {
  const out: (SlotMeta | null)[] = [];
  for (let i = 1; i <= SAVE_SLOTS; i++) {
    try {
      const raw = localStorage.getItem(`kk_meta_slot_${i}`);
      out.push(raw ? JSON.parse(raw) : null);
    } catch {
      out.push(null);
    }
  }
  return out;
}

export default function GamePage() {
  const [phase, setPhase] = useState<"menu" | "playing">("menu");
  const [, force] = useState(0);

  useEffect(() => {
    const un = subscribe(() => force((n) => n + 1));
    return () => un();
  }, []);

  const startNew = useCallback((name: string) => {
    gamestate.reset(name || "Pendatang");
    const gs = gamestate.get();
    gs.scene = { map: "outdoor", x: 10 * 32 + 16, y: 8 * 32 + 32 };
    localStorage.setItem("kk_last_slot", "1");
    setPhase("playing");
  }, []);

  const startFromSlot = useCallback(async (slot: number) => {
    const { loadGame } = await import("@/game/core/save");
    const loaded = await loadGame(slot);
    if (!loaded) {
      alert("Slot kosong atau rusak.");
      return;
    }
    localStorage.setItem("kk_last_slot", String(slot));
    if (!loaded.scene) loaded.scene = { map: "outdoor", x: 10 * 32 + 16, y: 8 * 32 + 32 };
    setPhase("playing");
  }, []);

  if (phase === "playing") {
    return <GameRunner />;
  }
  return <MainMenu onNew={startNew} onContinue={startFromSlot} onPlayAgain={() => setPhase("playing")} hasActive={Boolean(gamestate.get().scene)} />;
}

function MainMenu({ onNew, onContinue, hasActive }: { onNew: (n: string) => void; onContinue: (slot: number) => void; onPlayAgain: () => void; hasActive: boolean }) {
  const [view, setView] = useState<"home" | "new" | "load" | "help">("home");
  const [name, setName] = useState("");
  const [slots, setSlots] = useState<(SlotMeta | null)[]>([]);
  const [serverSlots, setServerSlots] = useState<SlotMeta[]>([]);

  useEffect(() => {
    if (view === "load") {
      setSlots(listLocalSlots());
      import("@/game/core/save").then(({ pullServerSlots }) =>
        pullServerSlots().then(setServerSlots).catch(() => {})
      );
    }
  }, [view]);

  return (
    <div className="relative min-h-[100dvh] bg-[#0B0E14] text-white overflow-hidden flex items-center justify-center">
      {/* Aurora kalem di latar */}
      <div className="absolute inset-0 pointer-events-none" aria-hidden="true">
        <div className="kk-aurora absolute -top-24 left-1/4 w-[30rem] h-[30rem] rounded-full bg-sage/10 blur-3xl" />
        <div className="kk-aurora absolute bottom-0 right-1/5 w-[24rem] h-[24rem] rounded-full bg-sand/10 blur-3xl" style={{ animationDelay: "-5s" }} />
        <div className="absolute inset-x-0 bottom-0 h-40 bg-gradient-to-t from-black/70 to-transparent" />
      </div>

      {/* Skyline pixel Arunika — deretan bangunan asli dari game */}
      <div className="absolute inset-x-0 bottom-0 pointer-events-none select-none flex items-end justify-center gap-3 sm:gap-5 opacity-80" aria-hidden="true">
        <img src="/game/assets/p_tree1.png" alt="" className="h-16 sm:h-20 mb-1" style={{ imageRendering: "pixelated" }} />
        <img src="/game/assets/b_house_c.png" alt="" className="h-24 sm:h-32" style={{ imageRendering: "pixelated" }} />
        <img src="/game/assets/b_warung.png" alt="" className="h-28 sm:h-40" style={{ imageRendering: "pixelated" }} />
        <img src="/game/assets/p_fountain.png" alt="" className="h-16 sm:h-24 mb-1 kk-float" style={{ imageRendering: "pixelated" }} />
        <img src="/game/assets/b_kafe.png" alt="" className="h-28 sm:h-40" style={{ imageRendering: "pixelated" }} />
        <img src="/game/assets/b_house_a.png" alt="" className="h-24 sm:h-32" style={{ imageRendering: "pixelated" }} />
        <img src="/game/assets/p_lamp.png" alt="" className="h-20 sm:h-28 mb-1" style={{ imageRendering: "pixelated" }} />
        <img src="/game/assets/b_minimarket.png" alt="" className="hidden sm:block h-36" style={{ imageRendering: "pixelated" }} />
        <img src="/game/assets/p_tree2.png" alt="" className="hidden sm:block h-20 mb-1" style={{ imageRendering: "pixelated" }} />
      </div>

      <div className="relative z-10 w-full max-w-lg px-5 py-10">
        <div className="text-center mb-9">
          <p className="text-[10px] sm:text-xs tracking-[0.42em] text-sage font-black mb-3">SIMULASI KEHIDUPAN PIXEL</p>
          <h1 className="text-5xl sm:text-6xl font-black tracking-tight drop-shadow-[0_4px_24px_rgba(169,194,162,0.25)]">
            KOTA KITA<span className="text-sage">:</span>
          </h1>
          <p className="text-2xl sm:text-3xl font-black bg-gradient-to-r from-sand via-sage to-sand bg-clip-text text-transparent mt-1 uppercase tracking-[0.14em]">Life Beyond</p>
          <p className="text-white/45 text-sm mt-4 italic">&ldquo;A little life. A thousand possibilities.&rdquo;</p>
        </div>

        {view === "home" && (
          <div className="space-y-2.5">
            <MenuButton primary onClick={() => setView("new")}>
              Mulai Kehidupan Baru
            </MenuButton>
            <MenuButton onClick={() => setView("load")}>
              Lanjutkan / Muat Slot
            </MenuButton>
            <MenuButton onClick={() => setView("help")}>
              Cara Bermain
            </MenuButton>
            <a href="#/" className="block w-full py-2.5 rounded-xl text-center text-white/40 hover:text-white/80 transition text-sm font-bold">
              ← Kembali ke Beranda Situs
            </a>
          </div>
        )}

        {view === "new" && (
          <form
            onSubmit={(e) => {
              e.preventDefault();
              onNew(name.trim());
            }}
            className="kk-game-window kk-pop p-6 space-y-4"
          >
            <h2 className="font-black text-lg uppercase tracking-[0.1em]">Siapa namamu?</h2>
            <input
              autoFocus
              value={name}
              onChange={(e) => setName(e.target.value)}
              maxLength={16}
              placeholder="Nama pendatang baru"
              className="kk-input"
            />
            <p className="text-xs text-white/40">Kamu memulai dengan Rp150.000, kamar kos sederhana, dan koper pakaian biasa.</p>
            <div className="flex gap-2">
              <button type="button" onClick={() => setView("home")} className="flex-1 py-3 rounded-xl bg-white/10 font-bold hover:bg-white/15 transition">Batal</button>
              <button className="flex-1 py-3 rounded-xl bg-sage text-[#12141A] font-extrabold hover:bg-sage-deep transition">Mulai</button>
            </div>
          </form>
        )}

        {view === "load" && (
          <div className="space-y-3">
            {slots.map((s, i) => (
              <button
                key={i}
                onClick={() => onContinue(i + 1)}
                className="w-full text-left rounded-2xl border border-white/10 bg-[#191C23] p-5 hover:border-sage/50 transition"
              >
                <p className="font-bold">Slot {i + 1} {s ? `— ${s.name}` : ""}</p>
                {s ? (
                  <p className="text-sm text-white/50">Hari {s.day} • Uang Rp{s.money.toLocaleString("id-ID")} • {new Date(s.savedAt).toLocaleString("id-ID")}</p>
                ) : (
                  <p className="text-sm text-white/40">Slot kosong — mulai baru akan menimpa.</p>
                )}
              </button>
            ))}
            {serverSlots.length > 0 && (
              <div className="rounded-2xl border border-sand/30 bg-sand/5 p-4">
                <p className="text-xs font-bold text-sand mb-2">SLOT DARI AKUN (SERVER)</p>
                {serverSlots.map((s) => (
                  <button key={s.slot} onClick={() => onContinue(s.slot)} className="w-full text-left text-sm py-1 hover:text-sage">
                    Slot {s.slot} — {s.name}, hari {s.day} (server)
                  </button>
                ))}
              </div>
            )}
            <button onClick={() => setView("home")} className="w-full py-3 rounded-xl bg-white/10 font-bold hover:bg-white/15 transition">← Kembali</button>
          </div>
        )}

        {view === "help" && (
          <div className="kk-game-window kk-pop p-6 text-sm text-white/70 space-y-3">
            <p><strong className="text-white">Gerak:</strong> WASD / tombol panah (8 arah). <strong className="text-white">Shift</strong> lari (boros energi).</p>
            <p><strong className="text-white">E</strong> interaksi (pintu, NPC, kasir, bangku). <strong className="text-white">I</strong> inventory, <strong className="text-white">J</strong> jurnal misi, <strong className="text-white">M</strong> peta, <strong className="text-white">P</strong> ponsel, <strong className="text-white">Esc</strong> menu jeda, <strong className="text-white">⛶</strong> layar penuh.</p>
            <p><strong className="text-white">Di HP/tablet:</strong> mainkan mode <strong className="text-white">lanskap</strong> seperti game console — joystick analog di kiri-bawah, tombol besar <strong className="text-white">E</strong> + <strong className="text-white">LARI</strong> di kanan-bawah, semuanya menempel di atas layar game. Tombol I/J/M/P/⛶/≡ di kanan atas. Coba di desktop dengan buka <code className="text-sage">?touch=1</code> di URL.</p>
            <p><strong className="text-white">Hidup:</strong> jaga lapar/energi/kebersihan/mood. Kerja shift di warung (07-14), jadi kurir (09-17), atau minimarket (15-21). Tidur di kasur memajukan waktu ke pagi.</p>
            <p><strong className="text-white">Sewa kos</strong> dipotong otomatis Rp25.000 setiap awal minggu. Uang dari kerja, misi, dan menjual barang.</p>
            <button onClick={() => setView("home")} className="mt-2 w-full py-3 rounded-xl bg-white/10 font-bold hover:bg-white/15 transition">← Kembali</button>
          </div>
        )}

        <p className="relative text-center text-[10px] tracking-[0.22em] text-white/25 mt-10 uppercase font-bold">
          v1.0 — Arunika Tengah Build
        </p>
      </div>
    </div>
  );
}

// Tombol menu utama gaya game — lebar, aksen kiri saat hover, chevron kanan
function MenuButton({ children, onClick, primary }: { children: React.ReactNode; onClick: () => void; primary?: boolean }) {
  return (
    <button
      onClick={onClick}
      className={`group relative w-full py-3.5 pl-6 pr-4 rounded-xl text-left font-black tracking-[0.04em] transition active:scale-[0.99] ${
        primary
          ? "bg-sage text-[#12141A] hover:bg-sage-deep shadow-[0_10px_30px_-12px_rgba(169,194,162,0.55)]"
          : "bg-white/[0.07] border border-white/12 text-white/85 hover:bg-white/[0.12] hover:border-sage/40"
      }`}
    >
      <span className={`absolute left-0 top-1/2 -translate-y-1/2 w-1.5 rounded-full bg-current transition-all group-hover:top-1/2 ${primary ? "h-6 bg-[#12141A]/60" : "h-3 bg-sage/0 group-hover:h-6 group-hover:bg-sage/70"}`} />
      <span className="flex items-center justify-between">
        {children}
        <svg viewBox="0 0 24 24" className="w-4 h-4 opacity-50 group-hover:opacity-90 group-hover:translate-x-0.5 transition" fill="none" stroke="currentColor" strokeWidth={2.6} strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
          <path d="M9 6l6 6-6 6" />
        </svg>
      </span>
    </button>
  );
}

// Mount Phaser setelah phase = playing
function GameRunner() {
  const [ready, setReady] = useState(false);
  useEffect(() => {
    let cancelled = false;
    (async () => {
      const { startGame } = await import("@/game/start");
      const el = document.getElementById("game-root");
      if (el && !cancelled) {
        startGame(el);
        // sinkron kosmetik premium dari akun -> flags game
        try {
          const r = await fetch("/api/gems/catalog", { credentials: "include", headers: authHeaders() });
          if (r.ok) {
            const d = await r.json();
            if (d.owned?.length) gamestate.get().flags.gem_skus = d.owned.join(",");
          }
        } catch { /* offline: skip */ }
        setReady(true);
      }
    })();
    return () => {
      cancelled = true;
      import("@/game/start").then(({ stopGame }) => stopGame());
    };
  }, []);

  return (
    <div className="fixed inset-0 bg-black flex items-center justify-center touch-none overflow-hidden">
      {/* Ambience letterbox — area di luar canvas tetap terasa bagian dari game */}
      <div className="absolute inset-0 pointer-events-none" style={{ background: "radial-gradient(120% 100% at 50% 45%, #10141C 0%, #05060A 72%)" }} />
      <div id="game-root" className="relative w-full h-full [&_canvas]:![image-rendering:pixelated]" />
      {/* Vignette tipis di atas canvas — kesan layar game */}
      <div className="absolute inset-0 pointer-events-none kk-vignette" />
      {ready && <GameUI />}
    </div>
  );
}
