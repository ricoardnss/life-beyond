"use client";

// Router SPA berbasis hash — seluruh halaman hidup di route "/" sesuai batas lingkungan.
// #/            -> Beranda KOTA KITA
// #/play        -> Game
// #/store       -> KOTA KITA STORE
// #/admin       -> Admin panel
// #/faq|help|terms|privacy
import { useEffect, useState } from "react";
import { AuthProvider } from "@/components/store/AuthContext";
import Landing from "@/components/store/Landing";
import StoreApp from "@/components/store/StoreApp";
import AdminApp from "@/components/admin/AdminApp";
import GamePage from "@/components/game/GamePage";
import StaticPage from "@/components/store/StaticPage";

export interface Route {
  path: string;
  parts: string[];
}

export function parseHash(): Route {
  const raw = window.location.hash.replace(/^#\/?/, "");
  const parts = raw.split("/").filter(Boolean);
  return { path: "/" + parts.join("/"), parts };
}

export function navigate(to: string) {
  if (window.location.hash === to) return;
  window.location.hash = to;
}

export default function AppRouter() {
  const [route, setRoute] = useState<Route>({ path: "/", parts: [] });

  useEffect(() => {
    const onChange = () => {
      setRoute(parseHash());
      window.scrollTo({ top: 0 });
    };
    window.addEventListener("hashchange", onChange);
    if (!window.location.hash) window.location.hash = "#/";
    onChange();
    return () => window.removeEventListener("hashchange", onChange);
  }, []);

  const first = route.parts[0] ?? "";

  let page: React.ReactNode;
  switch (first) {
    case "":
      page = <Landing />;
      break;
    case "play":
      page = <GamePage />;
      break;
    case "store":
      page = <StoreApp route={route} />;
      break;
    case "admin":
      page = <AdminApp />;
      break;
    case "faq":
    case "help":
    case "terms":
    case "privacy":
      page = <StaticPage kind={first} />;
      break;
    default:
      page = (
        <div className="min-h-screen bg-[#12141A] text-white flex items-center justify-center">
          <div className="text-center">
            <p className="text-4xl mb-2">404</p>
            <p className="text-white/60 mb-4">Halaman tidak ditemukan.</p>
            <a href="#/" className="text-sage hover:underline">Kembali ke Beranda</a>
          </div>
        </div>
      );
  }

  return (
    <AuthProvider>
      {page}
    </AuthProvider>
  );
}
