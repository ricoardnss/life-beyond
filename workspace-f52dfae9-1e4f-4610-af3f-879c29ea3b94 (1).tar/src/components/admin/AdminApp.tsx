"use client";
import { authHeaders } from "@/lib/client-session";

// Admin panel — akses diverifikasi server di setiap endpoint; UI ini hanya pelapis.
import { useCallback, useEffect, useState } from "react";
import { useAuth } from "@/components/store/AuthContext";
import { navigate } from "@/components/AppRouter";
import { rupiah } from "@/components/store/StoreApp";

type Tab = "stats" | "products" | "orders" | "ledger" | "audit";

interface Stats {
  users: number;
  products: number;
  orders: { total: number; pending: number; paid: number; fulfilled: number; refunded: number };
  revenueIdr: number;
  gemsSold: number;
  ledgerEntries: number;
}

interface Product {
  id: string;
  name: string;
  gems: number;
  priceIdr: number;
  description: string;
  active: boolean;
  promoLabel: string | null;
  sortOrder: number;
}

interface AdminOrder {
  id: string;
  userId: string;
  productName: string;
  gems: number;
  amountIdr: number;
  status: string;
  provider: string;
  createdAt: string;
}

interface LedgerRow {
  id: string;
  userId: string;
  delta: number;
  balanceAfter: number;
  reason: string;
  refType: string;
  refId: string;
  note: string | null;
  createdAt: string;
}

interface AuditRow {
  id: string;
  actorEmail: string | null;
  action: string;
  targetType: string;
  targetId: string | null;
  meta: string | null;
  createdAt: string;
}

export default function AdminApp() {
  const { user, loading } = useAuth();
  const [tab, setTab] = useState<Tab>("stats");

  useEffect(() => {
    if (!loading && (!user || user.role !== "admin")) {
      // biarkan halaman menolak via UI; API tetap otoritas utama
    }
  }, [user, loading]);

  if (loading) return <div className="min-h-screen bg-[#12141A] text-white flex items-center justify-center">Memuat…</div>;
  if (!user || user.role !== "admin") {
    return (
      <div className="min-h-screen bg-[#12141A] text-white flex items-center justify-center px-4">
        <div className="text-center max-w-md">
          <p className="text-5xl mb-4">🔒</p>
          <h1 className="text-2xl font-black mb-2">Akses Ditolak</h1>
          <p className="text-white/60 mb-6">Area ini khusus admin. Semua operasi admin diverifikasi di server — peran dari browser tidak dipercaya.</p>
          <a href="#/store/login" className="text-sage hover:underline">Masuk sebagai admin</a>
        </div>
      </div>
    );
  }

  const tabs: { id: Tab; label: string }[] = [
    { id: "stats", label: "Ringkasan" },
    { id: "products", label: "Produk" },
    { id: "orders", label: "Order" },
    { id: "ledger", label: "Ledger Gems" },
    { id: "audit", label: "Log Audit" },
  ];

  return (
    <div className="min-h-screen bg-[#12141A] text-white">
      <header className="border-b border-white/10 sticky top-0 z-40 bg-[#12141A]/90 backdrop-blur">
        <div className="max-w-6xl mx-auto px-4 h-14 flex items-center justify-between">
          <p className="font-black">⚙️ Admin Panel — KOTA KITA</p>
          <div className="flex items-center gap-3 text-sm">
            <span className="text-white/50">{user.email}</span>
            <a href="#/store" className="hover:text-sage">Store</a>
          </div>
        </div>
        <div className="max-w-6xl mx-auto px-4 flex gap-1 overflow-x-auto pb-2">
          {tabs.map((t) => (
            <button key={t.id} onClick={() => setTab(t.id)}
              className={`px-4 py-2 rounded-lg text-sm font-semibold whitespace-nowrap transition ${tab === t.id ? "bg-sage text-[#12141A]" : "bg-white/5 hover:bg-white/10 text-white/70"}`}>
              {t.label}
            </button>
          ))}
        </div>
      </header>
      <main className="max-w-6xl mx-auto px-4 py-8">
        {tab === "stats" && <StatsTab />}
        {tab === "products" && <ProductsTab />}
        {tab === "orders" && <OrdersTab />}
        {tab === "ledger" && <LedgerTab />}
        {tab === "audit" && <AuditTab />}
      </main>
    </div>
  );
}

function StatsTab() {
  const [stats, setStats] = useState<Stats | null>(null);
  useEffect(() => {
    fetch("/api/admin/stats", { credentials: "include", headers: authHeaders() }).then((r) => r.json()).then(setStats).catch(() => {});
  }, []);
  if (!stats) return <p className="text-white/40">Memuat…</p>;
  const cards: { label: string; value: string }[] = [
    { label: "Pengguna", value: stats.users.toLocaleString("id-ID") },
    { label: "Produk", value: stats.products.toLocaleString("id-ID") },
    { label: "Order Total", value: stats.orders.total.toLocaleString("id-ID") },
    { label: "Order Pending", value: stats.orders.pending.toLocaleString("id-ID") },
    { label: "Order Fulfilled", value: stats.orders.fulfilled.toLocaleString("id-ID") },
    { label: "Direfund", value: stats.orders.refunded.toLocaleString("id-ID") },
    { label: "Pendapatan (fulfilled)", value: rupiah(stats.revenueIdr) },
    { label: "Gems Terjual", value: stats.gemsSold.toLocaleString("id-ID") },
  ];
  return (
    <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
      {cards.map((c) => (
        <div key={c.label} className="rounded-2xl border border-white/10 bg-[#191C23] p-5">
          <p className="text-white/50 text-sm">{c.label}</p>
          <p className="text-2xl font-black mt-1">{c.value}</p>
        </div>
      ))}
    </div>
  );
}

function ProductsTab() {
  const [products, setProducts] = useState<Product[] | null>(null);
  const [form, setForm] = useState({ id: "", name: "", gems: "", priceIdr: "", description: "", promoLabel: "" });
  const [msg, setMsg] = useState("");

  const load = useCallback(() => {
    fetch("/api/products?all=1", { credentials: "include", headers: authHeaders() })
      .then((r) => r.json())
      .then((d) => setProducts(d.products))
      .catch(() => {});
  }, []);
  useEffect(load, [load]);

  const create = async (e: React.FormEvent) => {
    e.preventDefault();
    setMsg("");
    const res = await fetch("/api/admin/products", {
      method: "POST",
      headers: { "Content-Type": "application/json", ...authHeaders() },
      credentials: "include",
      body: JSON.stringify({ ...form, gems: Number(form.gems), priceIdr: Number(form.priceIdr) }),
    });
    const d = await res.json();
    if (res.ok) {
      setMsg(`Produk "${d.product.name}" dibuat.`);
      setForm({ id: "", name: "", gems: "", priceIdr: "", description: "", promoLabel: "" });
      load();
    } else setMsg(d.error ?? "Gagal.");
  };

  const patch = async (id: string, data: Record<string, unknown>) => {
    const res = await fetch(`/api/admin/products/${id}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json", ...authHeaders() },
      credentials: "include",
      body: JSON.stringify(data),
    });
    const d = await res.json();
    setMsg(res.ok ? `Produk ${id} diperbarui.` : d.error ?? "Gagal.");
    if (res.ok) load();
  };

  const remove = async (id: string) => {
    const res = await fetch(`/api/admin/products/${id}`, { method: "DELETE", credentials: "include", headers: authHeaders() });
    const d = await res.json();
    setMsg(d.message ?? (res.ok ? "Terhapus." : d.error ?? "Gagal."));
    if (res.ok) load();
  };

  return (
    <div className="space-y-8">
      <section className="rounded-2xl border border-white/10 bg-[#191C23] p-6">
        <h2 className="font-extrabold mb-4">Tambah Paket Top-Up</h2>
        <form onSubmit={create} className="grid sm:grid-cols-3 gap-3">
          <input required placeholder="id-produk (slug)" value={form.id} onChange={(e) => setForm({ ...form, id: e.target.value })}
            className="px-3 py-2.5 rounded-xl bg-[#12141A] border border-white/15 focus:border-sage outline-none text-sm" />
          <input required placeholder="Nama paket" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })}
            className="px-3 py-2.5 rounded-xl bg-[#12141A] border border-white/15 focus:border-sage outline-none text-sm" />
          <input required type="number" min={1} placeholder="Jumlah Gems" value={form.gems} onChange={(e) => setForm({ ...form, gems: e.target.value })}
            className="px-3 py-2.5 rounded-xl bg-[#12141A] border border-white/15 focus:border-sage outline-none text-sm" />
          <input required type="number" min={0} placeholder="Harga (Rp)" value={form.priceIdr} onChange={(e) => setForm({ ...form, priceIdr: e.target.value })}
            className="px-3 py-2.5 rounded-xl bg-[#12141A] border border-white/15 focus:border-sage outline-none text-sm" />
          <input placeholder="Label promo (opsional)" value={form.promoLabel} onChange={(e) => setForm({ ...form, promoLabel: e.target.value })}
            className="px-3 py-2.5 rounded-xl bg-[#12141A] border border-white/15 focus:border-sage outline-none text-sm" />
          <input required placeholder="Deskripsi" value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })}
            className="px-3 py-2.5 rounded-xl bg-[#12141A] border border-white/15 focus:border-sage outline-none text-sm sm:col-span-3" />
          <button className="sm:col-span-3 py-3 rounded-xl bg-sage text-[#12141A] font-extrabold hover:bg-sage transition">Buat Produk</button>
        </form>
        {msg && <p className="mt-3 text-sm text-sage">{msg}</p>}
      </section>

      <section>
        <h2 className="font-extrabold mb-4">Daftar Produk</h2>
        <div className="space-y-3">
          {products?.map((p) => (
            <div key={p.id} className="rounded-2xl border border-white/10 bg-[#191C23] p-4 flex flex-wrap items-center gap-3">
              <div className="flex-1 min-w-52">
                <p className="font-bold">{p.name} <span className="text-white/40 text-xs font-mono">{p.id}</span></p>
                <p className="text-sm text-white/50">{p.gems.toLocaleString("id-ID")} Gems • {rupiah(p.priceIdr)} • urutan {p.sortOrder}</p>
              </div>
              <span className={`px-2 py-1 rounded-full text-xs font-bold border ${p.active ? "bg-emerald-400/15 text-emerald-300 border-emerald-400/40" : "bg-white/10 text-white/50 border-white/20"}`}>
                {p.active ? "Aktif" : "Nonaktif"}
              </span>
              <button onClick={() => patch(p.id, { active: !p.active })} className="px-3 py-2 rounded-lg bg-white/10 hover:bg-white/15 text-sm font-semibold">
                {p.active ? "Nonaktifkan" : "Aktifkan"}
              </button>
              <button onClick={() => {
                const v = window.prompt(`Harga baru (Rp) untuk ${p.name}:`, String(p.priceIdr));
                if (v !== null) patch(p.id, { priceIdr: Number(v) });
              }} className="px-3 py-2 rounded-lg bg-white/10 hover:bg-white/15 text-sm font-semibold">Ubah Harga</button>
              <button onClick={() => {
                const v = window.prompt(`Gems baru untuk ${p.name}:`, String(p.gems));
                if (v !== null) patch(p.id, { gems: Number(v) });
              }} className="px-3 py-2 rounded-lg bg-white/10 hover:bg-white/15 text-sm font-semibold">Ubah Gems</button>
              <button onClick={() => remove(p.id)} className="px-3 py-2 rounded-lg bg-red-400/15 text-red-300 hover:bg-red-400/25 text-sm font-semibold">Hapus</button>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
}

function OrdersTab() {
  const [orders, setOrders] = useState<AdminOrder[] | null>(null);
  const [msg, setMsg] = useState("");
  const load = useCallback(() => {
    fetch("/api/admin/orders", { credentials: "include", headers: authHeaders() }).then((r) => r.json()).then((d) => setOrders(d.orders)).catch(() => {});
  }, []);
  useEffect(load, [load]);

  const refund = async (orderId: string) => {
    if (!window.confirm(`Refund order ${orderId}? Gems akan ditarik dari saldo pemain dan dicatat di ledger+audit.`)) return;
    const res = await fetch("/api/admin/refund", {
      method: "POST",
      headers: { "Content-Type": "application/json", ...authHeaders() },
      credentials: "include",
      body: JSON.stringify({ orderId }),
    });
    const d = await res.json();
    setMsg(d.message ?? (res.ok ? "Refund diproses." : "Gagal."));
    if (res.ok) load();
  };

  return (
    <div>
      {msg && <p className="mb-4 text-sm text-sage">{msg}</p>}
      <div className="overflow-x-auto rounded-2xl border border-white/10">
        <table className="w-full text-sm bg-[#191C23]">
          <thead className="text-white/50 text-left">
            <tr className="border-b border-white/10">
              <th className="px-4 py-3">Order</th><th className="px-4 py-3">Produk</th><th className="px-4 py-3">Gems</th>
              <th className="px-4 py-3">Nominal</th><th className="px-4 py-3">Status</th><th className="px-4 py-3">Provider</th><th className="px-4 py-3">Aksi</th>
            </tr>
          </thead>
          <tbody>
            {orders?.map((o) => (
              <tr key={o.id} className="border-b border-white/5 hover:bg-white/5">
                <td className="px-4 py-3 font-mono text-xs">{o.id}</td>
                <td className="px-4 py-3">{o.productName}</td>
                <td className="px-4 py-3">{o.gems}</td>
                <td className="px-4 py-3">{rupiah(o.amountIdr)}</td>
                <td className="px-4 py-3">
                  <span className={`px-2 py-0.5 rounded-full text-xs font-bold ${o.status === "fulfilled" ? "bg-emerald-400/15 text-emerald-300" : o.status === "pending" ? "bg-yellow-400/15 text-yellow-300" : o.status === "refunded" ? "bg-sand/15 text-sand" : "bg-white/10 text-white/60"}`}>{o.status}</span>
                </td>
                <td className="px-4 py-3 text-xs text-white/50">{o.provider}</td>
                <td className="px-4 py-3">
                  {["paid", "fulfilled"].includes(o.status) ? (
                    <button onClick={() => refund(o.id)} className="px-3 py-1.5 rounded-lg bg-sand/20 text-violet-200 hover:bg-sand/30 text-xs font-bold">Refund</button>
                  ) : (
                    <a href={`#/store/transactions/${o.id}`} className="text-sage text-xs hover:underline">Detail</a>
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
        {orders?.length === 0 && <p className="p-6 text-center text-white/40">Belum ada order.</p>}
      </div>
    </div>
  );
}

function LedgerTab() {
  const [rows, setRows] = useState<LedgerRow[] | null>(null);
  useEffect(() => {
    fetch("/api/admin/ledger", { credentials: "include", headers: authHeaders() }).then((r) => r.json()).then((d) => setRows(d.ledger)).catch(() => {});
  }, []);
  return (
    <div className="overflow-x-auto rounded-2xl border border-white/10">
      <table className="w-full text-sm bg-[#191C23]">
        <thead className="text-white/50 text-left">
          <tr className="border-b border-white/10">
            <th className="px-4 py-3">Waktu</th><th className="px-4 py-3">User</th><th className="px-4 py-3">Δ</th>
            <th className="px-4 py-3">Saldo Akhir</th><th className="px-4 py-3">Alasan</th><th className="px-4 py-3">Ref</th>
          </tr>
        </thead>
        <tbody>
          {rows?.map((r) => (
            <tr key={r.id} className="border-b border-white/5 hover:bg-white/5">
              <td className="px-4 py-3 text-xs text-white/50">{new Date(r.createdAt).toLocaleString("id-ID")}</td>
              <td className="px-4 py-3 font-mono text-xs">{r.userId.slice(-8)}</td>
              <td className={`px-4 py-3 font-bold ${r.delta >= 0 ? "text-emerald-300" : "text-red-300"}`}>{r.delta >= 0 ? "+" : ""}{r.delta}</td>
              <td className="px-4 py-3">{r.balanceAfter}</td>
              <td className="px-4 py-3">{r.reason}</td>
              <td className="px-4 py-3 text-xs text-white/50">{r.refId}</td>
            </tr>
          ))}
        </tbody>
      </table>
      {rows?.length === 0 && <p className="p-6 text-center text-white/40">Ledger kosong.</p>}
    </div>
  );
}

function AuditTab() {
  const [rows, setRows] = useState<AuditRow[] | null>(null);
  useEffect(() => {
    fetch("/api/admin/audit", { credentials: "include", headers: authHeaders() }).then((r) => r.json()).then((d) => setRows(d.audit)).catch(() => {});
  }, []);
  return (
    <div className="space-y-2">
      {rows?.map((r) => (
        <div key={r.id} className="rounded-xl border border-white/10 bg-[#191C23] p-4 text-sm flex flex-wrap gap-2 items-center">
          <span className="px-2 py-0.5 rounded-full bg-white/10 text-xs font-bold">{r.action}</span>
          <span className="text-white/50 text-xs">{new Date(r.createdAt).toLocaleString("id-ID")}</span>
          <span className="text-white/70">{r.actorEmail ?? "sistem"}</span>
          <span className="text-white/40 text-xs">→ {r.targetType}:{r.targetId?.slice(0, 24)}</span>
          {r.meta && <span className="text-white/40 text-xs font-mono truncate max-w-72">{r.meta}</span>}
        </div>
      ))}
      {rows?.length === 0 && <p className="text-center text-white/40 py-8">Log audit kosong.</p>}
    </div>
  );
}
