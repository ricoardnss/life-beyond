"use client";
import { authHeaders } from "@/lib/client-session";

// KOTA KITA STORE — shell + beranda katalog + detail paket + katalog Gems premium.
import { useCallback, useEffect, useState } from "react";
import { useAuth } from "@/components/store/AuthContext";
import { navigate, type Route } from "@/components/AppRouter";
import { StoreAccount } from "@/components/store/StoreAccount";

export interface Product {
  id: string;
  name: string;
  gems: number;
  priceIdr: number;
  description: string;
  active: boolean;
  promoLabel: string | null;
  sortOrder: number;
}

export function rupiah(n: number): string {
  return "Rp" + Math.round(n).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ".");
}

function GemArt({ size = 40 }: { size?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 40 40" aria-hidden="true" className="drop-shadow-[0_0_10px_rgba(79,216,224,0.45)]">
      <defs>
        <linearGradient id="gemg" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0%" stopColor="#7de9f2" />
          <stop offset="55%" stopColor="#22d3ee" />
          <stop offset="100%" stopColor="#7c6cf0" />
        </linearGradient>
      </defs>
      <polygon points="20,4 34,16 20,36 6,16" fill="url(#gemg)" />
      <polygon points="20,4 27,16 20,36 13,16" fill="#a8f4fa" opacity="0.85" />
      <polyline points="6,16 34,16" stroke="#e6fbfd" strokeWidth="1.4" opacity="0.8" />
      <polyline points="13,16 20,4 27,16" stroke="#e6fbfd" strokeWidth="1" opacity="0.7" fill="none" />
    </svg>
  );
}

export function GemBadge({ gems }: { gems: number }) {
  return (
    <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-sage/10 border border-sage/40 text-sage font-bold">
      <GemArt size={16} /> {gems.toLocaleString("id-ID")}
    </span>
  );
}

const STEPS = [
  "Pilih paket Gems dan pastikan kamu sudah masuk akun.",
  "Server membuat order unik dengan harga resmi dari database.",
  "Selesaikan pembayaran melalui penyedia pembayaran.",
  "Webhook diverifikasi server — Gems masuk otomatis dan tercatat di ledger.",
];

export default function StoreApp({ route }: { route: Route }) {
  const parts = route.parts.slice(1); // setelah "store"
  const sub = parts[0] ?? "";

  return (
    <div className="min-h-screen flex flex-col bg-[#12141A] text-white">
      <StoreNav />
      <main className="flex-1">
        {sub === "" && <StoreHome />}
        {sub === "product" && <ProductDetail id={parts[1] ?? ""} />}
        {sub === "gems" && <GemsPage />}
        {(sub === "login" || sub === "register" || sub === "profile" || sub === "transactions" || sub.startsWith("transactions") || sub.startsWith("pay")) && (
          <StoreAccount sub={parts.join("/")} />
        )}
      </main>
      <StoreFooter />
    </div>
  );
}

function StoreNav() {
  const { user, gems, logout } = useAuth();
  return (
    <header className="sticky top-0 z-50 backdrop-blur bg-[#12141A]/85 border-b border-white/10">
      <nav className="max-w-6xl mx-auto px-4 h-16 flex items-center justify-between gap-2" aria-label="Navigasi store">
        <div className="flex items-center gap-4">
          <a href="#/store" className="flex items-center gap-2">
            <span className="w-8 h-8 rounded-lg bg-gradient-to-br from-violet-400 to-cyan-400 flex items-center justify-center font-black text-[#12141A]">S</span>
            <div className="leading-tight">
              <span className="font-extrabold tracking-tight block">KOTA KITA STORE</span>
              <span className="text-[10px] text-white/50 hidden sm:block">Top up, customize, continue your story</span>
            </div>
          </a>
        </div>
        <div className="flex items-center gap-1 sm:gap-2 text-sm">
          <a href="#/store" className="hidden sm:block px-3 py-2 rounded-lg hover:bg-white/10">Katalog</a>
          <a href="#/store/gems" className="hidden sm:block px-3 py-2 rounded-lg hover:bg-white/10">Kosmetik Gems</a>
          <a href="#/store/transactions" className="hidden sm:block px-3 py-2 rounded-lg hover:bg-white/10">Transaksi</a>
          <a href="#/play" className="px-3 py-2 rounded-lg bg-white/10 hover:bg-white/15 font-semibold">▶ Game</a>
          {user ? (
            <div className="flex items-center gap-2">
              <GemBadge gems={gems} />
              <a href="#/store/profile" className="px-3 py-2 rounded-lg bg-sand/90 text-[#12141A] font-bold hover:bg-sand-deep">{user.displayName}</a>
              <button onClick={() => logout()} className="px-2 py-2 rounded-lg text-white/60 hover:text-white" title="Keluar">⎋</button>
            </div>
          ) : (
            <>
              <a href="#/store/login" className="px-3 py-2 rounded-lg hover:bg-white/10">Masuk</a>
              <a href="#/store/register" className="px-3 py-2 rounded-lg bg-sage text-[#12141A] font-bold hover:bg-sage">Daftar</a>
            </>
          )}
        </div>
      </nav>
    </header>
  );
}

// ============ Beranda ============
function StoreHome() {
  const { user } = useAuth();
  const [products, setProducts] = useState<Product[] | null>(null);
  const [error, setError] = useState("");

  useEffect(() => {
    fetch("/api/products")
      .then((r) => r.json())
      .then((d) => setProducts(d.products ?? []))
      .catch(() => setError("Gagal memuat katalog. Coba muat ulang."));
  }, []);

  return (
    <div className="max-w-6xl mx-auto px-4 py-12">
      <section className="text-center mb-12">
        <h1 className="text-3xl sm:text-4xl font-black">Top Up Arunika Gems</h1>
        <p className="text-white/60 mt-3 max-w-2xl mx-auto">
          Gems dipakai untuk skin, outfit, dan dekorasi premium di game. Semua order diproses server: harga resmi dari database, status transparan, riwayat tersimpan.
        </p>
        {!user && (
          <p className="mt-4 text-sm text-sand-deep">
            <a href="#/store/login" className="underline hover:text-sand">Masuk dulu</a> untuk membeli.
          </p>
        )}
      </section>

      {error && <p className="text-center text-red-400 mb-6">{error}</p>}
      {!products && !error && (
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4" aria-busy="true">
          {[0, 1, 2, 3, 4].map((i) => (
            <div key={i} className="h-56 rounded-2xl bg-white/5 animate-pulse" />
          ))}
        </div>
      )}

      <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {products?.map((p) => (
          <article key={p.id} className="group relative rounded-2xl border border-white/10 bg-[#191C23] p-6 flex flex-col items-center text-center hover:border-sage/50 hover:-translate-y-0.5 transition">
            {p.promoLabel && (
              <span className="absolute top-3 left-3 px-2 py-0.5 rounded-full bg-sand/90 text-[#12141A] text-[10px] font-black tracking-wide">{p.promoLabel}</span>
            )}
            <GemArt size={56} />
            <h2 className="mt-4 font-extrabold text-lg">{p.name}</h2>
            <p className="text-sage font-bold mt-1">{p.gems.toLocaleString("id-ID")} Gems</p>
            <p className="text-white/50 text-sm mt-2 flex-1">{p.description}</p>
            <p className="mt-4 font-black text-xl">{rupiah(p.priceIdr)}</p>
            <a
              href={`#/store/product/${p.id}`}
              className="mt-4 w-full py-2.5 rounded-xl bg-sage text-[#12141A] font-bold hover:bg-sage transition"
            >
              Beli
            </a>
          </article>
        ))}
      </div>

      <section className="mt-16 grid sm:grid-cols-4 gap-4">
        {STEPS.map((s, i) => (
          <div key={i} className="rounded-2xl border border-white/10 bg-[#191C23] p-5">
            <span className="w-8 h-8 rounded-full bg-sand/20 text-sand font-black flex items-center justify-center mb-3">{i + 1}</span>
            <p className="text-sm text-white/70">{s}</p>
          </div>
        ))}
      </section>

      <section className="mt-16 rounded-2xl border border-white/10 bg-[#191C23] p-6 sm:p-8">
        <h2 className="text-xl font-extrabold mb-4">Pertanyaan Umum</h2>
        <div className="space-y-3 text-sm text-white/70">
          <p><strong className="text-white">Apakah Gems bisa didapat gratis?</strong> Ya — event resmi in-game memberikan Gems hadiah yang tervalidasi server. Kami tidak menjual loot box.</p>
          <p><strong className="text-white">Berapa lama Gems masuk?</strong> Otomatis beberapa detik setelah webhook pembayaran terverifikasi. Cek halaman status transaksi.</p>
          <p><strong className="text-white">Apakah harga di sini final?</strong> Harga awal dapat diubah oleh pengelola melalui admin panel sebelum peluncuran komersial.</p>
        </div>
        <a href="#/faq" className="inline-block mt-4 text-sage hover:underline text-sm">Baca FAQ lengkap →</a>
      </section>
    </div>
  );
}

// ============ Detail produk ============
function ProductDetail({ id }: { id: string }) {
  const { user } = useAuth();
  const [product, setProduct] = useState<Product | null>(null);
  const [msg, setMsg] = useState("");
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    fetch("/api/products")
      .then((r) => r.json())
      .then((d) => setProduct((d.products as Product[])?.find((p) => p.id === id) ?? null))
      .catch(() => setMsg("Gagal memuat produk."));
  }, [id]);

  const buy = useCallback(async () => {
    if (!user) {
      navigate("#/store/login");
      return;
    }
    setBusy(true);
    setMsg("");
    try {
      const res = await fetch("/api/orders", {
        method: "POST",
        headers: { "Content-Type": "application/json", ...authHeaders() },
        credentials: "include",
        body: JSON.stringify({ productId: id }),
      });
      const data = await res.json();
      if (res.ok && data.redirectUrl) {
        navigate(data.redirectUrl);
        return;
      }
      setMsg(data.error ?? "Gagal membuat order.");
    } catch {
      setMsg("Kesalahan jaringan.");
    } finally {
      setBusy(false);
    }
  }, [id, user]);

  if (msg && !product) return <div className="max-w-3xl mx-auto px-4 py-20 text-center text-white/70">{msg}</div>;
  if (!product) return <div className="max-w-3xl mx-auto px-4 py-20 text-center text-white/40">Memuat…</div>;

  return (
    <div className="max-w-3xl mx-auto px-4 py-12">
      <a href="#/store" className="text-white/50 hover:text-white text-sm">← Kembali ke katalog</a>
      <div className="mt-6 rounded-3xl border border-white/10 bg-[#191C23] p-8">
        <div className="flex flex-col sm:flex-row items-center gap-8">
          <GemArt size={110} />
          <div className="flex-1 text-center sm:text-left">
            <h1 className="text-2xl font-black">{product.name}</h1>
            <p className="text-sage font-bold text-lg mt-1">{product.gems.toLocaleString("id-ID")} Arunika Gems</p>
            <p className="text-white/60 mt-2">{product.description}</p>
            <p className="mt-4 text-3xl font-black">{rupiah(product.priceIdr)}</p>
            <p className="text-xs text-white/40 mt-1">Harga resmi ditetapkan server — dapat berubah oleh pengelola.</p>
          </div>
        </div>
        {msg && <p className="mt-4 text-center text-sand-deep text-sm">{msg}</p>}
        <button
          onClick={buy}
          disabled={busy || !product.active}
          className="mt-6 w-full py-4 rounded-xl bg-sage text-[#12141A] font-extrabold text-lg hover:bg-sage disabled:opacity-50 transition"
        >
          {busy ? "Membuat order…" : user ? "Beli Sekarang" : "Masuk untuk Membeli"}
        </button>
        <p className="mt-3 text-center text-xs text-white/40">
          Order dibuat dengan ID unik. Pembayaran diverifikasi webhook server — status bisa dipantau di Riwayat Transaksi.
        </p>
      </div>
    </div>
  );
}

// ============ Katalog kosmetik Gems ============
interface GemSku {
  sku: string;
  name: string;
  priceGems: number;
  kind: string;
  description: string;
}

const KIND_LABEL: Record<string, string> = {
  skin: "Skin",
  outfit: "Outfit",
  decor: "Dekorasi",
  comfort: "Kenyamanan",
  bundle: "Bundel",
};

function GemsPage() {
  const { user, gems, entitlements, refresh } = useAuth();
  const [skus, setSkus] = useState<GemSku[] | null>(null);
  const [msg, setMsg] = useState("");
  const [busy, setBusy] = useState("");

  useEffect(() => {
    fetch("/api/gems/catalog")
      .then((r) => r.json())
      .then((d) => setSkus(d.skus ?? []))
      .catch(() => setMsg("Gagal memuat katalog kosmetik."));
  }, []);

  const buySku = async (sku: string) => {
    if (!user) {
      navigate("#/store/login");
      return;
    }
    setBusy(sku);
    setMsg("");
    try {
      const nonce = `${Date.now().toString(36)}${Math.random().toString(36).slice(2, 8)}`;
      const res = await fetch("/api/gems/spend", {
        method: "POST",
        headers: { "Content-Type": "application/json", ...authHeaders() },
        credentials: "include",
        body: JSON.stringify({ sku, nonce }),
      });
      const data = await res.json();
      if (res.ok) {
        setMsg(`"${data.sku}" berhasil dibeli! Item aktif di kamar/game.`);
        await refresh();
      } else {
        setMsg(data.error ?? "Gagal membeli.");
      }
    } catch {
      setMsg("Kesalahan jaringan.");
    } finally {
      setBusy("");
    }
  };

  return (
    <div className="max-w-6xl mx-auto px-4 py-12">
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div>
          <h1 className="text-3xl font-black">Kosmetik Premium</h1>
          <p className="text-white/60 mt-1">Belanja langsung dengan Gems — tanpa loot box, semua item terlihat jelas.</p>
        </div>
        <GemBadge gems={gems} />
      </div>
      {msg && <p className="mt-4 text-sm text-sage">{msg}</p>}
      <div className="mt-8 grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {skus?.map((s) => {
          const owned = entitlements.includes(s.sku);
          return (
            <article key={s.sku} className="rounded-2xl border border-white/10 bg-[#191C23] p-6 flex flex-col">
              <span className="text-[10px] font-black tracking-widest text-sand">{KIND_LABEL[s.kind] ?? s.kind}</span>
              <h2 className="mt-1 font-extrabold text-lg">{s.name}</h2>
              <p className="text-white/55 text-sm mt-2 flex-1">{s.description}</p>
              <div className="mt-4 flex items-center justify-between">
                <GemBadge gems={s.priceGems} />
                <button
                  onClick={() => buySku(s.sku)}
                  disabled={owned || busy === s.sku}
                  className={`px-4 py-2 rounded-xl font-bold transition ${owned ? "bg-white/10 text-white/40 cursor-default" : "bg-sand text-[#12141A] hover:bg-sand-deep"}`}
                >
                  {owned ? "Dimiliki" : busy === s.sku ? "Memproses…" : "Beli"}
                </button>
              </div>
            </article>
          );
        })}
      </div>
      <p className="mt-6 text-xs text-white/40 max-w-2xl">
        Item kenyamanan (comfort) memberi efek kualitas hidup kecil dan tidak merusak keseimbangan ekonomi game. Pembelanjaan dicatat di ledger akunmu.
      </p>
    </div>
  );
}

function StoreFooter() {
  return (
    <footer className="border-t border-white/10 mt-auto">
      <div className="max-w-6xl mx-auto px-4 py-8 flex flex-col sm:flex-row items-center justify-between gap-4 text-sm text-white/50">
        <p>© {new Date().getFullYear()} KOTA KITA STORE — bagian dari proyek KOTA KITA: Life Beyond.</p>
        <div className="flex flex-wrap gap-4 justify-center">
          <a href="#/faq" className="hover:text-white">FAQ</a>
          <a href="#/store/help" className="hover:text-white">Bantuan</a>
          <a href="#/store/terms" className="hover:text-white">Syarat &amp; Ketentuan</a>
          <a href="#/store/privacy" className="hover:text-white">Privasi</a>
        </div>
      </div>
      <p className="text-center text-[11px] text-white/30 pb-4">Mode pembayaran saat ini: {process.env.NEXT_PUBLIC_PAYMENT_LABEL ?? "MockPay (DEVELOPMENT ONLY)"}</p>
    </footer>
  );
}
