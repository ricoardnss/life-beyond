// Konteks autentikasi untuk store & game (client-side).
"use client";

import { createContext, useCallback, useContext, useEffect, useState } from "react";
import { authHeaders, clearSessionToken, saveSessionToken } from "@/lib/client-session";

export interface AuthUser {
  id: string;
  email: string;
  displayName: string;
  role: string;
}

interface MeResponse {
  user: AuthUser;
  gems: number;
  entitlements: string[];
}

interface AuthCtx {
  user: AuthUser | null;
  gems: number;
  entitlements: string[];
  loading: boolean;
  refresh: () => Promise<void>;
  login: (email: string, password: string) => Promise<{ ok: boolean; error?: string }>;
  register: (email: string, password: string, displayName: string) => Promise<{ ok: boolean; error?: string }>;
  logout: () => Promise<void>;
}

const Ctx = createContext<AuthCtx>({
  user: null,
  gems: 0,
  entitlements: [],
  loading: true,
  refresh: async () => {},
  login: async () => ({ ok: false }),
  register: async () => ({ ok: false }),
  logout: async () => {},
});

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<AuthUser | null>(null);
  const [gems, setGems] = useState(0);
  const [entitlements, setEntitlements] = useState<string[]>([]);
  const [loading, setLoading] = useState(true);

  const refresh = useCallback(async () => {
    try {
      const res = await fetch("/api/auth/me", { credentials: "include", headers: authHeaders() });
      if (res.ok) {
        const data = (await res.json()) as MeResponse;
        setUser(data.user);
        setGems(data.gems);
        setEntitlements(data.entitlements ?? []);
      } else {
        setUser(null);
        setGems(0);
        setEntitlements([]);
      }
    } catch {
      setUser(null);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    refresh();
    // refresh ulang saat berpindah halaman SPA (mis. setelah pembayaran selesai)
    const onNav = () => refresh();
    window.addEventListener("hashchange", onNav);
    return () => window.removeEventListener("hashchange", onNav);
  }, [refresh]);

  const login = useCallback(async (email: string, password: string) => {
    const res = await fetch("/api/auth/login", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      credentials: "include",
      body: JSON.stringify({ email, password }),
    });
    const data = await res.json().catch(() => ({}));
    if (res.ok) {
      // Simpan token utk fallback header (iframe lintas-situs memblokir cookie).
      if (typeof data.sessionToken === "string") saveSessionToken(data.sessionToken);
      await refresh();
      return { ok: true };
    }
    return { ok: false, error: data.error ?? "Gagal masuk." };
  }, [refresh]);

  const register = useCallback(async (email: string, password: string, displayName: string) => {
    const res = await fetch("/api/auth/register", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      credentials: "include",
      body: JSON.stringify({ email, password, displayName }),
    });
    const data = await res.json().catch(() => ({}));
    if (res.ok) {
      if (typeof data.sessionToken === "string") saveSessionToken(data.sessionToken);
      await refresh();
      return { ok: true };
    }
    return { ok: false, error: data.error ?? "Gagal mendaftar." };
  }, [refresh]);

  const logout = useCallback(async () => {
    await fetch("/api/auth/logout", { method: "POST", credentials: "include", headers: authHeaders() });
    clearSessionToken();
    setUser(null);
    setGems(0);
    setEntitlements([]);
  }, []);

  return <Ctx.Provider value={{ user, gems, entitlements, loading, refresh, login, register, logout }}>{children}</Ctx.Provider>;
}

export function useAuth() {
  return useContext(Ctx);
}
