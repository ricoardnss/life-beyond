"use client";
import { authHeaders } from "@/lib/client-session";

// Halaman akun store: login, register, profil, riwayat transaksi, detail order,
// dan halaman "gateway" MockPay (DEVELOPMENT ONLY).
import { useCallback, useEffect, useState } from "react";
import { useAuth } from "@/components/store/AuthContext";
import { navigate } from "@/components/AppRouter";
import { rupiah, GemBadge } from "@/components/store/StoreApp";

const STATUS_LABEL: Record<string, string> = {
  pending: "Menunggu Pembayaran",
  paid: "Dibayar",
  fulfilled: "Berhasil (Gems Terkirim)",
  failed: "Gagal",
  expired: "Kedaluwarsa",
  refunded: "Direfund",
};
const STATUS_COLOR: Record<string, string> = {
  pending: "bg-yellow-400/15 text-yellow-300 border-yellow-400/40",
  paid: "bg-sage/15 text-sage border-sage/40",
  fulfilled: "bg-emerald-400/15 text-emerald-300 border-emerald-400/40",
  failed: "bg-red-400/15 text-red-300 border-red-400/40",
  expired: "bg-white/10 text-white/50 border-white/20",
  refunded: "bg-sand/15 text-sand border-sand/40",
};

interface Order {
  id: string;
  productName?: string;
  productId?: string;
  gems: number;
  amountIdr: number;
  status: string;
  provider: string;
  createdAt: string;
  paidAt?: string | null;
  fulfilledAt?: string | null;
  expiresAt?: string | null;
}

export function StoreAccount({ sub }: { sub: string }) {
  const page = sub.split("/")[0];
  if (page === "login") return <LoginPage />;
  if (page === "register") return <RegisterPage />;
  if (page === "profile") return <ProfilePage />;
  if (page === "transactions") return partsTail(sub, 1) ? <OrderDetail id={partsTail(sub, 1)!} /> : <TransactionsPage />;
  if (page === "pay") return <MockGateway orderId={partsTail(sub, 1)!} />;
  return <LoginPage />;
}

function partsTail(sub: string, idx: number): string | null {
  const p = sub.split("/");
  return p[idx] ?? null;
}

// ---------- Login ----------
function LoginPage() {
  const { login } = useAuth();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setBusy(true);
    setError("");
    const r = await login(email, password);
    setBusy(false);
    if (r.ok) navigate("#/store");
    else setError(r.error ?? "Gagal masuk.");
  };

  return (
    <AuthLayout title="Masuk" subtitle="Gunakan akun KOTA KITA untuk top-up & sinkron progres game.">
      <form onSubmit={submit} className="kk-card p-5 sm:p-6 space-y-3 sm:space-y-4">
        <div>
          <label htmlFor="email" className="kk-label">Email</label>
          <input id="email" type="email" required autoComplete="email" value={email} onChange={(e) => setEmail(e.target.value)}
            className="kk-input" placeholder="kamu@contoh.com" />
        </div>
        <div>
          <label htmlFor="password" className="kk-label">Password</label>
          <input id="password" type="password" required autoComplete="current-password" value={password} onChange={(e) => setPassword(e.target.value)}
            className="kk-input" placeholder="••••••••" />
        </div>
        {error && <p className="text-[#d98a80] text-sm" role="alert">{error}</p>}
        <button disabled={busy} className="w-full py-3 rounded-xl kk-btn-primary">
          {busy ? "Memproses…" : "Masuk"}
        </button>
        <p className="text-sm text-white/50 text-center">
          Belum punya akun? <a href="#/store/register" className="text-sage hover:underline">Daftar</a>
        </p>
      </form>
    </AuthLayout>
  );
}

/** Bingkai halaman auth: rapi di portrait, padat & bisa digulir di landscape pendek (HP). */
function AuthLayout({ title, subtitle, children }: { title: string; subtitle: string; children: React.ReactNode }) {
  return (
    <div className="min-h-[100dvh] flex items-center justify-center px-4 py-6 landscape:py-3">
      <div className="w-full max-w-md landscape:max-h-[94dvh] landscape:overflow-y-auto">
        <div className="text-center mb-5 landscape:mb-3">
          <h1 className="text-2xl sm:text-3xl font-black text-center">{title}</h1>
          <p className="text-white/50 text-center mt-1.5 mb-5 landscape:mb-3 text-sm">{subtitle}</p>
        </div>
        {children}
      </div>
    </div>
  );
}

// ---------- Register ----------
function RegisterPage() {
  const { register } = useAuth();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [displayName, setDisplayName] = useState("");
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setBusy(true);
    setError("");
    const r = await register(email, password, displayName);
    setBusy(false);
    if (r.ok) navigate("#/store");
    else setError(r.error ?? "Gagal mendaftar.");
  };

  return (
    <AuthLayout title="Daftar Akun" subtitle="Gratis. Data hanya dipakai untuk akun game & transaksi.">
      <form onSubmit={submit} className="kk-card p-5 sm:p-6 space-y-3 sm:space-y-4">
        <div>
          <label htmlFor="rname" className="kk-label">Nama Tampilan</label>
          <input id="rname" required minLength={2} maxLength={24} value={displayName} onChange={(e) => setDisplayName(e.target.value)}
            className="kk-input" placeholder="Nama di dunia Arunika" />
        </div>
        <div>
          <label htmlFor="remail" className="kk-label">Email</label>
          <input id="remail" type="email" required autoComplete="email" value={email} onChange={(e) => setEmail(e.target.value)}
            className="kk-input" placeholder="kamu@contoh.com" />
        </div>
        <div>
          <label htmlFor="rpass" className="kk-label">Password (min. 8 karakter)</label>
          <input id="rpass" type="password" required minLength={8} autoComplete="new-password" value={password} onChange={(e) => setPassword(e.target.value)}
            className="kk-input" placeholder="••••••••" />
        </div>
        {error && <p className="text-[#d98a80] text-sm" role="alert">{error}</p>}
        <button disabled={busy} className="w-full py-3 rounded-xl kk-btn-primary">
          {busy ? "Memproses…" : "Buat Akun"}
        </button>
        <p className="text-sm text-white/50 text-center">
          Sudah punya akun? <a href="#/store/login" className="text-sage hover:underline">Masuk</a>
        </p>
      </form>
    </AuthLayout>
  );
}

// ---------- Profil ----------
function ProfilePage() {
  const { user, gems, loading, logout } = useAuth();
  if (loading) return <div className="max-w-2xl mx-auto px-4 py-20 text-center text-white/40">Memuat…</div>;
  if (!user) {
    navigate("#/store/login");
    return null;
  }
  return (
    <div className="max-w-2xl mx-auto px-4 py-12 space-y-4">
      <h1 className="text-3xl font-black">Profil Akun</h1>
      <div className="rounded-2xl border border-white/10 bg-[#191C23] p-6 space-y-2">
        <p><span className="text-white/50">Nama:</span> <strong>{user.displayName}</strong></p>
        <p><span className="text-white/50">Email:</span> {user.email}</p>
        <p className="flex items-center gap-2"><span className="text-white/50">Saldo:</span> <GemBadge gems={gems} /></p>
        <p><span className="text-white/50">Peran:</span> {user.role === "admin" ? "Admin" : "Pemain"}</p>
      </div>
      <div className="grid sm:grid-cols-2 gap-3">
        <a href="#/store/transactions" className="rounded-2xl border border-white/10 bg-[#191C23] p-5 hover:border-sage/40 transition">
          <p className="font-bold">Riwayat Transaksi →</p>
          <p className="text-sm text-white/50 mt-1">Status order dan rincian pembayaran.</p>
        </a>
        <a href="#/play" className="rounded-2xl border border-white/10 bg-[#191C23] p-5 hover:border-sage/40 transition">
          <p className="font-bold">Buka Game →</p>
          <p className="text-sm text-white/50 mt-1">Progres tersinkron lewat akun ini.</p>
        </a>
      </div>
      <button onClick={() => logout()} className="px-6 py-3 rounded-xl bg-white/10 hover:bg-white/15 font-semibold">Keluar</button>
      {user.role === "admin" && (
        <a href="#/admin" className="block rounded-2xl border border-sand/40 bg-sand/10 p-5 hover:border-orange-400 transition">
          <p className="font-bold text-sand-deep">Admin Panel →</p>
          <p className="text-sm text-white/60 mt-1">Kelola produk, order, ledger, dan audit.</p>
        </a>
      )}
    </div>
  );
}

// ---------- Riwayat transaksi ----------
function TransactionsPage() {
  const { user, loading } = useAuth();
  const [orders, setOrders] = useState<Order[] | null>(null);
  const [error, setError] = useState("");

  useEffect(() => {
    if (loading) return;
    if (!user) {
      navigate("#/store/login");
      return;
    }
    fetch("/api/orders", { credentials: "include", headers: authHeaders() })
      .then(async (r) => {
        if (!r.ok) throw new Error((await r.json()).error ?? "Gagal memuat.");
        return r.json();
      })
      .then((d) => setOrders(d.orders))
      .catch((e) => setError(e.message));
  }, [user, loading]);

  return (
    <div className="max-w-3xl mx-auto px-4 py-12">
      <h1 className="text-3xl font-black mb-6">Riwayat Transaksi</h1>
      {error && <p className="text-red-400">{error}</p>}
      {!orders && !error && <p className="text-white/40">Memuat…</p>}
      {orders?.length === 0 && (
        <div className="rounded-2xl border border-white/10 bg-[#191C23] p-8 text-center">
          <p className="text-white/60">Belum ada transaksi. <a href="#/store" className="text-sage hover:underline">Top up pertamamu?</a></p>
        </div>
      )}
      <div className="space-y-3">
        {orders?.map((o) => (
          <a key={o.id} href={`#/store/transactions/${o.id}`} className="block rounded-2xl border border-white/10 bg-[#191C23] p-5 hover:border-sage/40 transition">
            <div className="flex items-center justify-between flex-wrap gap-2">
              <div>
                <p className="font-bold">{o.productName}</p>
                <p className="text-xs text-white/40 mt-0.5">{o.id} • {new Date(o.createdAt).toLocaleString("id-ID")}</p>
              </div>
              <div className="text-right">
                <p className="font-black">{rupiah(o.amountIdr)}</p>
                <span className={`inline-block mt-1 px-2 py-0.5 rounded-full border text-xs font-bold ${STATUS_COLOR[o.status]}`}>{STATUS_LABEL[o.status] ?? o.status}</span>
              </div>
            </div>
          </a>
        ))}
      </div>
    </div>
  );
}

// ---------- Detail order ----------
function OrderDetail({ id }: { id: string }) {
  const [order, setOrder] = useState<Order | null>(null);
  const [error, setError] = useState("");

  const load = useCallback(() => {
    fetch(`/api/orders/${id}`, { credentials: "include", headers: authHeaders() })
      .then(async (r) => {
        const d = await r.json();
        if (!r.ok) throw new Error(d.error ?? "Gagal memuat.");
        return d;
      })
      .then((d) => setOrder(d.order))
      .catch((e) => setError(e.message));
  }, [id]);

  useEffect(() => {
    load();
    // polling saat pending (status bisa berubah dari webhook)
    const t = setInterval(() => {
      fetch(`/api/orders/${id}`, { credentials: "include", headers: authHeaders() })
        .then((r) => (r.ok ? r.json() : null))
        .then((d) => d?.order && setOrder(d.order))
        .catch(() => {});
    }, 3000);
    return () => clearInterval(t);
  }, [load, id]);

  if (error) return <div className="max-w-2xl mx-auto px-4 py-20 text-center"><p className="text-red-400">{error}</p><a href="#/store/transactions" className="text-sage underline mt-2 inline-block">← Kembali</a></div>;
  if (!order) return <div className="max-w-2xl mx-auto px-4 py-20 text-center text-white/40">Memuat…</div>;

  return (
    <div className="max-w-2xl mx-auto px-4 py-12">
      <a href="#/store/transactions" className="text-white/50 hover:text-white text-sm">← Riwayat Transaksi</a>
      <div className="mt-6 rounded-3xl border border-white/10 bg-[#191C23] p-8">
        <div className="flex items-start justify-between flex-wrap gap-3">
          <div>
            <h1 className="text-2xl font-black">{order.productName}</h1>
            <p className="text-xs text-white/40 mt-1 font-mono">{order.id}</p>
          </div>
          <span className={`px-3 py-1 rounded-full border text-sm font-bold ${STATUS_COLOR[order.status]}`}>{STATUS_LABEL[order.status] ?? order.status}</span>
        </div>
        <dl className="mt-6 space-y-2 text-sm">
          {[
            ["Jumlah Gems", `${order.gems.toLocaleString("id-ID")} Gems`],
            ["Total Bayar", rupiah(order.amountIdr)],
            ["Provider", order.provider === "mockpay" ? "MockPay (DEVELOPMENT ONLY)" : order.provider],
            ["Dibuat", new Date(order.createdAt).toLocaleString("id-ID")],
            ...(order.paidAt ? [["Dibayar", new Date(order.paidAt).toLocaleString("id-ID")]] : []),
            ...(order.fulfilledAt ? [["Gems Terkirim", new Date(order.fulfilledAt).toLocaleString("id-ID")]] : []),
          ].map(([k, v]) => (
            <div key={k as string} className="flex justify-between border-b border-white/5 pb-2">
              <dt className="text-white/50">{k}</dt>
              <dd className="font-semibold">{v}</dd>
            </div>
          ))}
        </dl>
        {order.status === "pending" && (
          <div className="mt-6">
            <a href={`#/store/pay/${order.id}`} className="block w-full text-center py-3 rounded-xl bg-sage text-[#12141A] font-extrabold hover:bg-sage transition">
              Lanjutkan Pembayaran
            </a>
            <p className="text-center text-xs text-white/40 mt-2">Menunggu webhook pembayaran… halaman ini memperbarui status otomatis.</p>
          </div>
        )}
        {order.status === "fulfilled" && (
          <a href="#/play" className="mt-6 block w-full text-center py-3 rounded-xl bg-emerald-400 text-[#12141A] font-extrabold hover:bg-emerald-300 transition">Lanjutkan Ceritamu di Game →</a>
        )}
      </div>
    </div>
  );
}

// ---------- Mock gateway (DEVELOPMENT ONLY) ----------
function MockGateway({ orderId }: { orderId: string }) {
  const { user } = useAuth();
  const [busy, setBusy] = useState("");
  const [msg, setMsg] = useState("");
  const [order, setOrder] = useState<Order | null>(null);

  useEffect(() => {
    fetch(`/api/orders/${orderId}`, { credentials: "include", headers: authHeaders() })
      .then((r) => (r.ok ? r.json() : null))
      .then((d) => d?.order && setOrder(d.order))
      .catch(() => {});
  }, [orderId]);

  const simulate = async (result: string) => {
    setBusy(result);
    setMsg("");
    try {
      const res = await fetch("/api/payment/mock/checkout", {
        method: "POST",
        headers: { "Content-Type": "application/json", ...authHeaders() },
        credentials: "include",
        body: JSON.stringify({ orderId, result }),
      });
      const data = await res.json();
      setMsg(data.message ?? (res.ok ? "Tersimulasi." : "Gagal."));
      if (res.ok) {
        setTimeout(() => navigate(`#/store/transactions/${orderId}`), 900);
      }
    } catch {
      setMsg("Kesalahan jaringan.");
    } finally {
      setBusy("");
    }
  };

  if (!user) {
    return (
      <div className="max-w-md mx-auto px-4 py-20 text-center">
        <p className="text-white/60">Masuk dulu untuk membuka halaman pembayaran.</p>
        <a href="#/store/login" className="text-sage underline mt-2 inline-block">Masuk</a>
      </div>
    );
  }

  return (
    <div className="max-w-md mx-auto px-4 py-12">
      <div className="rounded-3xl border-2 border-sand/50 bg-[#191C23] overflow-hidden">
        <div className="bg-sand/15 px-6 py-4 flex items-center gap-3">
          <span className="w-9 h-9 rounded-lg bg-sand text-[#12141A] font-black flex items-center justify-center">M</span>
          <div>
            <p className="font-black">MockPay Checkout</p>
            <p className="text-[11px] font-bold text-sand-deep tracking-wide">DEVELOPMENT ONLY — BUKAN PEMBAYARAN NYATA</p>
          </div>
        </div>
        <div className="p-6">
          {order ? (
            <>
              <p className="text-white/50 text-sm">Order</p>
              <p className="font-mono text-xs">{order.id}</p>
              <div className="mt-4 flex items-center justify-between rounded-xl bg-[#12141A] border border-white/10 px-4 py-3">
                <div>
                  <p className="font-bold">{order.productName}</p>
                  <p className="text-xs text-sage">{order.gems.toLocaleString("id-ID")} Gems</p>
                </div>
                <p className="font-black text-lg">{rupiah(order.amountIdr)}</p>
              </div>
              <p className="mt-4 text-xs text-white/40 leading-relaxed">
                Halaman ini mensimulasikan tampilan checkout penyedia pembayaran. Tombol di bawah mengirim webhook tersignature
                ke server melalui jalur pemrosesan yang sama dengan gateway sungguhan (signature → idempotensi → kredit atomik).
              </p>
              {msg && <p className="mt-4 text-sm text-sage">{msg}</p>}
              <div className="mt-5 space-y-2">
                <button onClick={() => simulate("sukses")} disabled={busy !== "" || order.status !== "pending"}
                  className="w-full py-3 rounded-xl bg-emerald-400 text-[#12141A] font-extrabold hover:bg-emerald-300 disabled:opacity-50 transition">
                  {busy === "sukses" ? "Memproses…" : "Simulasikan Bayar Berhasil"}
                </button>
                <div className="grid grid-cols-2 gap-2">
                  <button onClick={() => simulate("gagal")} disabled={busy !== "" || order.status !== "pending"}
                    className="py-3 rounded-xl bg-white/10 font-bold hover:bg-white/15 disabled:opacity-50 transition">Gagalkan</button>
                  <button onClick={() => simulate("kedaluwarsa")} disabled={busy !== "" || order.status !== "pending"}
                    className="py-3 rounded-xl bg-white/10 font-bold hover:bg-white/15 disabled:opacity-50 transition">Kedaluwarsa</button>
                </div>
              </div>
            </>
          ) : (
            <p className="text-white/40">Memuat order…</p>
          )}
          <a href={`#/store/transactions/${orderId}`} className="block mt-5 text-center text-sm text-white/50 hover:text-white">← Status Transaksi</a>
        </div>
      </div>
    </div>
  );
}
