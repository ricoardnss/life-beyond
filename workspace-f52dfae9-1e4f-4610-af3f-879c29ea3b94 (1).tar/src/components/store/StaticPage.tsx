"use client";

// Halaman statis: FAQ, Bantuan, Syarat & Ketentuan, Kebijakan Privasi.
import { useAuth } from "@/components/store/AuthContext";

const CONTENT: Record<string, { title: string; body: React.ReactNode }> = {
  faq: {
    title: "Pertanyaan Umum (FAQ)",
    body: (
      <div className="space-y-6">
        <section>
          <h2 className="font-bold text-lg">Tentang Game</h2>
          <div className="mt-2 space-y-3 text-white/70 text-sm">
            <p><strong className="text-white">Apakah game gratis?</strong> Ya. KOTA KITA bisa dimainkan gratis di browser. Ada mata uang premium (Arunika Gems) untuk kosmetik, tetapi tidak ada konten gameplay yang dikunci di balik pembayaran.</p>
            <p><strong className="text-white">Apakah progres tersimpan?</strong> Ya — tiga slot save di perangkatmu, plus sinkronisasi otomatis ke akun saat login (misal saat tidur atau menyimpan manual). Data di server memakai akun yang sama dengan store.</p>
            <p><strong className="text-white">Bisakah main tanpa akun?</strong> Bisa. Progres tetap tersimpan di perangkat, tapi fitur top-up dan sinkronisasi antar-perangkat butuh akun.</p>
            <p><strong className="text-white">Apa yang bisa dibeli dengan Gems?</strong> Hanya kosmetik dan kenyamanan: skin, outfit, dekorasi kamar, dan efek visual. Kami tidak menjual loot box, tidak menjual uang game, dan tidak menjual keunggulan kompetitif.</p>
          </div>
        </section>
        <section>
          <h2 className="font-bold text-lg">Tentang Top-Up</h2>
          <div className="mt-2 space-y-3 text-white/70 text-sm">
            <p><strong className="text-white">Berapa lama Gems masuk?</strong> Gem masuk otomatis setelah webhook pembayaran terverifikasi server — biasanya hitungan detik. Jika pembayaran berhasil tapi Gems belum masuk dalam 15 menit, hubungi bantuan dengan melampirkan ID order.</p>
            <p><strong className="text-white">Status order saya &ldquo;pending&rdquo; terus?</strong> Pembayaran mungkin belum selesai di sisi penyedia pembayaran. Cek halaman status transaksi; halaman memperbarui otomatis. Jangan melakukan order baru untuk paket yang sama selama masih pending.</p>
            <p><strong className="text-white">Apakah harga final?</strong> Harga yang tampil adalah harga awal proyek dan dapat diubah oleh pengelola melalui admin sebelum peluncuran komersial. Harga yang berlaku adalah yang tercatat server saat order dibuat.</p>
            <p><strong className="text-white">Bagaimana keamanan transaksi?</strong> Harga ditentukan server, order terikat akunmu, webhook diverifikasi tanda tangan digital, pemrosesan bersifat idempoten (tidak bisa dikredit dua kali), dan seluruh perubahan saldo tercatat di ledger yang bisa diaudit.</p>
          </div>
        </section>
        <section>
          <h2 className="font-bold text-lg">Teknis</h2>
          <div className="mt-2 space-y-3 text-white/70 text-sm">
            <p><strong className="text-white">Spesifikasi minimum?</strong> Browser modern (Chrome/Edge/Firefox terbaru), 2 GB RAM. Kontrol: WASD/panah, E interaksi, Shift lari, I inventory, J jurnal, M peta, Esc menu. Perangkat sentuh mendapat kontrol layar lengkap: joystick virtual, tombol LARI, dan tombol aksi.</p>
            <p><strong className="text-white">Data saya disimpan di mana?</strong> Progres offline di penyimpanan browser; akun, transaksi, dan save tersinkron di database server proyek. Lihat Kebijakan Privasi.</p>
          </div>
        </section>
      </div>
    ),
  },
  help: {
    title: "Pusat Bantuan",
    body: (
      <div className="space-y-6 text-white/70 text-sm">
        <section>
          <h2 className="font-bold text-lg">Masalah Pembayaran</h2>
          <ol className="mt-2 list-decimal list-inside space-y-2">
            <li>Siapkan <strong className="text-white">ID Order</strong> (format KK-ORD-…) dari halaman Riwayat Transaksi.</li>
            <li>Cek status transaksi — jika <em>pending</em>, tunggu maksimal 15 menit; halaman status memperbarui otomatis.</li>
            <li>Jika <em>failed</em> atau <em>expired</em>, silakan buat order baru.</li>
            <li>Jika <em>paid/fulfilled</em> tapi Gems belum terlihat, muat ulang halaman profil — saldo diambil langsung dari server.</li>
            <li>Masih bermasalah? Sertakan ID order dan waktu pembayaran saat menghubungi pengelola.</li>
          </ol>
        </section>
        <section>
          <h2 className="font-bold text-lg">Masalah Game</h2>
          <ul className="mt-2 list-disc list-inside space-y-2">
            <li>Game tampil kabur? Pastikan zoom browser 100% — pixel art dirancang untuk skala bilangan bulat.</li>
            <li>Save rusak? Menu utama akan menolak slot korup dengan aman; coba slot lain atau muat versi server (lebih baru).</li>
            <li>NPC macet di tempat? Jeda melalui menu (Esc) lalu lanjutkan; jadwal NPC memperbarui tiap beberapa detik.</li>
          </ul>
        </section>
        <section>
          <h2 className="font-bold text-lg">Kontak</h2>
          <p className="mt-2">Pengelola proyek: jalur kontak resmi akan diumumkan pemilik proyek sebelum peluncuran. Untuk pengujian sekarang, gunakan catatan issue pada repositori proyek.</p>
        </section>
      </div>
    ),
  },
  terms: {
    title: "Syarat dan Ketentuan",
    body: (
      <div className="space-y-5 text-white/70 text-sm">
        <p>Versi: draft awal proyek — final sebelum peluncuran komersial ditetapkan pemilik proyek.</p>
        <section>
          <h2 className="font-bold text-lg">1. Akun</h2>
          <p className="mt-1">Kamu bertanggung jawab atas kerahasiaan akun dan aktivitas di bawahnya. Satu orang satu akun. Akun dilarang dijual/dipindahtangankan.</p>
        </section>
        <section>
          <h2 className="font-bold text-lg">2. Pembelian Arunika Gems</h2>
          <p className="mt-1">Gems adalah lisensi kosmetik virtual, bukan aset finansial, tidak bisa ditukar uang. Pembelian diproses melalui penyedia pembayaran resmi; order dianggap selesai hanya setelah webhook terverifikasi. Refund mengikuti kebijakan refund dan menyertakan penarikan Gems yang belum terpakai; saldo tidak boleh negatif.</p>
        </section>
        <section>
          <h2 className="font-bold text-lg">3. Perilaku</h2>
          <p className="mt-1">Dilarang mengeksploitasi bug ekonomi, memanipulasi klien, atau mengganggu layanan. Penyalahgunaan dapat berakibat pembatasan akun.</p>
        </section>
        <section>
          <h2 className="font-bold text-lg">4. Layanan</h2>
          <p className="mt-1">Layanan disediakan &ldquo;sebagaimana adanya&rdquo; selama masa pengembangan. Fitur dapat berubah. Kami berupaya memberi pemberitahuan untuk perubahan besar.</p>
        </section>
        <section>
          <h2 className="font-bold text-lg">5. Konten</h2>
          <p className="mt-1">Seluruh aset game dibuat khusus untuk proyek ini. Nama dan dunia &ldquo;Kota Arunika&rdquo; adalah fiksi.</p>
        </section>
      </div>
    ),
  },
  privacy: {
    title: "Kebijakan Privasi",
    body: (
      <div className="space-y-5 text-white/70 text-sm">
        <p>Versi: draft awal proyek — final sebelum peluncuran komersial ditetapkan pemilik proyek.</p>
        <section>
          <h2 className="font-bold text-lg">Data yang Kami Simpan</h2>
          <ul className="mt-1 list-disc list-inside space-y-1">
            <li><strong className="text-white">Akun:</strong> email, nama tampilan, hash password (scrypt + salt). Kami tidak menyimpan password mentah.</li>
            <li><strong className="text-white">Progres game:</strong> snapshot save (posisi, uang, inventory, relasi NPC) terkait akun.</li>
            <li><strong className="text-white">Transaksi:</strong> order, status pembayaran, ledger perubahan Gems, dan log audit — diperlukan untuk akurasi keuangan dan penanganan sengketa.</li>
          </ul>
        </section>
        <section>
          <h2 className="font-bold text-lg">Yang Tidak Kami Simpan</h2>
          <p className="mt-1">Kunci rahasia payment gateway, service-role key, dan kredensial server tidak pernah disimpan atau dikirim ke browser. Log webhook tidak menyimpan rahasia.</p>
        </section>
        <section>
          <h2 className="font-bold text-lg">Hakmu</h2>
          <p className="mt-1">Kamu dapat meminta ekspor atau penghapusan data akun melalui pengelola. Menghapus akun akan menghapus save tersinkron; transaksi tetap disimpan dalam bentuk teragregasi untuk kepatuhan keuangan.</p>
        </section>
        <section>
          <h2 className="font-bold text-lg">Cookie</h2>
          <p className="mt-1">Kami memakai satu cookie sesi httpOnly untuk menjaga status login. Tidak ada pelacak pihak ketiga.</p>
        </section>
      </div>
    ),
  },
};

export default function StaticPage({ kind }: { kind: string }) {
  const { user } = useAuth();
  const c = CONTENT[kind] ?? CONTENT.faq;
  return (
    <div className="min-h-screen flex flex-col bg-[#12141A] text-white">
      <header className="border-b border-white/10 sticky top-0 z-40 bg-[#12141A]/85 backdrop-blur">
        <nav className="max-w-4xl mx-auto px-4 h-14 flex items-center justify-between text-sm">
          <a href="#/store" className="font-extrabold">KOTA KITA STORE</a>
          <div className="flex gap-3">
            <a href="#/play" className="hover:text-sage">▶ Game</a>
            {user ? <a href="#/store/profile" className="hover:text-sage">Profil</a> : <a href="#/store/login" className="hover:text-sage">Masuk</a>}
          </div>
        </nav>
      </header>
      <main className="flex-1 max-w-4xl mx-auto px-4 py-12 w-full">
        <h1 className="text-3xl font-black mb-8">{c.title}</h1>
        {c.body}
      </main>
      <footer className="border-t border-white/10 mt-auto">
        <div className="max-w-4xl mx-auto px-4 py-6 text-sm text-white/40 flex gap-4 justify-center">
          <a href="#/faq" className="hover:text-white">FAQ</a>
          <a href="#/store/help" className="hover:text-white">Bantuan</a>
          <a href="#/store/terms" className="hover:text-white">Syarat</a>
          <a href="#/store/privacy" className="hover:text-white">Privasi</a>
        </div>
      </footer>
    </div>
  );
}
