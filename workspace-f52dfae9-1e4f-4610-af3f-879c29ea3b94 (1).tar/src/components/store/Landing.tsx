// Beranda resmi KOTA KITA: Life Beyond — pintu masuk game & store.
"use client";

import { useAuth } from "@/components/store/AuthContext";

const FEATURES = [
  {
    title: "Hidup Bebas, Tanpa Ending",
    desc: "Jadilah pekerja warung, kurir, pengusaha kafe, atau penjelajah kota. Tidak ada ending wajib — hanya seribu kemungkinan kehidupan kecil di Kota Arunika.",
    tag: "Life Simulation",
  },
  {
    title: "Kota yang Hidup",
    desc: "10 warga punya jadwal, kepribadian, dan cerita sendiri. Warung buka pagi, kafe ramai sore, taman nyaman di malam minggu.",
    tag: "Social Simulation",
  },
  {
    title: "Kebutuhan & Ekonomi Nyata",
    desc: "Kelola lapar, energi, kebersihan, dan mood. Bayar sewa kos mingguan, kerja shift, dan catat semua transaksi di dompet.",
    tag: "Sandbox RPG",
  },
  {
    title: "Pixel Art Kota Indonesia",
    desc: "Tile 32px penuh detail: warung berawning, bengkel motor, gerobak keliling, sampai hujan sore yang bikin nostalgia.",
    tag: "Top-down 2D",
  },
];

export default function Landing() {
  const { user } = useAuth();

  return (
    <div className="min-h-screen flex flex-col bg-[#12141A] text-white">
      {/* Navbar */}
      <header className="sticky top-0 z-50 backdrop-blur bg-[#12141A]/80 border-b border-white/10">
        <nav className="max-w-6xl mx-auto px-4 h-16 flex items-center justify-between" aria-label="Navigasi utama">
          <a href="#/" className="flex items-center gap-2">
            <span className="w-8 h-8 rounded-lg bg-gradient-to-br from-sage to-sand flex items-center justify-center font-black text-[#12141A]">K</span>
            <span className="font-extrabold tracking-tight">KOTA KITA</span>
          </a>
          <div className="flex items-center gap-1 sm:gap-2 text-sm">
            <a href="#/play" className="px-3 py-2 rounded-lg hover:bg-white/10 transition">Main Game</a>
            <a href="#/store" className="px-3 py-2 rounded-lg hover:bg-white/10 transition">Store</a>
            <a href="#/faq" className="hidden sm:block px-3 py-2 rounded-lg hover:bg-white/10 transition">FAQ</a>
            {user ? (
              <a href="#/store/profile" className="ml-2 px-4 py-2 rounded-lg bg-sage text-[#12141A] font-bold hover:bg-sage transition">{user.displayName}</a>
            ) : (
              <a href="#/store/login" className="ml-2 px-4 py-2 rounded-lg bg-sage text-[#12141A] font-bold hover:bg-sage transition">Masuk</a>
            )}
          </div>
        </nav>
      </header>

      <main className="flex-1">
        {/* Hero */}
        <section className="relative overflow-hidden">
          <div className="absolute inset-0 pointer-events-none" aria-hidden="true">
            <div className="absolute -top-24 left-1/4 w-96 h-96 rounded-full bg-sage/10 blur-3xl" />
            <div className="absolute top-40 right-1/5 w-80 h-80 rounded-full bg-sand/10 blur-3xl" />
            <div className="absolute bottom-0 left-10 w-72 h-72 rounded-full bg-sand/10 blur-3xl" />
          </div>
          <div className="relative max-w-6xl mx-auto px-4 py-20 sm:py-28 text-center">
            <p className="inline-block px-3 py-1 rounded-full border border-sage/40 text-sage text-xs font-semibold tracking-widest mb-6">LIFE SIMULATOR • BROWSER • GRATIS MAIN</p>
            <h1 className="text-4xl sm:text-6xl font-black leading-tight tracking-tight">
              KOTA KITA<span className="text-sage">:</span> <span className="bg-gradient-to-r from-sand via-sage to-sand bg-clip-text text-transparent">Life Beyond</span>
            </h1>
            <p className="mt-4 text-lg sm:text-xl text-white/70 max-w-2xl mx-auto italic">&ldquo;A little life. A thousand possibilities.&rdquo;</p>
            <p className="mt-4 text-white/60 max-w-xl mx-auto">
              Mulai dari kamar kos sederhana dengan Rp150.000 di genggaman. Bangun kehidupanmu sendiri di distrik Arunika Tengah — bekerja, berteman, berdagang, atau sekadar menikmati hujan sore.
            </p>
            <div className="mt-8 flex flex-col sm:flex-row gap-3 justify-center">
              <a href="#/play" className="px-8 py-4 rounded-xl bg-sage text-[#12141A] font-extrabold text-lg hover:bg-sage transition shadow-lg shadow-sage/20">
                ▶ Mainkan Sekarang
              </a>
              <a href="#/store" className="px-8 py-4 rounded-xl bg-white/10 border border-white/15 font-bold text-lg hover:bg-white/15 transition">
                Top Up Arunika Gems
              </a>
            </div>
          </div>
        </section>

        {/* Preview strip */}
        <section className="max-w-6xl mx-auto px-4 pb-16">
          <div className="rounded-2xl border border-white/10 bg-gradient-to-br from-[#191C23] to-[#14171D] p-4 sm:p-6">
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              {[
                { src: "/game/assets/b_warung.png", label: "Warung Bu Sari" },
                { src: "/game/assets/b_kos.png", label: "Kos Arunika" },
                { src: "/game/assets/p_gerobak.png", label: "Gerobak Jefri" },
                { src: "/game/assets/p_fountain.png", label: "Taman Kota" },
              ].map((it) => (
                <figure key={it.label} className="rounded-xl bg-[#12141A] border border-white/10 p-3 flex flex-col items-center gap-2">
                  <img src={it.src} alt={it.label} className="h-24 object-contain" style={{ imageRendering: "pixelated" }} />
                  <figcaption className="text-xs text-white/60">{it.label}</figcaption>
                </figure>
              ))}
            </div>
          </div>
        </section>

        {/* Fitur */}
        <section className="max-w-6xl mx-auto px-4 pb-20">
          <h2 className="text-2xl sm:text-3xl font-extrabold mb-8">Apa yang menantimu?</h2>
          <div className="grid sm:grid-cols-2 gap-4">
            {FEATURES.map((f) => (
              <article key={f.title} className="rounded-2xl border border-white/10 bg-[#191C23] p-6 hover:border-sage/40 transition">
                <span className="text-xs font-bold tracking-widest text-sage">{f.tag}</span>
                <h3 className="mt-2 text-xl font-bold">{f.title}</h3>
                <p className="mt-2 text-white/60 leading-relaxed">{f.desc}</p>
              </article>
            ))}
          </div>
        </section>

        {/* CTA store */}
        <section className="max-w-6xl mx-auto px-4 pb-24">
          <div className="rounded-2xl border border-sand/30 bg-gradient-to-r from-sand/10 via-transparent to-sage/10 p-8 sm:p-12 flex flex-col sm:flex-row items-center justify-between gap-6">
            <div>
              <h2 className="text-2xl font-extrabold">Arunika Gems</h2>
              <p className="text-white/60 mt-1 max-w-lg">Skin eksklusif, dekorasi premium, dan item kenyamanan — tanpa loot box, tanpa keuntungan gameplay berbayar. Saldo &amp; riwayat tersinkron dengan akunmu.</p>
            </div>
            <a href="#/store" className="shrink-0 px-8 py-4 rounded-xl bg-sand text-[#12141A] font-extrabold hover:bg-sand-deep transition">Buka KOTA KITA STORE</a>
          </div>
        </section>
      </main>

      <footer className="border-t border-white/10 mt-auto">
        <div className="max-w-6xl mx-auto px-4 py-8 flex flex-col sm:flex-row items-center justify-between gap-4 text-sm text-white/50">
          <p>© {new Date().getFullYear()} KOTA KITA: Life Beyond. Sebuah simulasi fiksi.</p>
          <div className="flex gap-4">
            <a href="#/store/terms" className="hover:text-white">Syarat &amp; Ketentuan</a>
            <a href="#/store/privacy" className="hover:text-white">Privasi</a>
            <a href="#/store/help" className="hover:text-white">Bantuan</a>
          </div>
        </div>
      </footer>
    </div>
  );
}
