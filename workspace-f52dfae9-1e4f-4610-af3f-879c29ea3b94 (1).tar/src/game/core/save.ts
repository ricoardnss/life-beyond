// Save/Load — 3 slot: LocalStorage (offline) + sinkronisasi server saat login.
import { SAVE_SLOTS, SAVE_VERSION } from "./constants";
import { state, newGameState } from "./state";
import { bus, EV } from "./bus";
import { toast } from "../systems/systems";
import type { GameState } from "./types";
import { authHeaders } from "@/lib/client-session";

const KEY_PREFIX = "kk_save_slot_";
const META_PREFIX = "kk_meta_slot_";

export interface SlotMeta {
  slot: number;
  name: string;
  day: number;
  money: number;
  savedAt: number;
  from: "lokal" | "server";
}

function serialize(s: GameState): string {
  return JSON.stringify(s);
}

/** Ekspos untuk pengujian */
export function serializeSlot(s: GameState): string {
  return serialize(s);
}

/** Ekspos untuk pengujian */
export function deserializeSlot(raw: string): GameState | null {
  return deserialize(raw);
}

function deserialize(raw: string): GameState | null {
  try {
    const data = JSON.parse(raw);
    if (!data || typeof data !== "object") return null;
    // migrasi skema sederhana: merge ke default agar field baru terisi
    const base = newGameState(String(data.playerName ?? "Pendatang"));
    const merged: GameState = {
      ...base,
      ...data,
      needs: { ...base.needs, ...(data.needs ?? {}) },
      stats: { ...base.stats, ...(data.stats ?? {}) },
      jobs: { ...base.jobs, ...(data.jobs ?? {}) },
      inventory: Array.isArray(data.inventory) && data.inventory.length === base.inventory.length ? data.inventory : base.inventory,
      version: SAVE_VERSION,
    };
    if (typeof merged.money !== "number" || !isFinite(merged.money)) merged.money = base.money;
    return merged;
  } catch {
    return null;
  }
}

export function listSlots(): (SlotMeta | null)[] {
  const out: (SlotMeta | null)[] = [];
  for (let i = 1; i <= SAVE_SLOTS; i++) {
    const raw = localStorage.getItem(META_PREFIX + i);
    if (raw) {
      try {
        out.push(JSON.parse(raw));
        continue;
      } catch { /* korup: abaikan */ }
    }
    out.push(null);
  }
  return out;
}

export async function saveGame(slot: number, syncServer = true): Promise<boolean> {
  const s = state.get();
  const raw = serialize(s);
  const meta: SlotMeta = { slot, name: s.playerName, day: s.day, money: s.money, savedAt: Date.now(), from: "lokal" };
  try {
    localStorage.setItem(KEY_PREFIX + slot, raw);
    localStorage.setItem(META_PREFIX + slot, JSON.stringify(meta));
  } catch {
    toast("Gagal menyimpan ke penyimpanan lokal (penuh?)", "peringatan");
  }
  let serverOk = false;
  if (syncServer) {
    try {
      const res = await fetch("/api/saves", {
        method: "POST",
        headers: { "Content-Type": "application/json", ...authHeaders() },
        credentials: "include",
        body: JSON.stringify({ slot, data: raw }),
      });
      if (res.ok) serverOk = true;
    } catch {
      serverOk = false;
    }
  }
  toast(serverOk ? `Tersimpan di slot ${slot} (lokal + akun).` : `Tersimpan di slot ${slot} (lokal).`, "sukses");
  bus.emit(EV.SAVED, { slot });
  return true;
}

export async function loadGame(slot: number): Promise<GameState | null> {
  // coba server dulu (lebih baru?), lalu lokal — pilih yang terbaru
  let best: { raw: string; savedAt: number } | null = null;
  const localRaw = localStorage.getItem(KEY_PREFIX + slot);
  if (localRaw) {
    const metaRaw = localStorage.getItem(META_PREFIX + slot);
    const savedAt = metaRaw ? (JSON.parse(metaRaw)?.savedAt ?? 0) : 0;
    best = { raw: localRaw, savedAt };
  }
  try {
    const res = await fetch(`/api/saves?slot=${slot}`, { credentials: "include", headers: authHeaders() });
    if (res.ok) {
      const j = await res.json();
      if (j?.data && (!best || j.savedAt > best.savedAt)) best = { raw: j.data, savedAt: j.savedAt };
    }
  } catch { /* offline: pakai lokal */ }
  if (!best) return null;
  const parsed = deserialize(best.raw);
  if (!parsed) {
    toast("Data slot rusak dan tidak bisa dimuat.", "peringatan");
    return null;
  }
  state.set(parsed);
  return parsed;
}

export function deleteSlot(slot: number) {
  localStorage.removeItem(KEY_PREFIX + slot);
  localStorage.removeItem(META_PREFIX + slot);
}

export function pullServerSlots(): Promise<SlotMeta[]> {
  return fetch("/api/saves", { credentials: "include", headers: authHeaders() })
    .then((r) => (r.ok ? r.json() : []))
    .then((rows) =>
      (rows ?? []).map((r: { slot: number; data: string; savedAt: number; playedAt?: string }) => {
        let name = "—", day = 1, money = 0;
        try {
          const d = JSON.parse(r.data);
          name = d.playerName; day = d.day; money = d.money;
        } catch { /* abaikan */ }
        return { slot: r.slot, name, day, money, savedAt: r.savedAt, from: "server" as const };
      })
    )
    .catch(() => []);
}

// autosave saat tidur dipanggil dari scene
export function autoSaveOnSleep() {
  // simpan ke slot terakhir yang dipakai (di flag)
  const last = Number(localStorage.getItem("kk_last_slot") || 1);
  saveGame(last, true);
}
