// State global game — satu sumber kebenaran; UI React berlangganan perubahan.
import { INV_SLOTS, SAVE_VERSION, START_MONEY } from "./constants";
import { bus, EV } from "./bus";
import type { GameState, JobId, Needs } from "./types";

export function rupiah(n: number): string {
  const neg = n < 0;
  const s = Math.abs(Math.round(n)).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ".");
  return `${neg ? "-" : ""}Rp${s}`;
}

export function timeStr(min: number): string {
  const h = Math.floor(min / 60) % 24;
  const m = Math.floor(min % 60);
  return `${h.toString().padStart(2, "0")}.${m.toString().padStart(2, "0")}`;
}

export function dayName(day: number): string {
  const names = ["Senin", "Selasa", "Rabu", "Kamis", "Jumat", "Sabtu", "Minggu"];
  return names[(day - 1) % 7];
}

export function weatherName(w: GameState["weather"]): string {
  return { cerah: "Cerah", berawan: "Berawan", hujan: "Hujan", badai: "Badai", kabut: "Kabut", salju: "Salju" }[w];
}

export function seasonName(s: GameState["season"]): string {
  return { semi: "Musim Semi", panas: "Musim Panas", gugur: "Musim Gugur", dingin: "Musim Dingin" }[s];
}

export function seasonIcon(s: GameState["season"]): string {
  return { semi: "❀", panas: "☀", gugur: "❦", dingin: "❄" }[s];
}

export function newNeeds(): Needs {
  return { lapar: 80, energi: 90, kebersihan: 85, mood: 75 };
}

export function emptyInventory(): (GameState["inventory"][number])[] {
  return Array.from({ length: INV_SLOTS }, () => null);
}

export function defaultJobs(): GameState["jobs"] {
  const mk = () => ({ level: 1, exp: 0, shiftsDone: 0, totalEarned: 0 });
  return { warung: mk(), kurir: mk(), minimarket: mk() };
}

export function newGameState(playerName: string): GameState {
  return {
    version: SAVE_VERSION,
    playerName,
    outfit: "default",
    money: START_MONEY,
    needs: newNeeds(),
    day: 1,
    timeMin: 7 * 60,
    weather: "cerah",
    season: "semi",
    inventory: emptyInventory(),
    relationships: {},
    quests: {},
    activeQuests: [],
    jobs: defaultJobs(),
    shift: null,
    flags: {},
    furniture: [
      { uid: "bed0", itemId: "furn_bed", tx: 2, ty: 2 },
      { uid: "ward0", itemId: "furn_wardrobe", tx: 10, ty: 2 },
      { uid: "desk0", itemId: "furn_desk", tx: 4, ty: 2 },
      { uid: "chair0", itemId: "furn_chair", tx: 4, ty: 3 },
      { uid: "fan0", itemId: "furn_fan", tx: 8, ty: 2 },
      { uid: "rug0", itemId: "furn_rug", tx: 6, ty: 5 },
      { uid: "lamp0", itemId: "furn_lamp", tx: 1, ty: 7 },
      { uid: "plant0", itemId: "furn_plant", tx: 11, ty: 7 },
    ],
    ledger: [],
    phone: [],
    phoneSeen: 0,
    stats: {
      daysPlayed: 1, moneyEarned: 0, moneySpent: 0, shiftsWorked: 0, deliveriesDone: 0,
      mealsEaten: 0, itemsBought: 0, trashCollected: 0, chatCount: 0, giftsGiven: 0,
      distanceWalked: 0, questsDone: 0, rainWalked: 0, friendsMax: 0, datesGone: 0,
    },
    achievements: [],
    scene: null,
    lastSleepDay: 0,
    weeklyRentPaidDay: 0,
  };
}

let _state: GameState = newGameState("Arunika");
let _listeners = new Set<() => void>();
let _notifyQueued = false;

export const state = {
  get(): GameState {
    return _state;
  },
  set(s: GameState) {
    _state = s;
    notify();
  },
  reset(name: string) {
    _state = newGameState(name);
    notify();
  },
  touch() {
    notify();
  },
};

function notify() {
  bus.emit(EV.STATE_CHANGED);
  if (_notifyQueued) return;
  _notifyQueued = true;
  queueMicrotask(() => {
    _notifyQueued = false;
    _listeners.forEach((fn) => fn());
  });
}

export function subscribe(fn: () => void): () => void {
  _listeners.add(fn);
  return () => _listeners.delete(fn);
}

export function getSnapshot(): GameState {
  return _state;
}

export function jobIdLabel(id: JobId): string {
  return { warung: "Pegawai Warung", kurir: "Kurir", minimarket: "Pegawai Minimarket" }[id];
}
