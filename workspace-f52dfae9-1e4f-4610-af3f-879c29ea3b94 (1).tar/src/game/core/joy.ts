// Vektor joystick virtual — fungsi murni agar mudah diuji.
// Koordinat layar -> vektor arah ternormalisasi dengan deadzone.

export interface JoyInput {
  /** pusat joystick (px) */
  cx: number;
  cy: number;
  /** posisi jari (px) */
  x: number;
  y: number;
  /** radius maksimum knobs dari pusat (px) */
  radius: number;
  /** 0..1 — gerak di bawah ini dianggap nol */
  deadzone?: number;
}

export interface JoyVec {
  x: number;
  y: number;
}

/** Hitung vektor joystick: besar output naik halus dari deadzone ke tepi radius (maks 1). */
export function joyVector(inp: JoyInput): JoyVec {
  const dz = inp.deadzone ?? 0.12;
  const dx = inp.x - inp.cx;
  const dy = inp.y - inp.cy;
  const d = Math.hypot(dx, dy);
  if (d <= 1e-6) return { x: 0, y: 0 };
  const mag = d / inp.radius; // jari relatif radius (0..∞)
  if (mag <= dz) return { x: 0, y: 0 };
  // besar keluaran: 0 pada deadzone -> 1 pada/lewat tepi radius
  const out = Math.min(1, (mag - dz) / (1 - dz));
  return { x: (dx / d) * out, y: (dy / d) * out };
}

/** Posisi knob visual (px relatif pusat), selalu di dalam radius. */
export function knobOffset(inp: JoyInput): JoyVec {
  let dx = inp.x - inp.cx;
  let dy = inp.y - inp.cy;
  const d = Math.hypot(dx, dy);
  if (d > inp.radius) {
    dx = (dx / d) * inp.radius;
    dy = (dy / d) * inp.radius;
  }
  return { x: dx, y: dy };
}
