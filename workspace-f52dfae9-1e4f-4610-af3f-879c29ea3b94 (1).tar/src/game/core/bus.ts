// Bus event ringan: jembatan Phaser <-> React UI <-> sistem.
type Handler = (payload?: unknown) => void;

class EventBus {
  private map = new Map<string, Set<Handler>>();

  on(evt: string, fn: Handler): () => void {
    if (!this.map.has(evt)) this.map.set(evt, new Set());
    this.map.get(evt)!.add(fn);
    return () => this.off(evt, fn);
  }

  off(evt: string, fn: Handler) {
    this.map.get(evt)?.delete(fn);
  }

  emit(evt: string, payload?: unknown) {
    this.map.get(evt)?.forEach((fn) => {
      try {
        fn(payload);
      } catch (e) {
        console.error(`[bus] error handler ${evt}`, e);
      }
    });
  }

  clear() {
    this.map.clear();
  }
}

export const bus = new EventBus();

// Ekspos untuk pengujian otomatis & debugging browser (aman: read/emit UI saja)
if (typeof window !== "undefined") {
  (window as unknown as { __kkBus: EventBus }).__kkBus = bus;
}

// Nama event terpusat agar tidak ada typo lintas file.
export const EV = {
  STATE_CHANGED: "state_changed",
  OPEN_PANEL: "open_panel", // inventory|phone|journal|map|menu|shop|dialog|settings|minigame|sleep
  CLOSE_PANEL: "close_panel",
  DIALOG: "dialog", // {npcId, lines, options}
  TOAST: "toast", // {text, kind}
  INTERACT_HINT: "interact_hint", // string | null
  TRANSITION: "transition",
  JOB_MINIGAME: "job_minigame", // {jobId}
  SHOP_OPEN: "shop_open", // {shopId}
  WARDROBE_OPEN: "wardrobe_open",
  FURNITURE_MODE: "furniture_mode", // {itemId} | null
  SAVED: "saved",
  QUIT_TO_MENU: "quit_to_menu",
  GAME_READY: "game_ready",
  AUTH_CHANGED: "auth_changed",
} as const;
