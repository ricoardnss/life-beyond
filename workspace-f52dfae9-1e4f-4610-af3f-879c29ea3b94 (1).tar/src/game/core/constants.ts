// Konstanta tuning gameplay — semua angka ekonomi/waktu terpusat di sini (Bagian D-4).
export const SAVE_VERSION = 1;
export const INV_SLOTS = 24;
export const START_MONEY = 150_000;
export const RENT_COST = 25_000; // sewa kos per 7 hari (dikurangi otomatis pagi hari ke-8, 15, dst)
export const RENT_INTERVAL = 7;
export const SAVE_SLOTS = 3;

// Musim: setiap 7 hari game ganti musim — semi → panas → gugur → dingin → ...
export const SEASON_DAYS = 7;
export const SEASON_ORDER = ["semi", "panas", "gugur", "dingin"] as const;

// Waktu: 1 hari game = 18 menit nyata -> 1440 menit game / 1080 detik
export const REAL_SECONDS_PER_DAY = 18 * 60;
export const GAME_MIN_PER_REAL_SEC = 1440 / REAL_SECONDS_PER_DAY; // ≈1.333
export const SLEEP_WAKE_HOUR = 7;

// Peluruhan kebutuhan per jam game
export const DECAY = {
  lapar: 5.5,
  energi: 4.2,
  kebersihan: 3.2,
  mood: 2.6,
};
export const RUN_ENERGY_COST = 9.0; // extra per jam saat berlari
export const WALK_ENERGY_COST = 1.2;

// Ambang efek kebutuhan
export const LOW = {
  lapar: 20, // di bawah: kecepatan -25%, mood turun cepat
  energi: 15, // di bawah: tidak bisa lari / kerja berat
  kebersihan: 25, // di bawah: NPC respons menurun
  mood: 20, // di bawah: gain relasi -50%
};

// Batas interaksi sosial per NPC per hari
export const CHAT_LIMIT = 3;
export const GIFT_LIMIT = 1;
export const CHAT_GAIN = [7, 6, 4, 3, 2]; // gain per stage (makin akrab makin lambat)
export const GIFT_GAIN_LIKE = 12;
export const GIFT_GAIN_NEUTRAL = 6;
export const GIFT_GAIN_DISLIKE = -4;

// Peta
export const TILE = 32;
export const MAP_W = 60;
export const MAP_H = 40;
export const PLAYER_SPEED = 92; // px/detik
export const RUN_MULT = 1.55;

// Relasi
export const STAGES: { id: import("./types").RelationStage; name: string; min: number }[] = [
  { id: "tidak_kenal", name: "Belum Kenal", min: 0 },
  { id: "kenalan", name: "Kenalan", min: 10 },
  { id: "teman", name: "Teman", min: 30 },
  { id: "teman_dekat", name: "Teman Dekat", min: 60 },
  { id: "sahabat", name: "Sahabat", min: 80 },
];

export function stageOf(score: number) {
  let cur = STAGES[0];
  for (const s of STAGES) if (score >= s.min) cur = s;
  return cur;
}

// ---------- Musim & cuaca ----------
export function seasonOf(day: number): import("./types").Season {
  return SEASON_ORDER[Math.floor((day - 1) / SEASON_DAYS) % SEASON_ORDER.length];
}

export function dayOfSeason(day: number): number {
  return ((day - 1) % SEASON_DAYS) + 1;
}

/** Peluang cuaca per musim — dipakai onNewDay/sleep. */
export const WEATHER_TABLE: Record<import("./types").Season, [import("./types").Weather, number][]> = {
  semi: [["cerah", 0.42], ["berawan", 0.24], ["hujan", 0.16], ["kabut", 0.14], ["badai", 0.04], ["salju", 0]],
  panas: [["cerah", 0.62], ["berawan", 0.16], ["hujan", 0.08], ["badai", 0.1], ["kabut", 0.04], ["salju", 0]],
  gugur: [["cerah", 0.3], ["berawan", 0.28], ["hujan", 0.22], ["kabut", 0.16], ["badai", 0.04], ["salju", 0]],
  dingin: [["cerah", 0.24], ["berawan", 0.24], ["hujan", 0.1], ["kabut", 0.16], ["salju", 0.24], ["badai", 0.02]],
};

export function rollWeather(season: import("./types").Season): import("./types").Weather {
  const table = WEATHER_TABLE[season];
  let r = Math.random();
  for (const [w, p] of table) {
    if (r < p) return w;
    r -= p;
  }
  return "cerah";
}

// ---------- Pacaran (romansa) ----------
export const ROMANCE = {
  MIN_SCORE: 85, // skor minimal agar pernyataan cinta diterima
  MOOD_MIN: 40, // mood minimal pemain saat menyatakan perasaan
  BREAK_BELOW: 30, // saat pacaran: skor di bawah ini -> putus otomatis
  DECAY_PER_DAY: 2, // skor berkurang per hari tanpa interaksi selama pacaran
  HEART_SCORE: 95, // ambang "hubungan makin serius"
  CHAT_MOOD_BONUS: 6, // bonus mood ekstra saat mengobrol dengan pacar
} as const;

export interface DateOptionDef {
  id: string;
  label: string;
  desc: string;
  cost: number;
  gain: number; // tambahan skor relasi
  mood: number;
  energi: number;
  lapar: number;
}

/** Opsi date — semua harga dari data ini (dipakai UI & logika, tidak ada hardcode ganda). */
export const DATE_OPTIONS: DateOptionDef[] = [
  { id: "santai", label: "Jalan Santai", desc: "Keliling taman sore sambil mengobrol ringan.", cost: 0, gain: 6, mood: 8, energi: -3, lapar: -2 },
  { id: "jajanan", label: "Jajanan Gerobak", desc: "Mampir ke gerobak Bang Jefri, kamu yang traktir.", cost: 15000, gain: 9, mood: 13, energi: -4, lapar: -4 },
  { id: "kafe", label: "Makan Malam Kafe", desc: "Meja dua di Kafe Arunika dengan menu spesial.", cost: 35000, gain: 13, mood: 18, energi: -5, lapar: -6 },
];

export const DATE_LIMIT_PER_DAY = 1;
