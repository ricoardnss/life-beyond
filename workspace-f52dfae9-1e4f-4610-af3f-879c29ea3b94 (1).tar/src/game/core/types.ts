// Tipe data inti KOTA KITA — dipakai game, sistem, UI, dan save.
export type Dir = "down" | "up" | "left" | "right";

export type Weather = "cerah" | "berawan" | "hujan" | "badai" | "kabut" | "salju";
export type Season = "semi" | "panas" | "gugur" | "dingin";

export interface ItemDef {
  id: string;
  name: string;
  desc: string;
  cat: "makanan" | "minuman" | "pakaian" | "furnitur" | "alat" | "bahan" | "khusus";
  icon: string; // id ikon di manifest ATAU key texture furnitur
  price: number; // harga beli (0 = tidak dijual)
  sell: number; // harga jual
  stack: number;
  effects?: Partial<Needs>;
  outfit?: string; // untuk pakaian: key outfit
  furniture?: string; // untuk furnitur: key sprite
  gemSku?: string; // item premium terkait
}

export interface Needs {
  lapar: number; // 0..100
  energi: number;
  kebersihan: number;
  mood: number;
}

export interface InvSlot {
  itemId: string;
  qty: number;
}

export type RelationStage = "tidak_kenal" | "kenalan" | "teman" | "teman_dekat" | "sahabat";

export interface Relationship {
  score: number; // 0..100
  stage: RelationStage;
  chatToday: number; // batas interaksi harian
  giftToday: number;
  lastDay: number;
  chatTotal?: number; // total obrolan sepanjang main — indeks topik agar percakapan nyambung
  dating?: boolean; // sedang pacaran (fitur romansa)
  sinceDay?: number; // hari mulai pacaran
  dateToday?: number; // jumlah date hari ini
}

export interface QuestObjective {
  id: string;
  desc: string;
  target?: number;
  count?: number;
}

export interface QuestDef {
  id: string;
  name: string;
  desc: string;
  type: "tutorial" | "sampingan";
  objectives: QuestObjective[];
  rewardMoney?: number;
  rewardItems?: { itemId: string; qty: number }[];
  rewardRelation?: { npcId: string; amount: number }[];
  unlockDay?: number;
  requires?: string[];
  autoComplete?: boolean; // selesai otomatis tanpa lapor NPC
  turnInAt?: string; // lapor ke NPC ini untuk klaim hadiah
  checkOnly?: boolean; // objektif dipantau tiap tick (mis. target uang)
}

export interface QuestProgress {
  status: "tersedia" | "aktif" | "selesai";
  counts: Record<string, number>;
  doneDay?: number;
}

export type JobId = "warung" | "kurir" | "minimarket";

export interface JobDef {
  id: JobId;
  name: string;
  employer: string;
  desc: string;
  startHour: number;
  endHour: number;
  wagePerShift: number;
  skillBonus: number; // per level skill (%)
  requireLevel: number;
  location: string; // poi key
  interior?: string;
}

export interface JobState {
  level: number; // 1..5
  exp: number;
  shiftsDone: number;
  totalEarned: number;
}

export type NpcActivity = "idle" | "walking" | "working" | "social" | "home" | "sleep";

export interface ScheduleBlock {
  from: number; // jam mulai
  to: number; // jam selesai
  poi: string; // key POI / interior
  activity: NpcActivity;
}

export interface NpcDef {
  id: string;
  name: string;
  tex: string; // key spritesheet
  personality: "ramah" | "praktis" | "kakar" | "lembut" | "ceria" | "pendiam";
  jobTitle: string;
  schedule: ScheduleBlock[];
  likes: string[]; // item id yang disukai
  dislikes: string[];
  homePoi: string;
  workInterior?: string;
  romanceable?: boolean; // bisa diajak pacaran
}

export interface LedgerEntry {
  id: number;
  day: number;
  time: number;
  label: string;
  amount: number; // + / -
}

export interface PhoneMessage {
  id: number;
  from: string; // npc id / "sistem" / "kerja"
  text: string;
  day: number;
  time: number;
  read: boolean;
}

export interface FurniturePlacement {
  uid: string;
  itemId: string;
  tx: number;
  ty: number;
}

export interface GameStats {
  daysPlayed: number;
  moneyEarned: number;
  moneySpent: number;
  shiftsWorked: number;
  deliveriesDone: number;
  mealsEaten: number;
  itemsBought: number;
  trashCollected: number;
  chatCount: number;
  giftsGiven: number;
  distanceWalked: number;
  questsDone: number;
  rainWalked: number;
  friendsMax: number;
  datesGone: number; // jumlah date dengan pacar
}

export interface AchievementDef {
  id: string;
  name: string;
  desc: string;
  check: (s: GameState) => boolean;
}

export interface GameFlags {
  [key: string]: number | boolean | string;
}

export interface GameState {
  version: number;
  playerName: string;
  outfit: string;
  money: number;
  needs: Needs;
  day: number;
  timeMin: number; // menit dalam hari 0..1439
  weather: Weather;
  season: Season;
  inventory: (InvSlot | null)[]; // 24 slot
  relationships: Record<string, Relationship>;
  quests: Record<string, QuestProgress>;
  activeQuests: string[];
  jobs: Record<JobId, JobState>;
  shift: { jobId: JobId; startedMin: number } | null;
  flags: GameFlags;
  furniture: FurniturePlacement[];
  ledger: LedgerEntry[];
  phone: PhoneMessage[];
  phoneSeen: number;
  stats: GameStats;
  achievements: string[];
  scene: { map: string; x: number; y: number } | null;
  lastSleepDay: number;
  weeklyRentPaidDay: number;
}
