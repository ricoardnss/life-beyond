// Bootstrap Phaser + kontrol pause & transisi.
import * as Phaser from "phaser";
import { BootScene } from "./scenes/BootScene";
import { WorldScene } from "./scenes/WorldScene";
import { InteriorScene } from "./scenes/InteriorScene";
import { state } from "./core/state";

let game: Phaser.Game | null = null;

export async function startGame(parent: HTMLElement): Promise<Phaser.Game> {
  if (game) {
    game.destroy(true);
    game = null;
  }
  const [{ BootScene }, { WorldScene }, { InteriorScene }] = await Promise.all([
    import("./scenes/BootScene"),
    import("./scenes/WorldScene"),
    import("./scenes/InteriorScene"),
  ]);
  game = new Phaser.Game({
    type: Phaser.AUTO,
    parent,
    width: 480,
    height: 270,
    pixelArt: true,
    roundPixels: true,
    backgroundColor: "#0b0e1a",
    scale: {
      mode: Phaser.Scale.FIT,
      autoCenter: Phaser.Scale.CENTER_BOTH,
    },
    render: {
      antialias: false,
      powerPreference: "high-performance",
    },
    scene: [BootScene, WorldScene, InteriorScene],
  });
  game.registry.set("savedScene", state.get().scene?.map ?? "outdoor");
  (window as unknown as { __kkGame?: Phaser.Game }).__kkGame = game;
  game.registry.set("paused", false);
  game.registry.set("joy", { x: 0, y: 0 });
  // Paksa ScaleManager menghitung ulang ukuran canvas terhadap parent —
  // mencegah canvas tampil pada ukuran native (kecil/tengah) bila layout
  // parent baru settle setelah game dibuat.
  game.events.once("ready", () => game?.scale.refresh());
  // Hook debug (hanya aktif dengan ?debug=1 di URL) — memudahkan verifikasi
  // cuaca/musim/waktu saat pengujian browser. Tidak memengaruhi pemain biasa.
  try {
    if (typeof window !== "undefined" && new URLSearchParams(window.location.search).get("debug") === "1") {
      void import("./core/constants").then(({ seasonOf, rollWeather }) => {
        (window as unknown as { __kkDebug?: object }).__kkDebug = {
          state,
          seasonOf,
          rollWeather,
          setWeather: (w: string) => {
            (state.get().weather as string) = w;
          },
          setSeason: (sn: string) => {
            (state.get().season as string) = sn;
          },
          setDay: (d: number) => {
            state.get().day = d;
            state.get().season = seasonOf(d);
          },
          setTime: (h: number) => {
            state.get().timeMin = h * 60;
          },
        };
      });
    }
  } catch { /* abaikan */ }
  // Jaminan tambahan: Phaser tidak selalu mem-poll ukuran parent elemen —
  // refresh eksplisit saat window berubah ukuran (maximize/rotate).
  // Double-RAF: tunggu layout selesai agar ukuran parent terbaru yang terbaca.
  let resizeRaf = 0;
  const onWinResize = () => {
    cancelAnimationFrame(resizeRaf);
    resizeRaf = requestAnimationFrame(() => {
      resizeRaf = requestAnimationFrame(() => game?.scale.refresh());
    });
  };
  window.addEventListener("resize", onWinResize);
  game.events.once("destroy", () => {
    cancelAnimationFrame(resizeRaf);
    window.removeEventListener("resize", onWinResize);
  });
  return game;
}

export function setPaused(p: boolean) {
  game?.registry.set("paused", p);
}

export function setJoy(x: number, y: number) {
  game?.registry.set("joy", { x, y });
}

/** Tombol LARI sentuh: true saat jari menahan tombol. */
export function setRun(v: boolean) {
  game?.registry.set("touchRun", v);
}

export function stopGame() {
  game?.destroy(true);
  game = null;
}

/** Scene awal berdasarkan save */
export function initialSceneKey(): { key: string; data?: Record<string, unknown> } {
  const s = state.get();
  if (s.scene && s.scene.map !== "outdoor") return { key: "InteriorScene", data: { id: s.scene.map } };
  return { key: "WorldScene" };
}
