// Registry aset & animasi — satu sumber kebenaran untuk preload + key.
import type * as PhaserNS from "phaser";

export const OUTFITS = ["default", "kaos_merah", "jaket_denim", "golden", "cyber", "sunset"] as const;
export const NPC_KEYS = [
  "bu_sari", "pak_budi", "dinda", "rian", "maya",
  "bang_jefri", "tante_wati", "mas_tony", "sinta", "om_hermanto",
  // 28 warga baru
  "chelsea", "rico", "akbar", "virly", "zaki", "pijar", "andini", "rahma",
  "aulia", "agata", "andika", "coco", "defriska", "vanesa", "yami", "asta",
  "yuno", "riski", "alip", "amar", "abi", "ali", "eka", "deka",
  "celyin", "sandra", "cindy", "syifa",
] as const;

export const CHAR_W = 32;
export const CHAR_H = 48;

export const IMAGE_KEYS = [
  "tileset_outdoor", "tileset_interior", "icons",
  "b_warung", "b_minimarket", "b_bengkel", "b_kafe", "b_kos", "b_house_a", "b_house_b", "b_house_c",
  "b_house_d", "b_house_e", "b_house_f", "b_house_g", "b_house_h", "b_house_i", "b_gazebo",
  "p_tree1", "p_tree2", "p_bush1", "p_bush2", "p_lamp", "p_bench", "p_trash1", "p_trash2",
  "p_chair_red", "p_chair_blue", "p_table", "p_motor", "p_fountain", "p_gerobak", "p_crate", "p_sign", "p_fence",
  "p_shower", "p_counter", "p_menu", "p_shelf", "p_fridge",
  "f_bed", "f_wardrobe", "f_desk", "f_pc", "f_chair", "f_fan", "f_rug", "f_plant", "f_lamp", "f_neon", "f_minifan",
  "cat",
];

export const AUDIO_KEYS = [
  "music_day", "music_night", "rain", "thunder",
  "sfx_step", "sfx_door", "sfx_coin", "sfx_click", "sfx_eat", "sfx_success", "sfx_fail", "sfx_notify", "sfx_pop", "sfx_reject",
];

export const ICON_ORDER = [
  "nasi_goreng", "ayam_geprek", "mie_instan", "roti", "nasi_bungkus", "jus_jeruk", "es_teh", "kopi",
  "air_botol", "telur", "cabai", "beras", "sabun", "obat", "buku", "sketchbook",
  "kaos", "jaket", "paket", "sparepart", "sampah", "kucing", "hadiah_bunga", "hadiah_kue",
];

export function iconFrame(iconId: string): number {
  const i = ICON_ORDER.indexOf(iconId);
  return i < 0 ? 0 : i;
}

export function charTex(kind: string): string {
  return kind.startsWith("npc_") ? `npc_${kind.slice(4)}` : `player_${kind}`;
}

export function createCharacterAnims(scene: PhaserNS.Scene, tex: string) {
  const dirs = ["down", "right", "up", "left"] as const;
  for (const d of dirs) {
    const row = { down: 0, right: 1, up: 2, left: 3 }[d];
    const base = row * 4;
    if (!scene.anims.exists(`${tex}_walk_${d}`)) {
      scene.anims.create({
        key: `${tex}_walk_${d}`,
        frames: scene.anims.generateFrameNumbers(tex, { frames: [base + 1, base + 2, base + 3, base + 2] }),
        frameRate: 9,
        repeat: -1,
      });
    }
    if (!scene.anims.exists(`${tex}_idle_${d}`)) {
      scene.anims.create({
        key: `${tex}_idle_${d}`,
        frames: [{ key: tex, frame: base }],
        frameRate: 1,
      });
    }
  }
}

// Palet langit siang-malam (warna overlay multiply)
export function dayNightTint(hour: number): { color: number; alpha: number } {
  // pagi 5-7 lembut, siang 7-16 cerah, sore 16-19 hangat, malam 19-5 biru gelap
  if (hour >= 6 && hour < 16) return { color: 0xffffff, alpha: 0 };
  if (hour >= 16 && hour < 18) return { color: 0xffd9a8, alpha: 0.16 };
  if (hour >= 18 && hour < 19.5) return { color: 0xe8a06a, alpha: 0.24 };
  if (hour >= 19.5 || hour < 4.5) return { color: 0x35406e, alpha: 0.42 };
  return { color: 0x9aa8d8, alpha: 0.24 }; // 4.5-6 subuh
}

export function isNight(hour: number): boolean {
  return hour >= 19 || hour < 5;
}

// ---------- Musim: tint dunia (tanah, dedaunan, udara) ----------
export interface SeasonLook {
  groundTint: number; // warna layer tanah
  groundAlpha: number;
  leafTint: number; // warna tajuk pohon
  skyTint: number; // overlay udara lembut (multiply)
  skyAlpha: number;
}

export const SEASON_LOOK: Record<string, SeasonLook> = {
  semi: { groundTint: 0x9fd8a0, groundAlpha: 0.14, leafTint: 0xbfe8a8, skyTint: 0xfff4dc, skyAlpha: 0.05 },
  panas: { groundTint: 0xffe9a8, groundAlpha: 0.16, leafTint: 0xcfe088, skyTint: 0xffe0b0, skyAlpha: 0.08 },
  gugur: { groundTint: 0xe8a060, groundAlpha: 0.2, leafTint: 0xe89850, skyTint: 0xe8b080, skyAlpha: 0.1 },
  dingin: { groundTint: 0xd8e8ff, groundAlpha: 0.3, leafTint: 0xc0d8e8, skyTint: 0xbcd0e8, skyAlpha: 0.12 },
};

/** Tambahan overlay cuaca di atas tint musim (multiply). */
export function weatherTint(weather: string): { color: number; alpha: number } {
  switch (weather) {
    case "berawan": return { color: 0xa8b0bc, alpha: 0.16 };
    case "hujan": return { color: 0x8a94a8, alpha: 0.2 };
    case "badai": return { color: 0x5a6278, alpha: 0.3 };
    case "kabut": return { color: 0xd8dce4, alpha: 0.3 };
    case "salju": return { color: 0xd0dcec, alpha: 0.16 };
    default: return { color: 0xffffff, alpha: 0 };
  }
}
