// Furnitur — penempatan di kamar kos dengan validasi collision.
import { state } from "../core/state";
import { INTERIORS } from "../data/mapdata";
import { item } from "../data/items";
import { toast } from "./systems";
import { removeItem, addItem } from "./inventory";
import { checkQuestObjective } from "./quests";
import { bus, EV } from "../core/bus";
import type { FurniturePlacement } from "../core/types";

const KOS = INTERIORS.kos;

function footprint(itemId: string): { w: number; h: number } {
  // ukuran tile furnitur
  switch (itemId) {
    case "furn_bed": return { w: 2, h: 2 };
    case "furn_wardrobe": return { w: 1, h: 2 };
    case "furn_desk": return { w: 2, h: 1 };
    case "furn_fan": return { w: 1, h: 1 };
    case "furn_chair": return { w: 1, h: 1 };
    case "furn_rug": return { w: 2, h: 2 };
    case "furn_plant": return { w: 1, h: 1 };
    case "furn_lamp": return { w: 1, h: 1 };
    default: return { w: 1, h: 1 };
  }
}

function blockedTiles(): Set<string> {
  const blocked = new Set<string>();
  // dinding: 2 baris atas
  for (let x = 0; x < KOS.w; x++) {
    blocked.add(`${x},0`);
    blocked.add(`${x},1`);
  }
  // fixture bawaan (shower dsb) selalu solid
  for (const fx of KOS.fixtures) {
    if (fx.interact === "bed" || fx.interact === "wardrobe" || fx.interact === "desk") continue; // akan digantikan furniture player
    if (fx.solid) blocked.add(`${fx.tx},${fx.ty}`);
  }
  // exit
  blocked.add(`${KOS.exitTile[0]},${KOS.exitTile[1]}`);
  return blocked;
}

export function canPlace(itemId: string, tx: number, ty: number, ignoreUid?: string): boolean {
  const fp = footprint(itemId);
  const blocked = blockedTiles();
  for (let y = ty; y < ty + fp.h; y++) {
    for (let x = tx; x < tx + fp.w; x++) {
      if (x < 0 || y < 0 || x >= KOS.w || y >= KOS.h) return false;
      if (y < 2) return false; // dinding
      if (blocked.has(`${x},${y}`)) return false;
      // tumpang tindih furnitur lain
      for (const f of state.get().furniture) {
        if (ignoreUid && f.uid === ignoreUid) continue;
        const f2 = footprint(f.itemId);
        if (x >= f.tx && x < f.tx + f2.w && y >= f.ty && y < f.ty + f2.h) return false;
      }
    }
  }
  return true;
}

export function placeFurniture(itemId: string, tx: number, ty: number): boolean {
  const s = state.get();
  if (!item(itemId).furniture) return false;
  if (countInv(itemId) <= 0) {
    toast("Kamu tidak punya furnitur itu.", "peringatan");
    return false;
  }
  if (!canPlace(itemId, tx, ty)) {
    toast("Tidak bisa ditempatkan di situ (bentrok/halangan).", "peringatan");
    return false;
  }
  if (!removeItem(itemId, 1)) return false;
  const uid = `f${Date.now()}${Math.floor(Math.random() * 1000)}`;
  s.furniture.push({ uid, itemId, tx, ty });
  checkQuestObjective("place_furniture", 1);
  bus.emit(EV.STATE_CHANGED);
  return true;
}

export function moveFurniture(uid: string, tx: number, ty: number): boolean {
  const s = state.get();
  const f = s.furniture.find((f) => f.uid === uid);
  if (!f) return false;
  if (f.tx === tx && f.ty === ty) return true;
  if (!canPlace(f.itemId, tx, ty, uid)) {
    toast("Tidak bisa dipindah ke situ.", "peringatan");
    return false;
  }
  f.tx = tx;
  f.ty = ty;
  bus.emit(EV.STATE_CHANGED);
  return true;
}

export function removeFurniture(uid: string): boolean {
  const s = state.get();
  const idx = s.furniture.findIndex((f) => f.uid === uid);
  if (idx < 0) return false;
  const f = s.furniture[idx];
  if (addItem(f.itemId, 1)) {
    s.furniture.splice(idx, 1);
    bus.emit(EV.STATE_CHANGED);
    return true;
  }
  return false;
}

function countInv(itemId: string): number {
  return state.get().inventory.reduce((n, sl) => (sl && sl.itemId === itemId ? n + sl.qty : n), 0);
}

export function kosSolidTiles(): Set<string> {
  const s = state.get();
  const solid = new Set<string>();
  for (let x = 0; x < KOS.w; x++) {
    solid.add(`${x},0`);
    solid.add(`${x},1`);
  }
  for (const fx of KOS.fixtures) {
    if (["bed", "wardrobe", "desk"].includes(fx.interact ?? "")) continue;
    if (fx.solid) solid.add(`${fx.tx},${fx.ty}`);
  }
  for (const f of s.furniture) {
    if (f.itemId === "furn_rug") continue; // karpet bisa dilewati
    const fp = footprint(f.itemId);
    for (let y = f.ty; y < f.ty + fp.h; y++) for (let x = f.tx; x < f.tx + fp.w; x++) solid.add(`${x},${y}`);
  }
  return solid;
}

export type { FurniturePlacement };
