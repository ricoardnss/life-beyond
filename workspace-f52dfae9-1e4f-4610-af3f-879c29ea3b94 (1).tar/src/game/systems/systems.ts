// Sistem inti: waktu, kebutuhan, cuaca+musim, ekonomi (ledger), pencapaian.
import { DECAY, LOW, RENT_COST, RENT_INTERVAL, ROMANCE, RUN_ENERGY_COST, WALK_ENERGY_COST, rollWeather, seasonOf } from "../core/constants";
import { bus, EV } from "../core/bus";
import { state } from "../core/state";
import type { GameState, Relationship } from "../core/types";
import { NPCS } from "../data/npcs";
import { checkQuestObjective } from "./quests";
import { ACHIEVEMENTS } from "./achievements";
import { SLEEP_WAKE_HOUR } from "../core/constants";

export function toast(text: string, kind: "info" | "sukses" | "peringatan" = "info") {
  bus.emit(EV.TOAST, { text, kind });
}

// ---------- Waktu ----------
export function currentHour(s: GameState = state.get()): number {
  return Math.floor(s.timeMin / 60) % 24;
}

export function tickTime(dtRealSec: number, gameMinPerSec: number) {
  const s = state.get();
  const before = s.timeMin;
  const next = s.timeMin + dtRealSec * gameMinPerSec;
  s.timeMin = next;
  // pergantian hari
  if (Math.floor(next / 1440) > Math.floor(before / 1440) || next >= 1440) {
    if (next >= 1440) {
      s.timeMin -= 1440;
      onNewDay();
    }
  }
  // rent mingguan diproses pagi hari ke-8, 15, ...
  if (s.day % RENT_INTERVAL === 1 && s.day > RENT_INTERVAL && s.weeklyRentPaidDay !== s.day && s.timeMin >= 60) {
    s.weeklyRentPaidDay = s.day;
    payRent();
  }
}

/** Romansa: peluruhan relasi pacar tanpa interaksi + putus otomatis bila terlalu dingin. */
function tickRomance(s: GameState) {
  for (const [id, r] of Object.entries(s.relationships)) {
    if (!r.dating) continue;
    if (r.score < ROMANCE.BREAK_BELOW) {
      endDating(s, id, r, "jarang ditemui");
    } else if (r.lastDay < s.day) {
      r.score = Math.max(0, r.score - ROMANCE.DECAY_PER_DAY);
    }
  }
}

function endDating(s: GameState, id: string, r: Relationship, why: string) {
  r.dating = false;
  r.sinceDay = undefined;
  r.dateToday = 0;
  delete s.flags[`pacar_${id}`];
  applyNeeds({ mood: -14 });
  pushPhone(id, "Aku pikir akhir-akhir ini kita mulai jauh... Mungkin lebih baik berhenti di sini. Jaga dirimu, ya.", "sistem");
  const npc = NPCS.find((n) => n.id === id);
  toast(`Kamu dan ${npc?.name ?? id} putus (${why}).`, "peringatan");
}

export function onNewDay() {
  const s = state.get();
  s.day += 1;
  s.stats.daysPlayed = s.day;
  // romansa dulu (sebelum lastDay direset ke hari baru)
  tickRomance(s);
  // reset batas interaksi harian NPC
  for (const k of Object.keys(s.relationships)) {
    const r = s.relationships[k];
    if (r.lastDay !== s.day) {
      r.chatToday = 0;
      r.giftToday = 0;
      r.lastDay = s.day;
    }
  }
  // pergantian musim otomatis tiap SEASON_DAYS hari
  const prevSeason = s.season;
  s.season = seasonOf(s.day);
  // cuaca harian mengikuti musim
  s.weather = rollWeather(s.season);
  const WN: Record<string, string> = { cerah: "Cerah", berawan: "Berawan", hujan: "Hujan", badai: "Badai", kabut: "Kabut", salju: "Salju" };
  if (prevSeason !== s.season) {
    const SN: Record<string, string> = { semi: "Musim Semi", panas: "Musim Panas", gugur: "Musim Gugur", dingin: "Musim Dingin" };
    toast(`Hari ${s.day} — ${SN[s.season]} tiba! Cuaca: ${WN[s.weather]}`);
    pushPhone("sistem", `Musim berganti menjadi ${SN[s.season]}. Kota Arunika tampil dengan wajah baru!`, "sistem");
  } else {
    toast(`Hari ${s.day} dimulai. Cuaca: ${WN[s.weather]}`);
  }
  checkQuestObjective("day_pass", 1);
}

function payRent() {
  const s = state.get();
  if (s.money >= RENT_COST) {
    s.money -= RENT_COST;
    s.stats.moneySpent += RENT_COST;
    addLedger("Sewa kos mingguan", -RENT_COST);
    toast(`Sewa kos mingguan terbayar: ${(-RENT_COST).toLocaleString("id-ID", { style: "currency", currency: "IDR", maximumFractionDigits: 0 })}`, "peringatan");
    pushPhone("mas_tony", `Sewa mingguan sudah masuk. Terima kasih! Kamar kamu tetap aman.`, "sistem");
  } else {
    // utang: mood turun, tanda peringatan
    applyNeeds({ mood: -18 });
    pushPhone("mas_tony", `Kamu belum bisa bayar sewa mingguan. Tidak apa-apa, tapi tolong segera cari uang ya.`, "sistem");
    toast("Uang tidak cukup untuk sewa — kamu merasa cemas (mood turun).", "peringatan");
  }
}

// ---------- Kebutuhan ----------
export function applyNeeds(delta: Partial<GameState["needs"]>) {
  const s = state.get();
  for (const k of ["lapar", "energi", "kebersihan", "mood"] as const) {
    const d = delta[k];
    if (typeof d === "number") s.needs[k] = Math.max(0, Math.min(100, s.needs[k] + d));
  }
}

export function tickNeeds(dtRealSec: number, gameMinPerSec: number, opts: { running?: boolean; walking?: boolean; rain?: boolean } = {}) {
  const s = state.get();
  const gameHours = (dtRealSec * gameMinPerSec) / 60;
  applyNeeds({
    lapar: -DECAY.lapar * gameHours,
    energi: -(DECAY.energi + (opts.running ? RUN_ENERGY_COST : opts.walking ? WALK_ENERGY_COST : 0)) * gameHours,
    kebersihan: -DECAY.kebersihan * gameHours * (opts.rain ? 0.4 : 1),
    mood: -DECAY.mood * gameHours * (s.needs.lapar < LOW.lapar ? 2 : 1),
  });
  if (opts.rain) s.stats.rainWalked += gameHours;
}

export function speedFactor(): number {
  const s = state.get();
  if (s.needs.lapar < LOW.lapar) return 0.75;
  if (s.needs.energi <= 0) return 0.7;
  return 1;
}

export function canRun(): boolean {
  return state.get().needs.energi >= LOW.energi;
}

export function canWorkHeavy(): boolean {
  const s = state.get();
  return s.needs.energi >= LOW.energi && s.needs.lapar >= LOW.lapar;
}

// ---------- Ekonomi ----------
export function addLedger(label: string, amount: number) {
  const s = state.get();
  s.ledger.unshift({ id: s.ledger.length + 1, day: s.day, time: s.timeMin, label, amount });
  if (s.ledger.length > 200) s.ledger.length = 200;
}

export function earnMoney(amount: number, label: string) {
  const s = state.get();
  if (amount <= 0) return;
  s.money += amount;
  s.stats.moneyEarned += amount;
  addLedger(label, amount);
  checkQuestObjective("money_200k", s.money, true);
  bus.emit(EV.STATE_CHANGED);
}

export function spendMoney(amount: number, label: string): boolean {
  const s = state.get();
  if (amount <= 0) return true;
  if (s.money < amount) return false;
  s.money -= amount;
  s.stats.moneySpent += amount;
  addLedger(label, -amount);
  bus.emit(EV.STATE_CHANGED);
  return true;
}

// ---------- Tidur ----------
export function sleepUntilMorning(): { skipped: number } {
  const s = state.get();
  const now = s.timeMin;
  const wake = SLEEP_WAKE_HOUR * 60;
  let skippedMin: number;
  if (now < wake) skippedMin = wake - now;
  else skippedMin = 1440 - now + wake;
  // pemulihan tidur
  const quality = s.needs.lapar >= 15 ? 1 : 0.6;
  applyNeeds({
    energi: 100 * quality,
    lapar: -38 * quality,
    kebersihan: -14,
    mood: 14,
  });
  const startDay = s.day;
  s.timeMin = wake;
  s.day += 1;
  s.lastSleepDay = s.day;
  s.stats.daysPlayed = s.day;
  // romansa dulu (sebelum lastDay direset ke hari baru)
  tickRomance(s);
  for (const k of Object.keys(s.relationships)) {
    const r = s.relationships[k];
    r.chatToday = 0;
    r.giftToday = 0;
    r.lastDay = s.day;
  }
  const roll = Math.random();
  s.weather = rollWeather(s.season);
  if (s.day % RENT_INTERVAL === 1) {
    s.weeklyRentPaidDay = 0; // diproses saat tick pagi
  }
  void startDay;
  return { skipped: skippedMin };
}

// ---------- Pencapaian ----------
export function checkAchievements() {
  const s = state.get();
  for (const a of ACHIEVEMENTS) {
    if (!s.achievements.includes(a.id) && a.check(s)) {
      s.achievements.push(a.id);
      toast(`Pencapaian: ${a.name}`, "sukses");
      pushPhone("sistem", `Pencapaian terbuka: ${a.name} — ${a.desc}`, "sistem");
    }
  }
}

// ---------- Ponsel ----------
export function pushPhone(from: string, text: string, kind: string) {
  const s = state.get();
  s.phone.unshift({ id: s.phone.length + 1, from, text, day: s.day, time: s.timeMin, read: false });
  if (s.phone.length > 60) s.phone.length = 60;
  if (kind !== "silent") bus.emit("phone_notify", { from, text });
}
