// BFS pathfinding di grid tile — NPC tidak menembus dinding/prop.
import { MAP_H, MAP_W } from "../data/mapdata";

export function findPath(walkable: (x: number, y: number) => boolean, start: [number, number], goal: [number, number]): [number, number][] {
  if (start[0] === goal[0] && start[1] === goal[1]) return [];
  const key = (x: number, y: number) => y * MAP_W + x;
  const prev = new Map<number, number>();
  const queue: number[] = [key(start[0], start[1])];
  const seen = new Set<number>(queue);
  const goalKey = key(goal[0], goal[1]);
  let found = false;
  while (queue.length > 0) {
    const cur = queue.shift()!;
    if (cur === goalKey) {
      found = true;
      break;
    }
    const cx = cur % MAP_W;
    const cy = Math.floor(cur / MAP_W);
    for (const [dx, dy] of [[1, 0], [-1, 0], [0, 1], [0, -1]] as const) {
      const nx = cx + dx;
      const ny = cy + dy;
      if (nx < 0 || ny < 0 || nx >= MAP_W || ny >= MAP_H) continue;
      if (!walkable(nx, ny) && key(nx, ny) !== goalKey) continue; // boleh masuk goal meski solid? tidak: goal harus walkable
      if (key(nx, ny) === goalKey && !walkable(nx, ny)) continue;
      const k = key(nx, ny);
      if (seen.has(k)) continue;
      seen.add(k);
      prev.set(k, cur);
      queue.push(k);
    }
  }
  if (!found) return [];
  const path: [number, number][] = [];
  let cur = goalKey;
  while (cur !== key(start[0], start[1])) {
    path.push([cur % MAP_W, Math.floor(cur / MAP_W)]);
    const p = prev.get(cur);
    if (p === undefined) break;
    cur = p;
  }
  return path.reverse();
}
