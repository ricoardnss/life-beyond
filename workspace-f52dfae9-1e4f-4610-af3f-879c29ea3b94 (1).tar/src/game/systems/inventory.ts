// Inventory 24 slot — aman dari duplikasi (operasi berbasis jumlah, bukan referensi).
import { INV_SLOTS } from "../core/constants";
import { state } from "../core/state";
import { item } from "../data/items";
import { applyNeeds, checkAchievements, toast } from "./systems";
import { checkQuestObjective } from "./quests";
import { bus, EV } from "../core/bus";
import type { InvSlot } from "../core/types";

export function addItem(itemId: string, qty = 1): boolean {
  if (qty <= 0) return false;
  const def = item(itemId);
  const inv = state.get().inventory;
  let left = qty;
  // isi slot bertumpuk dulu
  for (const slot of inv) {
    if (left <= 0) break;
    if (slot && slot.itemId === itemId && slot.qty < def.stack) {
      const space = def.stack - slot.qty;
      const put = Math.min(space, left);
      slot.qty += put;
      left -= put;
    }
  }
  // slot kosong baru
  for (let i = 0; i < inv.length && left > 0; i++) {
    if (!inv[i]) {
      const put = Math.min(def.stack, left);
      inv[i] = { itemId, qty: put };
      left -= put;
    }
  }
  if (left > 0) {
    toast("Inventory penuh!", "peringatan");
    return false;
  }
  bus.emit(EV.STATE_CHANGED);
  return true;
}

export function countItem(itemId: string): number {
  return state.get().inventory.reduce((n, s) => (s && s.itemId === itemId ? n + s.qty : n), 0);
}

export function removeItem(itemId: string, qty = 1): boolean {
  if (countItem(itemId) < qty) return false;
  const inv = state.get().inventory;
  let left = qty;
  // hapus dari slot paling belakang dulu agar slot awal stabil
  for (let i = inv.length - 1; i >= 0 && left > 0; i--) {
    const slot = inv[i];
    if (slot && slot.itemId === itemId) {
      const take = Math.min(slot.qty, left);
      slot.qty -= take;
      left -= take;
      if (slot.qty <= 0) inv[i] = null;
    }
  }
  bus.emit(EV.STATE_CHANGED);
  return true;
}

export function useItem(slotIndex: number): boolean {
  const s = state.get();
  const slot = s.inventory[slotIndex];
  if (!slot) return false;
  const def = item(slot.itemId);
  if (!def.effects) {
    toast(`${def.name} tidak bisa digunakan langsung.`, "info");
    return false;
  }
  // idempoten: validasi ulang sebelum mutasi
  if (!removeItem(slot.itemId, 1)) return false;
  applyNeeds(def.effects);
  s.stats.mealsEaten += 1;
  checkQuestObjective("eat_food", 1);
  checkAchievements();
  bus.emit("sfx", { name: "eat" });
  toast(`${def.name} dipakai.`, "sukses");
  return true;
}

export function moveSlot(from: number, to: number): boolean {
  const inv = state.get().inventory;
  if (from === to || from < 0 || to < 0 || from >= INV_SLOTS || to >= INV_SLOTS) return false;
  const a = inv[from];
  const b = inv[to];
  if (!a) return false;
  if (b && b.itemId === a.itemId) {
    const def = item(a.itemId);
    const put = Math.min(def.stack - b.qty, a.qty);
    if (put > 0) {
      b.qty += put;
      a.qty -= put;
      if (a.qty <= 0) inv[from] = null;
    }
  } else {
    inv[to] = a;
    inv[from] = b ?? null;
  }
  bus.emit(EV.STATE_CHANGED);
  return true;
}

export function dropSlot(slotIndex: number): boolean {
  const inv = state.get().inventory;
  const slot: InvSlot | null = inv[slotIndex];
  if (!slot) return false;
  const def = item(slot.itemId);
  if (def.cat === "khusus" && (slot.itemId === "paket" || slot.itemId === "kucing")) {
    toast(`${def.name} tidak boleh dibuang!`, "peringatan");
    return false;
  }
  inv[slotIndex] = null;
  toast(`${def.name} dibuang.`, "info");
  bus.emit(EV.STATE_CHANGED);
  return true;
}
