// Sistem hubungan sosial + interaksi NPC + ponsel (+ romansa/pacaran).
import {
  CHAT_GAIN,
  CHAT_LIMIT,
  DATE_LIMIT_PER_DAY,
  DATE_OPTIONS,
  GIFT_GAIN_DISLIKE,
  GIFT_GAIN_LIKE,
  GIFT_GAIN_NEUTRAL,
  GIFT_LIMIT,
  LOW,
  ROMANCE,
  stageOf,
} from "../core/constants";
import { state } from "../core/state";
import { bus } from "../core/bus";
import { npcById } from "../data/npcs";
import { item } from "../data/items";
import { pickLine, DIALOGS } from "../data/dialogs";
import { applyNeeds, pushPhone, spendMoney, toast } from "./systems";
import { removeItem, countItem } from "./inventory";
import { checkQuestObjective } from "./quests";
import { currentHour } from "./systems";
import type { GameState, Relationship } from "../core/types";

export function rel(npcId: string): Relationship {
  const s = state.get();
  if (!s.relationships[npcId]) {
    s.relationships[npcId] = { score: 0, stage: "tidak_kenal", chatToday: 0, giftToday: 0, lastDay: s.day };
  }
  return s.relationships[npcId];
}

/** Tambah skor relasi langsung (hadiah misi) — tanpa batas harian. */
export function gainRelDirect(npcId: string, amount: number) {
  rel(npcId); // pastikan terinisialisasi
  gain(npcId, amount);
}

export function stageName(score: number): string {
  return stageOf(score).name;
}

function gain(npcId: string, amount: number) {
  const r = rel(npcId);
  const before = stageOf(r.score).id;
  r.score = Math.max(0, Math.min(100, r.score + amount));
  const after = stageOf(r.score).id;
  if (before !== after) {
    const names: Record<string, string> = { kenalan: "Kenalan", teman: "Teman", teman_dekat: "Teman Dekat", sahabat: "Sahabat" };
    if (after !== "tidak_kenal") {
      toast(`${npcById(npcId).name} sekarang ${names[after]}!`, "sukses");
      pushPhone(npcId, `Senang bisa lebih dekat dengan kamu.`, "silent");
      const s = state.get();
      s.stats.friendsMax = Math.max(s.stats.friendsMax, r.score);
    }
  }
}

function moodFactor(): number {
  const s = state.get();
  if (s.needs.mood < LOW.mood) return 0.5;
  if (s.needs.mood > 60) return 1.15;
  return 1;
}

export function chatWith(npcId: string): { ok: boolean; line: string } {
  const s = state.get();
  const npc = npcById(npcId);
  const r = rel(npcId);
  if (r.chatToday >= CHAT_LIMIT) {
    return { ok: false, line: "(Kamu sudah banyak mengobrol hari ini. Biarkan dia istirahat.)" };
  }
  const stage = stageOf(r.score);
  const hour = currentHour();
  const pools = DIALOGS[npcId];
  let pool = pools?.chat ?? ["Hm, hari ini cuacanya biasa saja, ya?"];
  if (r.dating && pools.pacar) {
    // pacaran: dialog romantis mendominasi
    pool = Math.random() < 0.7 ? pools.pacar : [...pools.pacar, ...pools.chat];
  } else if (r.score >= 80 && pools.sahabat) pool = [...pools.sahabat, ...pools.chat];
  else if (r.score >= 30 && pools.teman) pool = [...pools.teman, ...pools.chat];
  if (!(r.dating && pools.pacar) && hour < 10 && pools.pagi && Math.random() < 0.5) pool = pools.pagi;
  if (!(r.dating && pools.pacar) && hour >= 20 && pools.malam && Math.random() < 0.5) pool = pools.malam;
  if (s.weather === "hujan" && pools.hujan && Math.random() < 0.55) pool = pools.hujan;
  if (s.weather === "salju" && pools.salju && Math.random() < 0.7) pool = pools.salju;
  if (s.weather === "badai" && pools.badai && Math.random() < 0.7) pool = pools.badai;
  if (s.weather === "kabut" && pools.kabut && Math.random() < 0.6) pool = pools.kabut;

  // Topik berurutan: obrolan ke-N melanjutkan cerita dari obrolan ke-(N-1)
  // — bukan lompatan acak, jadi percakapan terasa "nyambung" antar hari.
  if (r.chatTotal === undefined) r.chatTotal = 0;
  const line = pool[r.chatTotal % pool.length];
  r.chatTotal += 1;
  r.chatToday += 1;
  r.lastDay = s.day;
  const idx = Math.min(stage.id === "sahabat" ? 4 : stage.id === "teman_dekat" ? 3 : stage.id === "teman" ? 2 : stage.id === "kenalan" ? 1 : 0, CHAT_GAIN.length - 1);
  gain(npcId, CHAT_GAIN[idx] * moodFactor());
  s.stats.chatCount += 1;
  applyNeeds({ mood: r.dating ? 4 + ROMANCE.CHAT_MOOD_BONUS : 4 });
  checkQuestObjective("chat_unique", npcId);
  checkQuestObjective(`talk_${npcId}`, 1);
  return { ok: true, line };
}

export function giveGift(npcId: string, itemId: string): { ok: boolean; line: string } {
  const r = rel(npcId);
  const npc = npcById(npcId);
  if (r.giftToday >= GIFT_LIMIT) {
    return { ok: false, line: "(Satu hadiah per hari sudah cukup untuknya.)" };
  }
  if (countItem(itemId) <= 0) return { ok: false, line: "(Barang tidak ada di inventory.)" };
  const def = item(itemId);
  const s = state.get();
  if (!removeItem(itemId, 1)) return { ok: false, line: "(Gagal memberi hadiah.)" };
  r.giftToday += 1;
  r.lastDay = s.day;
  s.stats.giftsGiven += 1;
  let delta = GIFT_GAIN_NEUTRAL;
  let line: string;
  if (npc.likes.includes(itemId)) {
    delta = GIFT_GAIN_LIKE;
    line = `Wah, ${def.name}! Kamu tahu saja selera saya. Terima kasih banyak!`;
  } else if (npc.dislikes.includes(itemId)) {
    delta = GIFT_GAIN_DISLIKE;
    line = `Eh... ${def.name}? Bukan yang aku suka, tapi terima kasih sih.`;
  } else {
    line = `Oh, ${def.name} untukku? Terima kasih ya.`;
  }
  gain(npcId, delta * moodFactor());
  applyNeeds({ mood: 2 });
  return { ok: true, line };
}

export function helpNpc(npcId: string): string {
  // bantu kecil (ajak ngangkut, dll) — sekali sehari, gain kecil
  const r = rel(npcId);
  if (r.chatToday >= CHAT_LIMIT + 2) return "(Dia sudah cukup terbantu hari ini.)";
  gain(npcId, 3 * moodFactor());
  applyNeeds({ energi: -3, mood: 3 });
  const lines: Record<string, string> = {
    default: "Makasih banyak ya, kamu membantu!",
  };
  return lines.default;
}

export function inviteTogether(npcId: string): string {
  const r = rel(npcId);
  if (r.score < 30) return "Hmm... mungkin lain kali ya. Kita belum terlalu akrab.";
  const s = state.get();
  if (s.needs.mood < 30) return "Kamu kelihatan lelah. Istirahat dulu deh, nanti kita jalan.";
  gain(npcId, 5 * moodFactor());
  applyNeeds({ mood: 10, energi: -4, lapar: -3 });
  const acts = [
    "Kalian jalan sore keliling taman sambil cerita ringan.",
    "Kalian duduk di bangku taman, berbagi jajanan.",
    "Kalian ngobrol panjang sampai langit jingga.",
  ];
  return acts[s.day % acts.length];
}

// ---------- Romansa (pacaran) ----------

export function isDating(npcId: string): boolean {
  return Boolean(rel(npcId).dating);
}

/** Id pacar aktif (hanya boleh satu) atau null. */
export function pacarOf(s: GameState): string | null {
  for (const [id, r] of Object.entries(s.relationships)) {
    if (r.dating) return id;
  }
  return null;
}

export type ConfessReason = "no_npc" | "punya_pacar" | "sudah" | "skor" | "mood" | "ok";

export function canConfess(npcId: string, s: GameState = state.get()): { ok: boolean; reason: ConfessReason } {
  const npc = npcById(npcId);
  if (!npc.romanceable) return { ok: false, reason: "no_npc" };
  const r = rel(npcId);
  if (r.dating) return { ok: false, reason: "sudah" };
  if (pacarOf(s)) return { ok: false, reason: "punya_pacar" };
  if (r.score < ROMANCE.MIN_SCORE) return { ok: false, reason: "skor" };
  if (s.needs.mood < ROMANCE.MOOD_MIN) return { ok: false, reason: "mood" };
  return { ok: true, reason: "ok" };
}

/** Menyatakan perasaan (nembak). Diterima bila kedekatan cukup; ditolak berbiaya. */
export function confess(npcId: string): { ok: boolean; line: string } {
  const s = state.get();
  const npc = npcById(npcId);
  const chk = canConfess(npcId, s);
  if (!chk.ok) {
    const msgs: Record<string, string> = {
      no_npc: "(Kamu tidak bisa menyatakan perasaan pada orang ini.)",
      punya_pacar: "(Kamu sudah punya pacar. Setia itu penting — putus dulu kalau hatimu berubah.)",
      sudah: "(Kalian sudah berpacaran!)",
      skor: `${npc.name}: "Eh? Maaf ya... aku masih menganggapmu teman. Mungkin... kalau kita lebih dekat?"`,
      mood: "(Hatimu lagi tidak stabil. Bangkitkan mood dulu sebelum menyatakan perasaan.)",
    };
    return { ok: false, line: msgs[chk.reason] ?? "(Belum bisa.)" };
  }
  const r = rel(npcId);
  r.score = Math.min(100, r.score + 4);
  r.dating = true;
  r.sinceDay = s.day;
  r.dateToday = 0;
  r.lastDay = s.day;
  s.flags[`pacar_${npcId}`] = true;
  s.stats.friendsMax = Math.max(s.stats.friendsMax, r.score);
  applyNeeds({ mood: 15 });
  bus.emit("sfx", { name: "success" });
  pushPhone(npcId, `Eh, ini aku. Jadi... kita resmi ya mulai hari ini. Jangan lupa ajak aku jalan!`, "sistem");
  toast(`Sekarang kamu pacaran dengan ${npc.name}!`, "sukses");
  checkAchievementsSafe();
  return {
    ok: true,
    line: `${npc.name}: "Aku juga sudah lama mau bilang... Iya. Aku mau pacaran sama kamu. Jangan bikin aku nyesel, ya."`,
  };
}

function checkAchievementsSafe() {
  import("./systems").then(({ checkAchievements }) => checkAchievements());
}

/** Pergi date dengan pacar — sekali per hari, ada biaya sesuai pilihan. */
export function goOnDate(npcId: string, dateId: string): { ok: boolean; line: string } {
  const s = state.get();
  const npc = npcById(npcId);
  const r = rel(npcId);
  const opt = DATE_OPTIONS.find((d) => d.id === dateId);
  if (!opt) return { ok: false, line: "(Pilihan date tidak dikenal.)" };
  if (!r.dating) return { ok: false, line: "(Kalian belum berpacaran. Kenalan dulu, ya.)" };
  if ((r.dateToday ?? 0) >= DATE_LIMIT_PER_DAY) {
    return { ok: false, line: `${npc.name}: "Besok lagi, ya? Hari ini sudah cukup bahagia buatku."` };
  }
  if (s.needs.mood < 25) {
    return { ok: false, line: `${npc.name}: "Kamu kelihatan berat banget hari ini. Istirahat dulu, nanti kita jalan."` };
  }
  if (opt.cost > 0 && !spendMoney(opt.cost, `Date ${opt.label} — ${npc.name}`)) {
    return { ok: false, line: "(Uang tidak cukup untuk date ini.)" };
  }
  r.dateToday = (r.dateToday ?? 0) + 1;
  r.lastDay = s.day;
  gain(npcId, opt.gain * moodFactor());
  applyNeeds({ mood: opt.mood, energi: opt.energi, lapar: opt.lapar });
  s.stats.datesGone += 1;
  bus.emit("sfx", { name: "success" });
  const lines: Record<string, string[]> = {
    santai: [
      `Kalian berdua keliling taman sampai langit jingga. ${npc.name} bercerita panjang lebar, dan kamu mendengarkan.`,
      `Jalan pelan mengitari distrik, sesekali tertawa bersama. Waktu terasa cepat sekali.`,
    ],
    jajanan: [
      `${npc.name} memilih jajanan favoritnya di gerobak. "Traktir kamu paling enak," katanya sambil tersenyum lebar.`,
      `Duduk di bangku berbagi jajanan hangat. Sederhana, tapi hati kalian sama-sama hangat.`,
    ],
    kafe: [
      `Meja dua di Kafe Arunika. Cahaya lilin, obrolan panjang, dan ${npc.name} tak berhenti tersenyum.`,
      `Makan malam spesial berdua. ${npc.name} bilang, "Hari ini salah satu hari terbaikku."`,
    ],
  };
  const line = pickLine(lines[opt.id] ?? lines.santai, s.day, currentHour(), r.dateToday);
  if (r.score >= ROMANCE.HEART_SCORE && !s.flags.heart_event) {
    s.flags.heart_event = true;
    pushPhone(npcId, `Aku nggak pernah nyangka bisa sebahagia ini di kota ini. Terima kasih sudah selalu ada buatku.`, "sistem");
    toast("Hubungan kalian makin serius.", "sukses");
  }
  pushPhone(npcId, `Hari ini menyenangkan banget. Makasih ya sudah ajak aku jalan.`, "silent");
  checkAchievementsSafe();
  return { ok: true, line };
}

/** Mengakhiri hubungan — skor turun tajam dan mood pemain terpukul. */
export function breakUp(npcId: string): { ok: boolean; line: string } {
  const s = state.get();
  const npc = npcById(npcId);
  const r = rel(npcId);
  if (!r.dating) return { ok: false, line: "(Kalian memang tidak sedang berpacaran.)" };
  r.dating = false;
  r.sinceDay = undefined;
  r.dateToday = 0;
  delete s.flags[`pacar_${npcId}`];
  r.score = Math.max(0, Math.round(r.score * 0.4));
  applyNeeds({ mood: -18 });
  bus.emit("sfx", { name: "fail" });
  pushPhone(npcId, `Mungkin kita memang tidak jalan bersama lebih jauh. Jaga dirimu, ya.`, "sistem");
  toast(`Kamu dan ${npc.name} resmi putus.`, "peringatan");
  return { ok: true, line: `${npc.name}: "...Oh. Baiklah. Kalau itu keputusanmu, aku hormati. Semoga kamu bahagia."` };
}

// Buka dialog dengan opsi
export function dialogOptionsFor(npcId: string, s: GameState) {
  const opts: { key: string; label: string }[] = [
    { key: "chat", label: "Mengobrol" },
    { key: "gift", label: "Memberi Hadiah" },
  ];
  const r = rel(npcId);
  const stage = stageOf(r.score);
  if (stage.min >= 10) opts.push({ key: "help", label: "Menawarkan Bantuan" });
  if (stage.min >= 30) opts.push({ key: "invite", label: "Mengajak Jalan" });
  const npc = npcById(npcId);
  if (npc.romanceable && !r.dating && r.score >= ROMANCE.MIN_SCORE) opts.push({ key: "nembak", label: "Sampaikan Perasaan" });
  if (r.dating) {
    opts.push({ key: "date", label: "Ajak Date" });
    opts.push({ key: "putus", label: "Putus" });
  }
  void s;
  return opts;
}
