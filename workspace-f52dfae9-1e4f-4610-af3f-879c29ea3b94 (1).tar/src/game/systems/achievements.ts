// Pencapaian (achievement) + statistik.
import type { AchievementDef, GameState } from "../core/types";

export const ACHIEVEMENTS: AchievementDef[] = [
  { id: "first_day", name: "Langkah Pertama", desc: "Selesaikan hari pertama.", check: (s) => s.day >= 2 },
  { id: "week_one", name: "Satu Pekan Bertahan", desc: "Main sampai hari ke-7.", check: (s) => s.day >= 7 },
  { id: "free_bird", name: "Burung Bebas", desc: "Main sampai hari ke-30.", check: (s) => s.day >= 30 },
  { id: "rich", name: "Rezeki Kota", desc: "Kumpulkan Rp500.000.", check: (s) => s.money >= 500000 },
  { id: "millionaire", name: "Juragan Arunika", desc: "Kumpulkan Rp1.000.000.", check: (s) => s.money >= 1000000 },
  { id: "worker", name: "Pekerja Ulet", desc: "Selesaikan 10 shift kerja.", check: (s) => s.stats.shiftsWorked >= 10 },
  { id: "courier_pro", name: "Raja Jalanan", desc: "Antarkan 25 paket.", check: (s) => s.stats.deliveriesDone >= 25 },
  { id: "social", name: "Warga Baru Favorit", desc: "Ngobrol 30 kali.", check: (s) => s.stats.chatCount >= 30 },
  { id: "bestie", name: "Sahabat Sejati", desc: "Punya satu relasi 80+.", check: (s) => Object.values(s.relationships).some((r) => r.score >= 80) },
  { id: "collector", name: "Kolektor", desc: "Beli 25 barang di toko.", check: (s) => s.stats.itemsBought >= 25 },
  { id: "clean_city", name: "Lingkungan Bersih", desc: "Kumpulkan 10 sampah.", check: (s) => s.stats.trashCollected >= 10 },
  { id: "quest_hunter", name: "Pemburu Misi", desc: "Selesaikan 5 misi.", check: (s) => s.stats.questsDone >= 5 },
  { id: "rain_walker", name: "Hujan Tak Takut", desc: "Berjalan 5 jam saat hujan.", check: (s) => s.stats.rainWalked >= 5 },
  { id: "chef_friend", name: "Teman Warung", desc: "Makan 20 kali.", check: (s) => s.stats.mealsEaten >= 20 },
  { id: "first_love", name: "Jadian!", desc: "Mulai hubungan dengan seorang warga Arunika.", check: (s) => Object.values(s.relationships).some((r) => r.dating) },
  { id: "date_five", name: "Ahli Rencana Date", desc: "Ajak pacar berdate 5 kali.", check: (s) => s.stats.datesGone >= 5 },
  { id: "true_love", name: "Hubungan Serius", desc: "Capai kedekatan 95 dengan pacar.", check: (s) => Object.values(s.relationships).some((r) => r.dating && r.score >= 95) },
];

export function achievementProgress(s: GameState): { id: string; name: string; desc: string; done: boolean }[] {
  return ACHIEVEMENTS.map((a) => ({ id: a.id, name: a.name, desc: a.desc, done: s.achievements.includes(a.id) || a.check(s) }));
}
