// Pekerjaan — shift, gaji, skill, hasil minigame.
import { JOBS, KURIR_PAY_PER_DELIVERY, KURIR_TIP_PER_LEVEL, MAX_SKILL, MINIMART_BONUS_PER_ACCURACY, SHIFT_GAME_MINUTES, WARUNG_TIP_PER_SERVE } from "../data/jobs";
import { state } from "../core/state";
import { addLedger, applyNeeds, canWorkHeavy, currentHour, earnMoney, toast, pushPhone } from "./systems";
import { checkQuestObjective } from "./quests";
import { item } from "../data/items";
import { addItem, removeItem } from "./inventory";

export function jobAvailable(jobId: keyof typeof JOBS): { ok: boolean; reason?: string } {
  const s = state.get();
  const job = JOBS[jobId];
  const hour = currentHour();
  if (s.shift) return { ok: false, reason: "Selesaikan shift yang sedang berjalan dulu." };
  if (hour < job.startHour || hour >= job.endHour) return { ok: false, reason: `Jam kerja ${job.startHour}.00-${job.endHour}.00.` };
  if (!canWorkHeavy()) return { ok: false, reason: "Kondisi tubuh tidak fit (lapar/energi rendah). Makan & istirahat dulu." };
  if (jobId === "minimarket" && s.jobs.warung.shiftsDone < 2) {
    return { ok: false, reason: "Butuh pengalaman 2 shift di warung." };
  }
  return { ok: true };
}

export function startShift(jobId: keyof typeof JOBS): boolean {
  const av = jobAvailable(jobId);
  if (!av.ok) {
    toast(av.reason ?? "Tidak bisa memulai shift.", "peringatan");
    return false;
  }
  const s = state.get();
  s.shift = { jobId, startedMin: s.timeMin };
  if (jobId === "kurir") {
    // ambil paket
    addItem("paket", 3);
    toast("Shift kurir dimulai! 3 paket di tangan. Antarkan ke titik berkedip.", "info");
  } else {
    toast(`Shift ${JOBS[jobId].name} dimulai. Semangat!`, "info");
  }
  return true;
}

export interface ShiftResult {
  serves?: number; // warung
  correctServe?: number;
  deliveries?: number; // kurir
  accuracy?: number; // minimarket 0..1
}

export function finishShift(result: ShiftResult) {
  const s = state.get();
  if (!s.shift) return;
  const jobId = s.shift.jobId;
  const job = JOBS[jobId];
  s.shift = null;
  // maju waktu 2 jam game (durasi shift)
  s.timeMin = (s.timeMin + SHIFT_GAME_MINUTES) % 1440;
  const js = s.jobs[jobId];
  js.shiftsDone += 1;
  s.stats.shiftsWorked += 1;
  applyNeeds({ energi: -18, lapar: -12, mood: -4, kebersihan: -4 });

  let earned = 0;
  let detail = "";
  if (jobId === "warung") {
    const tip = (result.correctServe ?? 0) * WARUNG_TIP_PER_SERVE;
    earned = job.wagePerShift + tip;
    detail = `Gaji ${job.wagePerShift.toLocaleString("id-ID")} + tip ${tip.toLocaleString("id-ID")}`;
    earnMoney(earned, `Gaji shift warung (${result.correctServe ?? 0} serve)`);
    checkQuestObjective("shift_warung", 1);
  } else if (jobId === "kurir") {
    const pay = (result.deliveries ?? 0) * KURIR_PAY_PER_DELIVERY;
    const tip = (result.deliveries ?? 0) * KURIR_TIP_PER_LEVEL * (js.level - 1);
    earned = pay + tip;
    detail = `${result.deliveries ?? 0} pengiriman × ${(KURIR_PAY_PER_DELIVERY + KURIR_TIP_PER_LEVEL * (js.level - 1)).toLocaleString("id-ID")}`;
    if (earned > 0) earnMoney(earned, `Upah kurir (${result.deliveries ?? 0} paket)`);
    s.stats.deliveriesDone += result.deliveries ?? 0;
    checkQuestObjective("deliveries", result.deliveries ?? 0);
    checkQuestObjective("shift_any", 1);
    checkQuestObjective("shift_kurir", 1);
    // paket tersisa dikembalikan
    while (removeItem("paket", 1));
  } else {
    const acc = result.accuracy ?? 0;
    const bonus = Math.round(acc * 10) * MINIMART_BONUS_PER_ACCURACY;
    earned = job.wagePerShift + bonus;
    detail = `Gaji ${job.wagePerShift.toLocaleString("id-ID")} + bonus akurasi ${bonus.toLocaleString("id-ID")}`;
    earnMoney(earned, `Gaji shift minimarket (${Math.round(acc * 10)}/10 akurat)`);
    checkQuestObjective("shift_minimarket", 1);
  }
  checkQuestObjective("shift_any", 1);

  // skill
  js.exp += 10 + Math.round(earned / 10000) * 2;
  if (js.exp >= js.level * 30 && js.level < MAX_SKILL) {
    js.exp = 0;
    js.level += 1;
    toast(`Skill ${job.name} naik ke level ${js.level}!`, "sukses");
    pushPhone(jobId === "warung" ? "bu_sari" : jobId === "kurir" ? "rian" : "maya", `Kerjamu memuaskan! Kepedulianmu naik level ${js.level} ya.`, "sistem");
  }
  js.totalEarned += earned;
  void detail;
  toast(`Shift selesai! Kamu menerima total upah.`, "sukses");
}

export function removeOnePaket(): boolean {
  return removeItem("paket", 1);
}

export function hasPaket(): boolean {
  return state.get().inventory.some((sl) => sl && sl.itemId === "paket");
}

export function paketCount(): number {
  return state.get().inventory.reduce((n, sl) => (sl && sl.itemId === "paket" ? n + sl.qty : n), 0);
}

export function sellPriceOf(itemId: string): number {
  return item(itemId).sell;
}

export function addLedgerInfo(label: string, amount: number) {
  addLedger(label, amount);
}
