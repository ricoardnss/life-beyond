// Sistem misi — aktivasi, pencacah objektif, penyelesaian, hadiah.
import { state } from "../core/state";
import { QUESTS, questById } from "../data/quests";
import { addItem, countItem, removeItem } from "./inventory";
import { earnMoney, pushPhone, toast } from "./systems";
import { gainRelDirect } from "./social";
import { bus, EV } from "../core/bus";

export function refreshAvailability() {
  const s = state.get();
  for (const q of QUESTS) {
    if (q.type !== "sampingan") continue;
    if (s.quests[q.id]) continue;
    const unlockDay = q.unlockDay ?? 1;
    const reqOk = (q.requires ?? []).every((r) => s.quests[r]?.status === "selesai");
    if (s.day >= unlockDay && reqOk) {
      s.quests[q.id] = { status: "tersedia", counts: {} };
      pushPhone("sistem", `Misi baru tersedia: "${q.name}" — cek Jurnal (J).`, "sistem");
    }
  }
  // tutorial chain: aktifkan berikutnya saat selesai
  const tut = QUESTS.filter((q) => q.type === "tutorial");
  for (let i = 0; i < tut.length; i++) {
    const q = tut[i];
    if (!s.quests[q.id]) {
      const prev = i === 0 ? true : s.quests[tut[i - 1].id]?.status === "selesai";
      if (prev) {
        s.quests[q.id] = { status: "tersedia", counts: {} };
        if (i === 0) pushPhone("mas_tony", `Selamat datang di Kos Arunika! Mampir ke depan, saya Mas Tony penjaganya.`, "sistem");
      }
    }
  }
}

export function activateQuest(id: string): boolean {
  const s = state.get();
  const qp = s.quests[id];
  if (!qp || qp.status !== "tersedia") return false;
  qp.status = "aktif";
  s.activeQuests.push(id);
  toast(`Misi aktif: ${questById(id).name}`, "info");
  bus.emit(EV.STATE_CHANGED);
  return true;
}

/** Cacah objektif. value: angka (increment) atau string unik (unique set via count target). */
export function checkQuestObjective(objectiveId: string, value: number | string, absolute = false) {
  const s = state.get();
  for (const qid of s.activeQuests) {
    const q = QUESTS.find((q) => q.id === qid);
    if (!q) continue;
    const qp = s.quests[qid];
    for (const obj of q.objectives) {
      if (obj.id !== objectiveId) continue;
      if (typeof value === "string") {
        // objektif unik: simpan key di counts sebagai angka kehadiran
        const seenKey = `${obj.id}_seen`;
        const seen = ((qp.counts[seenKey] as unknown as string) || "");
        if (seen.includes(value)) continue;
        qp.counts[seenKey] = `${seen}|${value}` as unknown as number;
        qp.counts[obj.id] = (qp.counts[obj.id] || 0) + 1;
      } else if (absolute) {
        qp.counts[obj.id] = Math.max(qp.counts[obj.id] || 0, value);
      } else {
        qp.counts[obj.id] = (qp.counts[obj.id] || 0) + value;
      }
      // auto-complete
      if (q.autoComplete) tryComplete(qid);
    }
  }
  bus.emit(EV.STATE_CHANGED);
}

export function objectiveDone(qid: string, objId: string): boolean {
  const s = state.get();
  const qp = s.quests[qid];
  if (!qp) return false;
  const q = questById(qid);
  const obj = q.objectives.find((o) => o.id === objId);
  if (!obj) return false;
  return (qp.counts[objId] || 0) >= (obj.target ?? 1);
}

export function questReady(qid: string): boolean {
  return questById(qid).objectives.every((o) => objectiveDone(qid, o.id));
}

export function tryComplete(qid: string): boolean {
  const s = state.get();
  const qp = s.quests[qid];
  if (!qp || qp.status !== "aktif") return false;
  if (!questReady(qid)) return false;
  completeQuest(qid);
  return true;
}

function completeQuest(qid: string) {
  const s = state.get();
  const q = questById(qid);
  const qp = s.quests[qid];
  if (!qp) return;
  qp.status = "selesai";
  qp.doneDay = s.day;
  s.activeQuests = s.activeQuests.filter((x) => x !== qid);
  s.stats.questsDone += 1;
  if (q.rewardMoney) earnMoney(q.rewardMoney, `Hadiah misi: ${q.name}`);
  if (q.rewardItems) for (const r of q.rewardItems) addItem(r.itemId, r.qty);
  if (q.rewardRelation) for (const r of q.rewardRelation) gainRelDirect(r.npcId, r.amount);
  toast(`Misi selesai: ${q.name}!`, "sukses");
  bus.emit("sfx", { name: "success" });
  pushPhone("sistem", `Misi "${q.name}" selesai. Hadiah sudah dikirim ke dompet/inventory.`, "sistem");
  refreshAvailability();
}

/** NPC dengan misi turn-in; dipanggil saat bicara NPC. */
export function turnInQuestsFor(npcId: string): string[] {
  const s = state.get();
  const done: string[] = [];
  for (const qid of s.activeQuests) {
    const q = QUESTS.find((q) => q.id === qid);
    if (!q || q.turnInAt !== npcId) continue;
    // khusus q_menu_baru: butuh item bahan
    if (qid === "q_menu_baru") {
      if (countItem("telur") >= 1 && countItem("cabai") >= 1 && countItem("beras") >= 1) {
        removeItem("telur", 1);
        removeItem("cabai", 1);
        removeItem("beras", 1);
        checkQuestObjective("turnin_menu", 1);
      }
    }
    // q_kucing_hilang: butuh kucing
    if (qid === "q_kucing_hilang") {
      if (countItem("kucing") >= 1) {
        removeItem("kucing", 1);
        checkQuestObjective("return_cat", 1);
      }
    }
    if (questReady(qid)) {
      completeQuest(qid);
      done.push(q.name);
    }
  }
  return done;
}
