// Misi tutorial + misi sampingan. Progres dihitung dari event gameplay nyata.
import type { QuestDef } from "../core/types";

export const QUESTS: QuestDef[] = [
  // ===== Tutorial =====
  {
    id: "t1_hari_pertama",
    name: "Hari Pertama di Arunika",
    desc: "Kamu baru pindah ke Kos Arunika. Sapa Mas Tony, penjaga kos, di depan bangunan kos.",
    type: "tutorial",
    objectives: [{ id: "talk_mas_tony", desc: "Bicara dengan Mas Tony", target: 1 }],
    rewardMoney: 5000,
    autoComplete: true,
  },
  {
    id: "t2_isi_perut",
    name: "Isi Perut Dulu",
    desc: "Perut kosong tidak bisa diajak neraka pagi. Beli makanan di Warung Bu Sari lalu makan.",
    type: "tutorial",
    objectives: [
      { id: "buy_food", desc: "Beli makanan (di warung/minimarket)", target: 1 },
      { id: "eat_food", desc: "Makan makanan apa pun", target: 1 },
    ],
    rewardMoney: 3000,
    rewardItems: [{ itemId: "es_teh", qty: 1 }],
    autoComplete: true,
  },
  {
    id: "t3_cari_uang",
    name: "Cari Penghasilan",
    desc: "Uang tidak jatuh dari langit. Ambil satu shift kerja: warung, kurir, atau minimarket.",
    type: "tutorial",
    objectives: [{ id: "shift_any", desc: "Selesaikan satu shift kerja", target: 1 }],
    rewardMoney: 10000,
    autoComplete: true,
  },
  {
    id: "t4_rumah_kecil",
    name: "Rumah Kecilku",
    desc: "Kamar kos boleh sederhana, tapi harus terasa seperti rumah. Beli furnitur di minimarket dan tempatkan di kamar.",
    type: "tutorial",
    objectives: [{ id: "place_furniture", desc: "Tempatkan 1 furnitur di kamar", target: 1 }],
    rewardMoney: 5000,
    autoComplete: true,
  },
  {
    id: "t5_kenalan_baru",
    name: "Kenalan Baru",
    desc: "Arunika terasa seperti rumah ketika kamu punya teman. Ngobrol dengan 3 warga berbeda.",
    type: "tutorial",
    objectives: [
      { id: "chat_unique", desc: "Ngobrol dengan 3 warga berbeda", target: 3 },
    ],
    rewardItems: [{ itemId: "hadiah_kue", qty: 1 }],
    rewardMoney: 4000,
    autoComplete: true,
  },
  // ===== Misi sampingan =====
  {
    id: "q_paket_menggunung",
    name: "Paket Menggunung",
    desc: "Rian kewalahan dengan kiriman hari ini. Bantu dia mengantarkan paket sebagai kurir.",
    type: "sampingan",
    objectives: [{ id: "deliveries", desc: "Antarkan 3 paket (kerja kurir)", target: 3 }],
    rewardMoney: 20000,
    rewardRelation: [{ npcId: "rian", amount: 12 }],
    unlockDay: 1,
  },
  {
    id: "q_taman_bersih",
    name: "Arunika Bersih",
    desc: "Om Hermanto menyayangi taman kota. Cari kantong sampah dari tempat sampah di sekitar kota.",
    type: "sampingan",
    objectives: [{ id: "sampah", desc: "Kumpulkan 5 kantong sampah", target: 5 }],
    rewardMoney: 15000,
    rewardRelation: [{ npcId: "om_hermanto", amount: 10 }],
    unlockDay: 2,
  },
  {
    id: "q_menu_baru",
    name: "Menu Baru Bu Sari",
    desc: "Bu Sari ingin mencoba resep baru tapi bahannya habis. Bawa telur, cabai, dan beras ke beliau.",
    type: "sampingan",
    objectives: [{ id: "turnin_menu", desc: "Serahkan bahan ke Bu Sari (bawa: telur, cabai, beras)", target: 1 }],
    rewardMoney: 25000,
    rewardItems: [{ itemId: "nasi_goreng", qty: 3 }],
    rewardRelation: [{ npcId: "bu_sari", amount: 15 }],
    unlockDay: 3,
    turnInAt: "bu_sari",
  },
  {
    id: "q_kucing_hilang",
    name: "Oyen Hilang!",
    desc: "Oyen, kucing oren Tante Wati, kabur lagi. Ada yang melihatnya di gang sempit dekat bengkel...",
    type: "sampingan",
    objectives: [
      { id: "find_cat", desc: "Temukan Oyen di gang dekat bengkel", target: 1 },
      { id: "return_cat", desc: "Kembalikan Oyen ke Tante Wati (bicara dengannya bawa kucing)", target: 1 },
    ],
    rewardMoney: 12000,
    rewardRelation: [{ npcId: "tante_wati", amount: 20 }],
    unlockDay: 2,
    requires: ["t1_hari_pertama"],
    turnInAt: "tante_wati",
  },
  {
    id: "q_kopi_segar",
    name: "Kopi Segar Dinda",
    desc: "Dinda butuh pelanggan setia. Beli 3 kopi di Kafe Arunika.",
    type: "sampingan",
    objectives: [{ id: "buy_kopi", desc: "Beli kopi Dinda (3x)", target: 3 }],
    rewardMoney: 10000,
    rewardRelation: [{ npcId: "dinda", amount: 15 }],
    unlockDay: 4,
  },
  {
    id: "q_nabung",
    name: "Target Nabung",
    desc: "Simpan uang sampai Rp200.000 di dompet. Bukti kamu bisa bertahan hidup di kota.",
    type: "sampingan",
    objectives: [{ id: "money_200k", desc: "Capai tabungan Rp200.000", target: 200000 }],
    rewardMoney: 20000,
    unlockDay: 3,
    checkOnly: true,
  },
  {
    id: "q_malam_minggu",
    name: "Malam Minggu di Taman",
    desc: "Setiap hari ke-7, warga berkumpul di taman pada malam hari (19:00-21:00). Datang dan sapa mereka.",
    type: "sampingan",
    objectives: [{ id: "attend_event", desc: "Hadir di taman saat malam minggu (hari ke-7, 19:00-21:00)", target: 1 }],
    rewardMoney: 15000,
    unlockDay: 5,
  },
];

export function questById(id: string): QuestDef {
  const q = QUESTS.find((q) => q.id === id);
  if (!q) throw new Error(`Misi tidak ditemukan: ${id}`);
  return q;
}
