// Pekerjaan — persyaratan, jadwal, gaji. Dimainkan lewat minigame interaktif.
import type { JobDef, JobId } from "../core/types";

export const JOBS: Record<JobId, JobDef> = {
  warung: {
    id: "warung",
    name: "Pegawai Warung",
    employer: "Bu Sari",
    desc: "Melayani pembeli di warung Bu Sari. Hafalkan pesanan, sajikan cepat, dapatkan tip.",
    startHour: 7,
    endHour: 14,
    wagePerShift: 18000,
    skillBonus: 0.05,
    requireLevel: 0,
    location: "warung_door",
    interior: "warung",
  },
  kurir: {
    id: "kurir",
    name: "Kurir Paket",
    employer: "Rian",
    desc: "Antarkan paket ke titik-titik di Arunika Tengah sebelum waktunya habis.",
    startHour: 9,
    endHour: 17,
    wagePerShift: 0, // dibayar per pengiriman
    skillBonus: 0.08, // bonus tip per pengiriman per level
    requireLevel: 0,
    location: "kurir_base",
  },
  minimarket: {
    id: "minimarket",
    name: "Pegawai Minimarket",
    employer: "Maya",
    desc: "Isi ulang rak sesuai urutan permintaan. Akurasi = bonus.",
    startHour: 15,
    endHour: 21,
    wagePerShift: 22000,
    skillBonus: 0.04,
    requireLevel: 0,
    location: "minimarket_door",
    interior: "minimarket",
  },
};

export const JOB_REQUIREMENTS: Record<JobId, { label: string; check: (s: { shiftsDone: Record<string, number> }) => boolean }> = {
  warung: { label: "Tidak ada persyaratan", check: () => true },
  kurir: { label: "Tidak ada persyaratan", check: () => true },
  minimarket: {
    label: "Pengalaman: 2 shift di warung",
    check: (s) => (s.shiftsDone["warung"] || 0) >= 2,
  },
};

export const MAX_SKILL = 5;
export const KURIR_PAY_PER_DELIVERY = 7000;
export const KURIR_TIP_PER_LEVEL = 500;
export const WARUNG_TIP_PER_SERVE = 500;
export const MINIMART_BONUS_PER_ACCURACY = 400;
export const SHIFT_GAME_MINUTES = 120; // satu shift = 2 jam game
