// Peta distrik "Arunika Tengah" + interior. Dibangun programatik agar bebas typo koordinat.
// Grid outdoor: '.'=rumput 'r'=jalan '-'=marka H '|'=marka V 'x'=zebra 's'=trotoar
// 'd'=tanah/tapak 'w'=air 'g'=gang 'f'=bunga
import { TILE } from "../core/constants";

export const MAP_W = 60;
export const MAP_H = 40;

// ---------- Grid helper ----------
function makeGrid(w: number, h: number, fill: string): string[][] {
  return Array.from({ length: h }, () => Array.from({ length: w }, () => fill));
}
function rect(g: string[][], x: number, y: number, w: number, h: number, ch: string) {
  for (let yy = y; yy < y + h; yy++)
    for (let xx = x; xx < x + w; xx++) if (yy >= 0 && yy < g.length && xx >= 0 && xx < g[0].length) g[yy][xx] = ch;
}

function buildOutdoor(): string[][] {
  const g = makeGrid(MAP_W, MAP_H, ".");
  // variasi rumput acak deterministik
  for (let y = 0; y < MAP_H; y++) for (let x = 0; x < MAP_W; x++) if ((x * 7 + y * 13) % 9 === 0) g[y][x] = ",";

  // trotoar
  rect(g, 0, 16, MAP_W, 1, "s");
  rect(g, 0, 20, MAP_W, 1, "s");
  rect(g, 27, 3, 1, 34, "s");
  rect(g, 31, 3, 1, 34, "s");
  // jalan
  rect(g, 0, 17, MAP_W, 1, "r");
  rect(g, 0, 18, MAP_W, 1, "-");
  rect(g, 0, 19, MAP_W, 1, "r");
  rect(g, 28, 3, 1, 34, "r");
  rect(g, 29, 3, 1, 34, "|");
  rect(g, 30, 3, 1, 34, "r");
  // zebra cross
  rect(g, 24, 17, 3, 3, "x");
  rect(g, 28, 16, 3, 1, "x");
  rect(g, 27, 17, 1, 3, "x");
  rect(g, 31, 17, 1, 3, "x");
  rect(g, 36, 17, 3, 3, "x");
  // kolam taman
  rect(g, 40, 29, 6, 3, "w");
  for (const [cx, cy] of [[40, 29], [45, 29], [40, 31], [45, 31]]) g[cy][cx] = ".";
  // gang gravel dekat bengkel (sarang Oyen)
  rect(g, 13, 26, 8, 1, "g");
  // tapak tanah dari pintu-pintu
  const paths: [number, number, number, number][] = [
    [10, 8, 1, 8], [17, 7, 1, 9], [4, 14, 1, 2], [17, 14, 1, 2],
    [37, 7, 1, 9], [46, 12, 1, 4], [9, 21, 1, 5], [38, 21, 1, 5],
    [33, 26, 12, 1], [38, 26, 1, 3], [33, 32, 12, 1], [36, 27, 1, 6], [42, 26, 1, 3],
    // jalur rumah warga baru
    [22, 7, 1, 9], [2, 7, 1, 9], [51, 7, 1, 9], [42, 6, 1, 10], [54, 13, 1, 3], [23, 32, 1, 7],
  ];
  for (const [x, y, w, h] of paths) rect(g, x, y, w, h, "d");
  // petak bunga taman
  for (const [x, y] of [[35, 28], [43, 28], [35, 33], [44, 33], [39, 33]]) g[y][x] = "f";
  return g;
}

export const OUT_GRID = buildOutdoor();

// ---------- Bangunan ----------
export interface BuildingDef {
  tex: string;
  tx: number; // tile kiri-atas
  ty: number;
  w: number; // ukuran px
  h: number;
  doorTile: [number, number];
  interior?: string;
  name: string;
}

export const BUILDINGS: BuildingDef[] = [
  { tex: "b_kos", tx: 8, ty: 4, w: 160, h: 128, doorTile: [10, 8], interior: "kos", name: "Kos Arunika" },
  { tex: "b_house_a", tx: 16, ty: 4, w: 96, h: 84, doorTile: [17, 7], name: "Rumah Warga" },
  { tex: "b_house_b", tx: 3, ty: 11, w: 96, h: 84, doorTile: [4, 14], name: "Rumah Warga" },
  { tex: "b_house_c", tx: 16, ty: 11, w: 96, h: 84, doorTile: [17, 14], name: "Rumah Warga" },
  // rumah warga baru (lebih banyak rumah)
  { tex: "b_house_d", tx: 21, ty: 4, w: 96, h: 84, doorTile: [22, 7], interior: "rumah_d", name: "Rumah Villa D" },
  { tex: "b_house_e", tx: 1, ty: 4, w: 96, h: 84, doorTile: [2, 7], name: "Rumah Warga" },
  { tex: "b_house_f", tx: 50, ty: 4, w: 96, h: 84, doorTile: [51, 7], interior: "rumah_f", name: "Rumah Keluarga F" },
  { tex: "b_house_g", tx: 41, ty: 4, w: 64, h: 64, doorTile: [42, 6], name: "Rumah Warga" },
  { tex: "b_house_h", tx: 53, ty: 11, w: 64, h: 64, doorTile: [54, 13], name: "Rumah Warga" },
  { tex: "b_house_i", tx: 22, ty: 30, w: 64, h: 64, doorTile: [23, 32], name: "Rumah Warga" },
  { tex: "b_kafe", tx: 36, ty: 4, w: 112, h: 96, doorTile: [37, 7], interior: "kafe", name: "Kafe Arunika" },
  { tex: "b_minimarket", tx: 45, ty: 9, w: 128, h: 96, doorTile: [46, 12], interior: "minimarket", name: "Minimarket Arunika" },
  { tex: "b_bengkel", tx: 8, ty: 22, w: 128, h: 88, doorTile: [9, 25], interior: "bengkel", name: "Bengkel Pak Budi" },
  { tex: "b_warung", tx: 37, ty: 22, w: 128, h: 96, doorTile: [38, 25], interior: "warung", name: "Warung Bu Sari" },
  { tex: "b_gazebo", tx: 34, ty: 30, w: 96, h: 76, doorTile: [35, 32], name: "Gazebo Taman" },
];

// ---------- Props ----------
export interface PropDef {
  tex: string;
  tx: number;
  ty: number; // tile tempat prop berdiri (basis)
  solid?: boolean;
  interact?: string; // id interaksi
}

const TREES: [number, number][] = [];
for (let x = 1; x < 59; x += 4) TREES.push([x, 0]);
for (let y = 2; y < 39; y += 3) {
  TREES.push([0, y]);
  TREES.push([59, y]);
}
for (let x = 2; x < 58; x += 4) TREES.push([x, 39]);
const PARK_TREES: [number, number][] = [[33, 28], [44, 27], [48, 31], [35, 34], [45, 34], [42, 33], [49, 25], [25, 27]];
const LAMPS: [number, number][] = [[6, 15], [22, 15], [34, 15], [50, 15], [6, 21], [22, 21], [34, 21], [50, 21], [26, 6], [26, 12], [26, 24], [26, 30], [32, 6], [32, 12], [32, 24], [32, 30]];
const BUSHES: [number, number][] = [[14, 15], [35, 8], [44, 12], [7, 15], [50, 27], [33, 35], [47, 35], [24, 30]];

export const PROPS: PropDef[] = [
  ...TREES.map((p, i): PropDef => ({ tex: i % 3 === 0 ? "p_tree2" : "p_tree1", tx: p[0], ty: p[1], solid: true })),
  ...PARK_TREES.map((p, i): PropDef => ({ tex: i % 2 ? "p_tree2" : "p_tree1", tx: p[0], ty: p[1], solid: true })),
  ...BUSHES.map((p): PropDef => ({ tex: "p_bush1", tx: p[0], ty: p[1], solid: false })),
  ...LAMPS.map((p): PropDef => ({ tex: "p_lamp", tx: p[0], ty: p[1], solid: true })),
  // bangku taman (interaksi duduk)
  { tex: "p_bench", tx: 36, ty: 27, solid: true, interact: "bench" },
  { tex: "p_bench", tx: 42, ty: 27, solid: true, interact: "bench" },
  { tex: "p_bench", tx: 34, ty: 34, solid: true, interact: "bench" },
  { tex: "p_bench", tx: 46, ty: 30, solid: true, interact: "bench" },
  { tex: "p_bench", tx: 14, ty: 9, solid: true, interact: "bench" },
  // tempat sampah (interaksi cari)
  { tex: "p_trash1", tx: 7, ty: 21, solid: true, interact: "trash" },
  { tex: "p_trash2", tx: 23, ty: 24, solid: true, interact: "trash" },
  { tex: "p_trash1", tx: 32, ty: 15, solid: true, interact: "trash" },
  { tex: "p_trash2", tx: 41, ty: 26, solid: true, interact: "trash" },
  { tex: "p_trash1", tx: 12, ty: 26, solid: true, interact: "trash" },
  // motor parkir
  { tex: "p_motor", tx: 24, ty: 15, solid: true, interact: "motor" },
  { tex: "p_motor", tx: 42, ty: 25, solid: true, interact: "motor" },
  { tex: "p_motor", tx: 12, ty: 21, solid: true, interact: "motor" },
  // meja & kursi plastik depan warung
  { tex: "p_table", tx: 35, ty: 25, solid: true },
  { tex: "p_chair_red", tx: 34, ty: 25, solid: false },
  { tex: "p_chair_blue", tx: 36, ty: 25, solid: false },
  // gerobak Bang Jefri
  { tex: "p_gerobak", tx: 33, ty: 21, solid: true, interact: "gerobak" },
  // basis kurir: kardus + papan
  { tex: "p_crate", tx: 20, ty: 22, solid: true, interact: "kurir_base" },
  { tex: "p_crate", tx: 22, ty: 22, solid: true, interact: "kurir_base" },
  { tex: "p_crate", tx: 20, ty: 23, solid: true, interact: "kurir_base" },
  { tex: "p_sign", tx: 22, ty: 23, solid: true, interact: "sign" },
  // air mancur taman
  { tex: "p_fountain", tx: 34, ty: 27, solid: false, interact: "fountain" },
  // pagar pembatas kos
  { tex: "p_fence", tx: 13, ty: 8, solid: true },
  { tex: "p_fence", tx: 14, ty: 8, solid: true },
  { tex: "p_fence", tx: 15, ty: 8, solid: true },
];

// ---------- POI (tujuan NPC) ----------
export const POI: Record<string, [number, number]> = {
  kos_door: [10, 8],
  house_a_door: [17, 7],
  house_b_door: [4, 14],
  house_c_door: [17, 14],
  house_d_door: [22, 7],
  house_e_door: [2, 7],
  house_f_door: [51, 7],
  house_g_door: [42, 6],
  house_h_door: [54, 13],
  house_i_door: [23, 32],
  kafe_door: [37, 7],
  minimarket_door: [46, 12],
  bengkel_door: [9, 25],
  warung_door: [38, 25],
  gazebo: [35, 32],
  park_center: [39, 29],
  park_bench1: [36, 28],
  park_bench2: [34, 34],
  kurir_base: [21, 24],
  gerobak: [33, 22],
  plaza_tengah: [25, 14],
  plaza_timur: [45, 14],
  gang_kardus: [17, 26],
  bengkel_yard: [14, 24],
};

// Spot kerja di dalam interior (untuk NPC "in:xxx")
export const INTERIOR_WORKSPOT: Record<string, Record<string, [number, number]>> = {
  warung: { bu_sari: [5, 2], alip: [7, 2] },
  minimarket: { maya: [5, 5], vanesa: [9, 4], sandra: [10, 4], pijar: [4, 4] },
  bengkel: { pak_budi: [5, 2], akbar: [9, 2] },
  kafe: { dinda: [3, 3], sinta: [9, 7], ali: [6, 7], deka: [2, 6], chelsea: [10, 5], aulia: [5, 2], defriska: [7, 2], yami: [4, 6], cindy: [2, 7], syifa: [10, 3] },
  rumah_d: { virly: [4, 3], eka: [7, 3], celyin: [2, 3] },
  rumah_f: { agata: [4, 4], cindy: [7, 4], yuno: [8, 4], syifa: [9, 5] },
};

// ---------- Interior ----------
export interface FixtureDef {
  tex: string;
  tx: number;
  ty: number;
  solid?: boolean;
  interact?: string; // bed|wardrobe|shower|desk|shop|job|look
  label?: string;
}

export interface InteriorDef {
  id: string;
  name: string;
  w: number;
  h: number;
  floor: "wood" | "ceramic" | "concrete";
  exitTile: [number, number];
  exitTo: [number, number]; // tile dunia saat keluar
  fixtures: FixtureDef[];
  shopId?: string;
}

function walls(w: number, h: number): string[][] {
  const g = makeGrid(w, h, ".");
  rect(g, 0, 0, w, 2, "#");
  return g;
}

export const INTERIORS: Record<string, InteriorDef> = {
  kos: {
    id: "kos",
    name: "Kamar Kos",
    w: 12,
    h: 9,
    floor: "wood",
    exitTile: [6, 8],
    exitTo: [10, 8],
    fixtures: [
      // Furnitur kamar dikelola state.furniture (bisa dipindah); fixture statis hanya shower.
      { tex: "p_shower", tx: 0, ty: 2, solid: true, interact: "shower", label: "Kamar Mandi" },
    ],
  },
  warung: {
    id: "warung",
    name: "Warung Bu Sari",
    w: 14,
    h: 10,
    floor: "ceramic",
    exitTile: [7, 9],
    exitTo: [38, 25],
    shopId: "warung",
    fixtures: [
      { tex: "p_counter", tx: 3, ty: 3, solid: true, interact: "shop", label: "Kasir Warung" },
      { tex: "p_counter", tx: 4, ty: 3, solid: true, interact: "shop", label: "Kasir Warung" },
      { tex: "p_counter", tx: 5, ty: 3, solid: true },
      { tex: "p_counter", tx: 6, ty: 3, solid: true, interact: "job", label: "Mulai Shift" },
      { tex: "p_menu", tx: 8, ty: 1, solid: false },
      { tex: "p_table", tx: 4, ty: 6, solid: true },
      { tex: "p_table", tx: 9, ty: 6, solid: true },
      { tex: "p_chair_red", tx: 3, ty: 7, solid: false },
      { tex: "p_chair_blue", tx: 5, ty: 7, solid: false },
      { tex: "p_chair_red", tx: 8, ty: 7, solid: false },
      { tex: "p_chair_blue", tx: 10, ty: 7, solid: false },
    ],
  },
  minimarket: {
    id: "minimarket",
    name: "Minimarket Arunika",
    w: 14,
    h: 10,
    floor: "ceramic",
    exitTile: [7, 9],
    exitTo: [46, 12],
    shopId: "minimarket",
    fixtures: [
      { tex: "p_shelf", tx: 3, ty: 3, solid: true, interact: "shop", label: "Rak" },
      { tex: "p_shelf", tx: 4, ty: 3, solid: true, interact: "shop", label: "Rak" },
      { tex: "p_shelf", tx: 3, ty: 4, solid: true, interact: "shop", label: "Rak" },
      { tex: "p_shelf", tx: 4, ty: 4, solid: true, interact: "shop", label: "Rak" },
      { tex: "p_shelf", tx: 8, ty: 3, solid: true, interact: "shop", label: "Rak" },
      { tex: "p_shelf", tx: 9, ty: 3, solid: true, interact: "shop", label: "Rak" },
      { tex: "p_fridge", tx: 11, ty: 3, solid: true, interact: "shop", label: "Kulkas Minuman" },
      { tex: "p_counter", tx: 5, ty: 6, solid: true },
      { tex: "p_counter", tx: 6, ty: 6, solid: true, interact: "job", label: "Mulai Shift" },
    ],
  },
  bengkel: {
    id: "bengkel",
    name: "Bengkel Pak Budi",
    w: 14,
    h: 9,
    floor: "concrete",
    exitTile: [7, 8],
    exitTo: [9, 25],
    shopId: "bengkel",
    fixtures: [
      { tex: "p_counter", tx: 3, ty: 3, solid: true, interact: "shop", label: "Meja Bengkel" },
      { tex: "p_counter", tx: 4, ty: 3, solid: true, interact: "shop", label: "Meja Bengkel" },
      { tex: "p_crate", tx: 10, ty: 3, solid: true, interact: "look", label: "Tumpukan Ban" },
      { tex: "p_crate", tx: 11, ty: 3, solid: true, interact: "look", label: "Tumpukan Ban" },
      { tex: "p_motor", tx: 10, ty: 6, solid: true, interact: "look", label: "Motor Servis" },
      { tex: "f_fan", tx: 12, ty: 2, solid: true, interact: "look", label: "Kipas Bengkel" },
    ],
  },
  kafe: {
    id: "kafe",
    name: "Kafe Arunika",
    w: 12,
    h: 9,
    floor: "wood",
    exitTile: [6, 8],
    exitTo: [37, 7],
    shopId: "kafe",
    fixtures: [
      { tex: "p_counter", tx: 2, ty: 4, solid: true, interact: "shop", label: "Counter Kafe" },
      { tex: "p_counter", tx: 3, ty: 4, solid: true },
      { tex: "p_counter", tx: 4, ty: 4, solid: true, interact: "shop", label: "Counter Kafe" },
      { tex: "p_menu", tx: 7, ty: 1, solid: false },
      { tex: "p_table", tx: 7, ty: 3, solid: true },
      { tex: "p_table", tx: 9, ty: 3, solid: true },
      { tex: "p_table", tx: 7, ty: 6, solid: true },
      { tex: "p_table", tx: 9, ty: 6, solid: true },
      { tex: "p_chair_red", tx: 6, ty: 4, solid: false },
      { tex: "p_chair_blue", tx: 8, ty: 4, solid: false },
      { tex: "p_chair_red", tx: 10, ty: 7, solid: false },
      { tex: "f_plant", tx: 0, ty: 2, solid: true, interact: "look", label: "Tanaman Kafe" },
      { tex: "f_plant", tx: 11, ty: 2, solid: true, interact: "look", label: "Tanaman Kafe" },
    ],
  },
  rumah_d: {
    id: "rumah_d",
    name: "Rumah Villa D",
    w: 12,
    h: 9,
    floor: "wood",
    exitTile: [6, 8],
    exitTo: [22, 7],
    fixtures: [
      { tex: "p_table", tx: 5, ty: 4, solid: true },
      { tex: "p_chair_red", tx: 4, ty: 4, solid: false },
      { tex: "p_chair_blue", tx: 6, ty: 4, solid: false },
      { tex: "f_rug", tx: 5, ty: 6, solid: false },
      { tex: "f_plant", tx: 1, ty: 2, solid: true, interact: "look", label: "Tanaman Teras" },
      { tex: "f_lamp", tx: 10, ty: 2, solid: true, interact: "look", label: "Lampu Ruang" },
      { tex: "f_wardrobe", tx: 10, ty: 5, solid: true, interact: "look", label: "Lemari Kayu" },
      { tex: "p_shelf", tx: 2, ty: 5, solid: true, interact: "look", label: "Rak Buku" },
    ],
  },
  rumah_f: {
    id: "rumah_f",
    name: "Rumah Keluarga F",
    w: 12,
    h: 9,
    floor: "ceramic",
    exitTile: [6, 8],
    exitTo: [51, 7],
    fixtures: [
      { tex: "p_counter", tx: 2, ty: 2, solid: true, interact: "look", label: "Dapur" },
      { tex: "p_counter", tx: 3, ty: 2, solid: true, interact: "look", label: "Dapur" },
      { tex: "p_fridge", tx: 9, ty: 2, solid: true, interact: "look", label: "Kulkas Keluarga" },
      { tex: "p_table", tx: 5, ty: 5, solid: true },
      { tex: "p_chair_red", tx: 4, ty: 5, solid: false },
      { tex: "p_chair_blue", tx: 6, ty: 5, solid: false },
      { tex: "f_rug", tx: 5, ty: 7, solid: false },
      { tex: "f_plant", tx: 10, ty: 6, solid: true, interact: "look", label: "Pot Bunga" },
    ],
  },
};

// ---------- Interaksi dunia ----------
export interface WorldInteract {
  id: string;
  type: "bench" | "trash" | "fountain" | "gerobak" | "kurir" | "sign" | "motor" | "cat" | "pond";
  tx: number;
  ty: number;
  label: string;
}

export const WORLD_INTERACTS: WorldInteract[] = [
  ...PROPS.filter((p) => p.interact === "bench").map((p, i): WorldInteract => ({ id: `bench_${i}`, type: "bench", tx: p.tx, ty: p.ty + 1, label: "Duduk" })),
  ...PROPS.filter((p) => p.interact === "trash").map((p, i): WorldInteract => ({ id: `trash_${i}`, type: "trash", tx: p.tx, ty: p.ty + 1, label: "Periksa Tempat Sampah" })),
  { id: "fountain", type: "fountain", tx: 35, ty: 29, label: "Lihat Air Mancur" },
  { id: "gerobak", type: "gerobak", tx: 33, ty: 22, label: "Jajan di Gerobak" },
  { id: "kurir", type: "kurir", tx: 21, ty: 24, label: "Ambil Paket (Kurir)" },
  { id: "sign", type: "sign", tx: 22, ty: 24, label: "Baca Papan" },
  ...PROPS.filter((p) => p.interact === "motor").map((p, i): WorldInteract => ({ id: `motor_${i}`, type: "motor", tx: p.tx, ty: p.ty + 1, label: "Lihat Motor" })),
  { id: "pond", type: "pond", tx: 42, ty: 28, label: "Lihat Kolam" },
  { id: "cat", type: "cat", tx: 16, ty: 26, label: "Periksa Gerombolan Kardus" },
];

// ---------- Walkability ----------
const OUT_SOLID_BUILDINGS = new Set<string>();
for (const b of BUILDINGS) {
  const tw = Math.ceil(b.w / TILE);
  const th = Math.ceil(b.h / TILE);
  const bottom = Math.min(th, b.interior ? th : th); // seluruh footprint solid; pintu di tile depan
  for (let y = b.ty; y < b.ty + bottom; y++)
    for (let x = b.tx; x < b.tx + tw; x++) OUT_SOLID_BUILDINGS.add(`${x},${y}`);
}
// gazebo: baris terdepan (lantai) bisa dilewati
{
  const gz = BUILDINGS.find((b) => b.tex === "b_gazebo")!;
  const tw = Math.ceil(gz.w / TILE);
  for (let x = gz.tx; x < gz.tx + tw; x++) OUT_SOLID_BUILDINGS.delete(`${x},${gz.ty + 2}`);
}

export const SOLID_PROPS = new Set(PROPS.filter((p) => p.solid).map((p) => `${p.tx},${p.ty}`));

export function outdoorWalkable(tx: number, ty: number): boolean {
  if (tx < 0 || ty < 0 || tx >= MAP_W || ty >= MAP_H) return false;
  const ch = OUT_GRID[ty][tx];
  if (ch === "w") return false;
  if (OUT_SOLID_BUILDINGS.has(`${tx},${ty}`)) return false;
  if (SOLID_PROPS.has(`${tx},${ty}`)) return false;
  return true;
}
