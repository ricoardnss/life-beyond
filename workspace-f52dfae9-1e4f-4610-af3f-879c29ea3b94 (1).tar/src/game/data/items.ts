// Katalog item — harga & efek terpusat (dipakai toko, minimarket, kafe, gerobak).
import type { ItemDef } from "../core/types";

export const ITEMS: Record<string, ItemDef> = {
  // ---- Makanan ----
  nasi_goreng: { id: "nasi_goreng", name: "Nasi Goreng", desc: "Nasi goreng spesial warung Bu Sari. Kenyang maksimal.", cat: "makanan", icon: "nasi_goreng", price: 12000, sell: 6000, stack: 10, effects: { lapar: 45, mood: 6 } },
  ayam_geprek: { id: "ayam_geprek", name: "Ayam Geprek", desc: "Pedasnya bikin nagih. Hati-hati kalau mood sedang naik.", cat: "makanan", icon: "ayam_geprek", price: 15000, sell: 7000, stack: 10, effects: { lapar: 50, mood: 8 } },
  mie_instan: { id: "mie_instan", name: "Mie Instan", desc: "Penyelamat akhir bulan. Cepat, murah, (agak) mengenyangkan.", cat: "makanan", icon: "mie_instan", price: 3500, sell: 1500, stack: 20, effects: { lapar: 28, mood: 2 } },
  roti: { id: "roti", name: "Roti Bungkus", desc: "Bekal praktis buat kurir yang sibuk.", cat: "makanan", icon: "roti", price: 5000, sell: 2000, stack: 15, effects: { lapar: 22 } },
  nasi_bungkus: { id: "nasi_bungkus", name: "Nasi Bungkus", desc: "Porsi warung bungkus, lengkap lauknya.", cat: "makanan", icon: "nasi_bungkus", price: 8000, sell: 3500, stack: 12, effects: { lapar: 35 } },
  // ---- Minuman ----
  es_teh: { id: "es_teh", name: "Es Teh", desc: "Manis dingin. Teman setia siang terik.", cat: "minuman", icon: "es_teh", price: 4000, sell: 1500, stack: 15, effects: { lapar: 5, mood: 4, energi: 4 } },
  kopi: { id: "kopi", name: "Kopi Dinda", desc: "Seduhan kafe Arunika. Bikin mata melek sempurna.", cat: "minuman", icon: "kopi", price: 8000, sell: 3000, stack: 15, effects: { energi: 22, mood: 5 } },
  air_botol: { id: "air_botol", name: "Air Botol", desc: "Paling sehat di antara semuanya.", cat: "minuman", icon: "air_botol", price: 3000, sell: 1000, stack: 20, effects: { lapar: 3, energi: 3 } },
  jus_jeruk: { id: "jus_jeruk", name: "Jus Jeruk", desc: "Segar, asam, manis. Mood naik pelan-pelan.", cat: "minuman", icon: "jus_jeruk", price: 7000, sell: 2500, stack: 15, effects: { mood: 9, lapar: 6 } },
  // ---- Bahan ----
  telur: { id: "telur", name: "Telur", desc: "Bahan dasar masakan apa pun.", cat: "bahan", icon: "telur", price: 2500, sell: 1000, stack: 20 },
  cabai: { id: "cabai", name: "Cabai", desc: "Wajib di dapur Indonesia.", cat: "bahan", icon: "cabai", price: 3000, sell: 1200, stack: 20 },
  beras: { id: "beras", name: "Beras", desc: "Sekantong beras berkualitas.", cat: "bahan", icon: "beras", price: 8000, sell: 3500, stack: 5 },
  // ---- Alat & lainnya ----
  sabun: { id: "sabun", name: "Sabun Mandi", desc: "Wajib punya kalau mau diakui ramai.", cat: "alat", icon: "sabun", price: 6000, sell: 2000, stack: 5 },
  obat: { id: "obat", name: "Vitamin", desc: "Pemulih energi cepat saat badan drop.", cat: "alat", icon: "obat", price: 9000, sell: 3000, stack: 5, effects: { energi: 35, mood: 3 } },
  buku: { id: "buku", name: "Novel Ringan", desc: "Bacaan santai di taman atau sebelum tidur.", cat: "alat", icon: "buku", price: 15000, sell: 6000, stack: 3, effects: { mood: 12 } },
  sketchbook: { id: "sketchbook", name: "Sketchbook Arunika", desc: "Buku sketsa favorit para seniman. Hadiah terbaik untuk Sinta.", cat: "khusus", icon: "sketchbook", price: 20000, sell: 8000, stack: 2 },
  // ---- Pakaian ----
  kaos: { id: "kaos", name: "Kaos Merah", desc: "Kaos santai. Bisa dipakai lewat lemari.", cat: "pakaian", icon: "kaos", price: 25000, sell: 10000, stack: 1, outfit: "kaos_merah" },
  jaket: { id: "jaket", name: "Jaket Denim", desc: "Gaya anak muda Arunika. Bisa dipakai lewat lemari.", cat: "pakaian", icon: "jaket", price: 60000, sell: 25000, stack: 1, outfit: "jaket_denim" },
  // ---- Khusus misi/kerja ----
  paket: { id: "paket", name: "Paket Kiriman", desc: "Wajib diantarkan tepat waktu. Jangan dibuka!", cat: "khusus", icon: "paket", price: 0, sell: 0, stack: 3 },
  sparepart: { id: "sparepart", name: "Sparepart Motor", desc: "Piston langka untuk bengkel Pak Budi.", cat: "khusus", icon: "sparepart", price: 30000, sell: 12000, stack: 2 },
  sampah: { id: "sampah", name: "Kantong Sampah", desc: "Dikumpulkan untuk kebersihan taman.", cat: "khusus", icon: "sampah", price: 0, sell: 0, stack: 10 },
  kucing: { id: "kucing", name: "Oyen (Kucing)", desc: "Kucing oren Tante Wati yang suka kabur. Kembalikan!", cat: "khusus", icon: "kucing", price: 0, sell: 0, stack: 1 },
  hadiah_bunga: { id: "hadiah_bunga", name: "Bunga Matahari", desc: "Hadiah sederhana yang selalu berbahagia.", cat: "khusus", icon: "hadiah_bunga", price: 10000, sell: 4000, stack: 5 },
  hadiah_kue: { id: "hadiah_kue", name: "Kue Kotak", desc: "Manis, cocok buat teman ngobrol.", cat: "khusus", icon: "hadiah_kue", price: 18000, sell: 7000, stack: 5 },
  // ---- Furnitur (tempat di kamar kos) ----
  furn_bed: { id: "furn_bed", name: "Kasur Single", desc: "Kasur nyaman untuk memulai hari.", cat: "furnitur", icon: "f_bed", price: 120000, sell: 50000, stack: 1, furniture: "f_bed" },
  furn_wardrobe: { id: "furn_wardrobe", name: "Lemari Kayu", desc: "Penyimpanan pakaian rapi.", cat: "furnitur", icon: "f_wardrobe", price: 80000, sell: 32000, stack: 1, furniture: "f_wardrobe" },
  furn_desk: { id: "furn_desk", name: "Meja Kerja", desc: "Meja untuk PC dan pekerjaan.", cat: "furnitur", icon: "f_desk", price: 65000, sell: 26000, stack: 1, furniture: "f_desk" },
  furn_chair: { id: "furn_chair", name: "Kursi Kayu", desc: "Pasangan meja kerja.", cat: "furnitur", icon: "f_chair", price: 20000, sell: 8000, stack: 2, furniture: "f_chair" },
  furn_fan: { id: "furn_fan", name: "Kipas Angin", desc: "Pendingin kamar klasik.", cat: "furnitur", icon: "f_fan", price: 45000, sell: 18000, stack: 1, furniture: "f_fan" },
  furn_rug: { id: "furn_rug", name: "Karpet Bulat", desc: "Membuat kamar terasa hangat.", cat: "furnitur", icon: "f_rug", price: 30000, sell: 12000, stack: 1, furniture: "f_rug" },
  furn_plant: { id: "furn_plant", name: "Tanaman Pot", desc: "Sedikit hijau menghangatkan suasana.", cat: "furnitur", icon: "f_plant", price: 18000, sell: 7000, stack: 2, furniture: "f_plant" },
  furn_lamp: { id: "furn_lamp", name: "Lampu Tidur", desc: "Cahaya kuning lembut.", cat: "furnitur", icon: "f_lamp", price: 25000, sell: 10000, stack: 1, furniture: "f_lamp" },
};

// Katalog toko per lokasi
export const SHOPS: Record<string, { name: string; npc: string; items: string[] }> = {
  warung: { name: "Warung Bu Sari", npc: "bu_sari", items: ["nasi_goreng", "ayam_geprek", "nasi_bungkus", "es_teh", "jus_jeruk", "telur", "cabai", "beras"] },
  minimarket: { name: "Minimarket Arunika", npc: "maya", items: ["mie_instan", "roti", "air_botol", "sabun", "obat", "kaos", "jaket", "furn_chair", "furn_plant", "furn_lamp"] },
  kafe: { name: "Kafe Arunika", npc: "dinda", items: ["kopi", "jus_jeruk", "roti", "hadiah_bunga", "hadiah_kue", "buku"] },
  gerobak: { name: "Gerobak Bang Jefri", npc: "bang_jefri", items: ["nasi_bungkus", "es_teh", "mie_instan"] },
  bengkel: { name: "Bengkel Pak Budi", npc: "pak_budi", items: ["sparepart"] },
};

// Furnitur yang bisa dibeli (dari minimarket & katalog premium Gems)
export const FURNITURE_SHOP = ["furn_chair", "furn_plant", "furn_lamp", "furn_rug", "furn_fan", "furn_desk", "furn_wardrobe", "furn_bed"];

export function item(id: string): ItemDef {
  const it = ITEMS[id];
  if (!it) throw new Error(`Item tidak ditemukan: ${id}`);
  return it;
}
