// Scene dunia outdoor — distrik Arunika Tengah.
import * as Phaser from "phaser";
import { MAP_H, MAP_W, OUT_GRID, BUILDINGS, PROPS, POI, WORLD_INTERACTS, outdoorWalkable } from "../data/mapdata";
import { TILE } from "../core/constants";
import { state } from "../core/state";
import { bus, EV } from "../core/bus";
import { NPCS, currentBlock, npcById } from "../data/npcs";
import { findPath } from "../systems/pathfind";
import { toast } from "../systems/systems";
import { finishShift, removeOnePaket, paketCount } from "../systems/jobs";
import { saveGame, autoSaveOnSleep } from "../core/save";
import { sleepUntilMorning } from "../systems/systems";
import { BaseScene, type InteractTarget } from "./BaseScene";
import { charTex, SEASON_LOOK } from "../sprites";

interface NpcView {
  id: string;
  sprite: Phaser.GameObjects.Sprite;
  shadow: Phaser.GameObjects.Image;
  path: [number, number][];
  targetPoi: string;
  wanderTimer: number;
}

const DELIVER_POIS = ["warung_door", "minimarket_door", "kafe_door", "bengkel_door", "kos_door", "gerobak", "park_center", "plaza_tengah", "gazebo", "house_d_door", "house_i_door", "plaza_timur"];

function charToTileIndex(ch: string, x: number, y: number): number {
  switch (ch) {
    case ",": return 1;
    case "f": return 12;
    case "d": return 3;
    case "r": return 4;
    case "-": return 5;
    case "|": return 6;
    case "x": return 7;
    case "s": return (x + y) % 3 === 0 ? 9 : 8;
    case "w": return 10;
    case "g": return 13;
    default: return (x * 7 + y * 13) % 9 === 0 ? 1 : (x + y) % 5 === 0 ? 2 : 0;
  }
}

export class WorldScene extends BaseScene {
  private ground!: Phaser.Tilemaps.TilemapLayer;
  private waterTiles: Phaser.Tilemaps.Tile[] = [];
  private waterFrame = 0;
  private npcs = new Map<string, NpcView>();
  private schedTimer = 0;
  private deliverTargets: [number, number][] = [];
  private deliverGfx!: Phaser.GameObjects.Graphics;
  private shiftStartedMin = 0;
  private npcNear: InteractTarget | null = null;
  private tintedTrees: Phaser.GameObjects.Image[] = [];
  private lastSeason = "";

  constructor() {
    super("WorldScene");
  }

  create(data: { spawnAt?: [number, number] } = {}) {
    // scene.start memakai ulang instance — bersihkan state transien dari run sebelumnya
    this.npcs.clear();
    this.deliverTargets = [];
    this.npcNear = null;
    // ground
    const map = this.make.tilemap({ tileWidth: TILE, tileHeight: TILE, width: MAP_W, height: MAP_H });
    const tiles = map.addTilesetImage("tiles", "tileset_outdoor", TILE, TILE, 0, 0)!;
    this.ground = map.createBlankLayer("ground", tiles)!;
    this.ground.setDepth(-10);
    for (let y = 0; y < MAP_H; y++) {
      for (let x = 0; x < MAP_W; x++) {
        const idx = charToTileIndex(OUT_GRID[y][x], x, y);
        const t = this.ground.putTileAt(idx, x, y);
        if (OUT_GRID[y][x] === "w") this.waterTiles.push(t);
      }
    }

    // bangunan & props (depth by y bawah)
    for (const b of BUILDINGS) {
      const bottomPx = (b.ty * TILE) + b.h;
      this.add.image(b.tx * TILE + b.w / 2, bottomPx, b.tex).setOrigin(0.5, 1).setDepth(bottomPx - 2);
    }
    for (const p of PROPS) {
      const img = this.textures.get(p.tex);
      const h = img.get().height;
      const bottomPx = p.ty * TILE + TILE;
      const go = this.add.image(p.tx * TILE + TILE / 2, bottomPx - 2, p.tex).setOrigin(0.5, 1).setDepth(bottomPx - 1);
      void h;
      // pohon di-tint per musim (dedaunan berganti warna)
      if (p.tex.startsWith("p_tree")) this.tintedTrees.push(go);
    }
    this.lastSeason = "";
    this.applySeasonLook();

    // glow lampu (muncul saat malam)
    const lampTiles = PROPS.filter((p) => p.tex === "p_lamp").map((p) => [p.tx, p.ty] as [number, number]);
    this.addLampGlows(lampTiles);

    // cahaya jendela rumah saat malam (sistem malam): dua titik hangat per bangunan
    const winGlows: [number, number][] = [];
    for (const b of BUILDINGS) {
      const baseY = b.ty * TILE + b.h * 0.52;
      winGlows.push([b.tx * TILE + b.w * 0.28, baseY]);
      winGlows.push([b.tx * TILE + b.w * 0.72, baseY]);
    }
    this.addWindowGlows(winGlows);

    // interaksi dunia
    this.interactables = [];
    for (const w of WORLD_INTERACTS) {
      this.interactables.push({
        id: w.id,
        tx: w.tx,
        ty: w.ty,
        label: w.label,
        run: () => this.handleWorldInteract(w.id),
      });
    }
    for (const b of BUILDINGS) {
      const label = b.interior ? `Masuk ${b.name}` : `Ketuk Pintu (${b.name})`;
      this.interactables.push({
        id: `door_${b.tex}`,
        tx: b.doorTile[0],
        ty: b.doorTile[1],
        label,
        run: () => this.enterBuilding(b.interior, b.name),
      });
    }

    this.deliverGfx = this.add.graphics().setDepth(8000);

    super.create();

    // spawn player
    const spawnAt = data.spawnAt ?? undefined;
    if (spawnAt) {
      this.player.setPosition(spawnAt[0] * TILE + TILE / 2, spawnAt[1] * TILE + TILE);
    } else if (state.get().scene?.map === "outdoor") {
      this.player.setPosition(state.get().scene!.x, state.get().scene!.y);
    } else if (state.get().scene && state.get().scene!.map !== "outdoor") {
      // dari save di interior — kembali ke depan kos saja
      this.player.setPosition(POI.kos_door[0] * TILE + TILE / 2, POI.kos_door[1] * TILE + TILE);
    }
    // refresh outfit texture
    this.applyOutfit();
    // jangan biarkan pemain terjebak di tile solid (mis. spawn di tile bangku)
    this.ensureFreeSpot();
    const offOutfit = bus.on("outfit_changed", () => this.applyOutfit());
    this.events.once("shutdown", offOutfit);
  }

  private applyOutfit() {
    const s = state.get();
    this.player.setTexture(charTex(s.outfit));
  }

  /** Terapkan tampilan musim: tint tanah + tint dedaunan pohon. */
  private applySeasonLook() {
    const s = state.get();
    if (s.season === this.lastSeason) return;
    this.lastSeason = s.season;
    const look = SEASON_LOOK[s.season] ?? SEASON_LOOK.semi;
    if (this.ground) this.ground.setTint(look.groundTint);
    for (const t of this.tintedTrees) t.setTint(look.leafTint);
  }

  mapPixelWidth() {
    return MAP_W * TILE;
  }

  mapPixelHeight() {
    return MAP_H * TILE;
  }

  isTileSolid(tx: number, ty: number): boolean {
    return !outdoorWalkable(tx, ty);
  }

  spawnContent() {
    /* NPC dikelola dinamis */
  }

  onInteract(target: InteractTarget) {
    target.run();
  }

  // ---------- Interaksi ----------
  private enterBuilding(interior: string | undefined, name: string) {
    if (!interior) {
      const replies = ["Tidak ada yang menjawab...", "Kamu mendengar TV dari dalam.", "Penduduk sedang keluar rumah, sepertinya.", "Pintu terkunci rapat."];
      toast(replies[Math.floor(Math.random() * replies.length)]);
      return;
    }
    const s = state.get();
    s.scene = { map: "outdoor", x: this.player.x, y: this.player.y };
    bus.emit(EV.TRANSITION, { to: interior });
    this.cameras.main.fadeOut(260, 12, 14, 22);
    this.time.delayedCall(280, () => {
      this.scene.start("InteriorScene", { id: interior });
    });
  }

  private handleWorldInteract(id: string) {
    if (id.startsWith("bench")) {
      toast("Kamu duduk sejenak. Pikiran jadi lebih tenang.");
      state.get().needs.mood = Math.min(100, state.get().needs.mood + 6);
      state.get().needs.energi = Math.min(100, state.get().needs.energi + 2);
    } else if (id.startsWith("trash")) {
      const s = state.get();
      const key = `trash_${id}`;
      if (s.flags[key] === s.day) {
        toast("Tempat sampah ini sudah kamu periksa hari ini.");
        return;
      }
      s.flags[key] = s.day;
      const roll = Math.random();
      if (roll < 0.55) {
        import("../systems/inventory").then(({ addItem }) => addItem("sampah", 1));
        s.stats.trashCollected += 1;
        toast("Kamu menemukan kantong sampah. Taman makin bersih!", "sukses");
      } else if (roll < 0.68) {
        state.get().money += 2000;
        toast("Ada Rp2.000 tergeletak. Hoki!", "sukses");
        bus.emit("sfx", { name: "coin" });
      } else {
        toast("Hanya daun kering dan sedikit debu.");
      }
      bus.emit(EV.STATE_CHANGED);
    } else if (id === "fountain") {
      toast("Air mancur berkilau di bawah cahaya. Mood kamu membaik.");
      state.get().needs.mood = Math.min(100, state.get().needs.mood + 8);
    } else if (id === "pond") {
      toast("Kolam tenang. Beberapa ikan kecil terlihat berenang.");
      state.get().needs.mood = Math.min(100, state.get().needs.mood + 4);
    } else if (id === "gerobak") {
      bus.emit(EV.SHOP_OPEN, { shopId: "gerobak" });
    } else if (id === "kurir") {
      bus.emit(EV.JOB_MINIGAME, { jobId: "kurir" });
    } else if (id === "sign") {
      toast("Papan: 'DISTRIK ARUNIKA TENGAH — Dibangun dengan bangga oleh warganya.'");
    } else if (id.startsWith("motor")) {
      toast("Motor parkir milik warga. Jangan disentuh ya.");
    } else if (id === "cat") {
      const s = state.get();
      const q = s.quests["q_kucing_hilang"];
      if (q && q.status === "aktif" && !s.flags.cat_found) {
        import("../systems/inventory").then(({ addItem }) => {
          addItem("kucing", 1);
          s.flags.cat_found = true;
          toast("Oyen menemukanmu! Dia mengeong pelan dan ikut di pelukan.", "sukses");
          bus.emit("sfx", { name: "pop" });
          bus.emit(EV.STATE_CHANGED);
        });
      } else if (s.flags.cat_found) {
        toast("Sisa kardus kosong. Oyen sudah aman di rumah.");
      } else {
        toast("Hanya tumpukan kardus tua dan jejak cakar...");
      }
    }
  }

  // ---------- NPC ----------
  updateNPCs(dt: number) {
    this.schedTimer -= dt;
    const s = state.get();
    const hour = Math.floor(s.timeMin / 60) % 24;

    if (this.schedTimer <= 0) {
      this.schedTimer = 2.5;
      for (const npc of NPCS) {
        const block = currentBlock(npc, hour);
        const indoors = block.poi.startsWith("in:");
        const hidden = block.activity === "home" || block.activity === "sleep";
        if (indoors || hidden) {
          this.despawnNpc(npc.id);
          continue;
        }
        const poi = POI[block.poi] ?? POI.park_center;
        let view = this.npcs.get(npc.id);
        if (!view) {
          const tex = charTex(npc.tex);
          const spawnTile = poi;
          const sprite = this.add.sprite(spawnTile[0] * TILE + TILE / 2, spawnTile[1] * TILE + TILE, tex).setOrigin(0.5, 0.9);
          const shadow = this.add.image(sprite.x, sprite.y, "shadow_tex").setDepth(sprite.depth - 0.1);
          view = { id: npc.id, sprite, shadow, path: [], targetPoi: block.poi, wanderTimer: Math.random() * 3 };
          this.npcs.set(npc.id, view);
          sprite.anims.play(`${tex}_idle_down`);
        } else if (view.targetPoi !== block.poi) {
          view.targetPoi = block.poi;
          view.path = findPath(outdoorWalkable, this.npcTile(view), poi);
        }
      }
    }

    for (const view of this.npcs.values()) {
      this.moveNpc(view, dt);
    }

    this.updateNpcInteract();
  }

  /** Target interaksi dinamis: NPC luar ruangan terdekat bisa diajak bicara. */
  private updateNpcInteract() {
    let bestId: string | null = null;
    let bestView: NpcView | null = null;
    let bestD = 52;
    for (const [id, v] of this.npcs) {
      const d = Phaser.Math.Distance.Between(this.player.x, this.player.y - 8, v.sprite.x, v.sprite.y - 8);
      if (d < bestD) {
        bestD = d;
        bestId = id;
        bestView = v;
      }
    }
    if (bestId && bestView) {
      const wantId = `npc_${bestId}`;
      const npcName = npcById(bestId).name;
      const npcRef = bestId;
      if (!this.npcNear || this.npcNear.id !== wantId) {
        if (this.npcNear) {
          const i = this.interactables.indexOf(this.npcNear);
          if (i >= 0) this.interactables.splice(i, 1);
        }
        this.npcNear = {
          id: wantId,
          tx: 0,
          ty: 0,
          radius: 60,
          label: `Bicara dengan ${npcName}`,
          run: () => bus.emit("npc_talk", { npcId: npcRef }),
        };
        this.interactables.push(this.npcNear);
      }
      this.npcNear.tx = Math.floor(bestView.sprite.x / TILE);
      this.npcNear.ty = Math.floor(bestView.sprite.y / TILE);
    } else if (this.npcNear) {
      const i = this.interactables.indexOf(this.npcNear);
      if (i >= 0) this.interactables.splice(i, 1);
      this.npcNear = null;
    }
  }

  private npcTile(v: NpcView): [number, number] {
    return [Math.floor(v.sprite.x / TILE), Math.floor(v.sprite.y / TILE)];
  }

  private despawnNpc(id: string) {
    const v = this.npcs.get(id);
    if (!v) return;
    v.sprite.destroy();
    v.shadow.destroy();
    this.npcs.delete(id);
  }

  private moveNpc(v: NpcView, dt: number) {
    const tex = v.sprite.texture.key;
    if (v.path.length > 0) {
      const [tx, ty] = v.path[0];
      const gx = tx * TILE + TILE / 2;
      const gy = ty * TILE + TILE;
      const dx = gx - v.sprite.x;
      const dy = gy - v.sprite.y;
      const d = Math.hypot(dx, dy);
      const speed = 46;
      if (d < 3) {
        v.path.shift();
        if (v.path.length === 0) {
          v.sprite.anims.play(`${tex}_idle_down`, true);
        }
      } else {
        const dir = Math.abs(dx) > Math.abs(dy) ? (dx > 0 ? "right" : "left") : dy > 0 ? "down" : "up";
        v.sprite.anims.play(`${tex}_walk_${dir}`, true);
        v.sprite.x += (dx / d) * speed * dt;
        v.sprite.y += (dy / d) * speed * dt;
      }
    } else {
      // berkeliaran kecil saat idle/social
      v.wanderTimer -= dt;
      if (v.wanderTimer <= 0) {
        v.wanderTimer = 4 + Math.random() * 6;
        const [cx, cy] = this.npcTile(v);
        const rx = cx + Math.floor(Math.random() * 5) - 2;
        const ry = cy + Math.floor(Math.random() * 5) - 2;
        if ((rx !== cx || ry !== cy) && outdoorWalkable(rx, ry)) {
          v.path = findPath(outdoorWalkable, [cx, ry === cy ? cy : cy], [rx, ry]);
        }
      }
    }
    v.sprite.setDepth(v.sprite.y);
    v.shadow.setPosition(v.sprite.x, v.sprite.y);
    v.shadow.setDepth(v.sprite.y - 0.1);
  }

  // ---------- Shift kurir ----------
  private updateKurirShift() {
    const s = state.get();
    if (!s.shift || s.shift.jobId !== "kurir") {
      this.deliverTargets = [];
      return;
    }
    if (this.deliverTargets.length === 0 && paketCount() > 0) {
      const shuffled = [...DELIVER_POIS].sort(() => Math.random() - 0.5).slice(0, Math.min(3, paketCount()));
      this.deliverTargets = shuffled.map((k) => POI[k]);
      toast(`${this.deliverTargets.length} tujuan pengiriman ditandai di peta.`, "info");
    }
    // auto-deliver saat dekat target
    if (this.deliverTargets.length > 0) {
      const [tx, ty] = this.deliverTargets[0];
      const d = Phaser.Math.Distance.Between(this.player.x, this.player.y, tx * TILE + TILE / 2, ty * TILE + TILE);
      if (d < 44) {
        removeOnePaket();
        this.deliverTargets.shift();
        bus.emit("sfx", { name: "coin" });
        toast(`Paket terkirim! Sisa ${paketCount()} paket.`, "sukses");
      }
    }
    if (paketCount() <= 0) {
      const done = 3;
      this.deliverTargets = [];
      finishShift({ deliveries: done });
    }
    // batas waktu shift (2 jam game)
    const elapsed = s.timeMin - s.shift.startedMin + (s.timeMin < s.shift.startedMin ? 1440 : 0);
    if (elapsed >= 120) {
      const delivered = 3 - paketCount();
      this.deliverTargets = [];
      finishShift({ deliveries: delivered });
      toast("Waktu shift kurir habis. Paket tersisa dikembalikan.", "peringatan");
    }
  }

  private drawDeliverMarkers() {
    this.deliverGfx.clear();
    if (this.deliverTargets.length === 0) return;
    const t = state.get().timeMin;
    const blink = 0.55 + 0.45 * Math.sin(t * 0.4);
    for (const [tx, ty] of this.deliverTargets) {
      this.deliverGfx.lineStyle(3, 0x4fd8e0, blink);
      this.deliverGfx.strokeCircle(tx * TILE + TILE / 2, ty * TILE + TILE / 2, 14 + 3 * blink);
    }
  }

  // ---------- Animasi air & update ----------
  update(time: number, delta: number) {
    super.update(time, delta);
    if (this.registry.get("paused")) return;
    this.applySeasonLook();
    // air beranimasi
    this.waterTimer -= delta;
    if (this.waterTimer <= 0) {
      this.waterTimer = 620;
      this.waterFrame ^= 1;
      for (const t of this.waterTiles) t.index = 10 + this.waterFrame;
    }
    this.updateKurirShift();
    this.drawDeliverMarkers();
  }

  private waterTimer = 0;
}

// Pintu masuk tidur (dipanggil dari React via bus)
bus.on("sleep_request", () => {
  sleepUntilMorning();
  autoSaveOnSleep();
  bus.emit("slept");
});
