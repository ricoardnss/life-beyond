// Scene interior (kos, warung, minimarket, bengkel, kafe).
import * as Phaser from "phaser";
import { INTERIORS, INTERIOR_WORKSPOT, outdoorWalkable } from "../data/mapdata";
import { TILE } from "../core/constants";
import { state } from "../core/state";
import { bus, EV } from "../core/bus";
import { NPCS, currentBlock } from "../data/npcs";
import { charTex } from "../sprites";
import { canPlace, kosSolidTiles, moveFurniture } from "../systems/furniture";
import { item } from "../data/items";
import { toast } from "../systems/systems";
import { BaseScene, type InteractTarget } from "./BaseScene";

const FLOOR_INDEX = { wood: 2, ceramic: 0, concrete: 4 } as const;

export class InteriorScene extends BaseScene {
  private def = INTERIORS.kos;
  private solid = new Set<string>();
  private furnitureSprites = new Map<string, Phaser.GameObjects.Image>();
  private placing: { itemId: string; uid?: string } | null = null;

  constructor() {
    super("InteriorScene");
  }

  create(data: { id?: string } = {}) {
    const id = data.id ?? "kos";
    this.def = INTERIORS[id] ?? INTERIORS.kos;

    const map = this.make.tilemap({ tileWidth: TILE, tileHeight: TILE, width: this.def.w, height: this.def.h });
    const tiles = map.addTilesetImage("tiles", "tileset_interior", TILE, TILE, 0, 0)!;
    const layer = map.createBlankLayer("floor", tiles)!;
    layer.setDepth(-10);
    for (let y = 0; y < this.def.h; y++) {
      for (let x = 0; x < this.def.w; x++) {
        let idx: number;
        if (y === 0) idx = 5;
        else if (y === 1) idx = 6;
        else if (x === 0 || x === this.def.w - 1 || y === this.def.h - 1) idx = 6; // dinding samping/bawah
        else if (x === this.def.exitTile[0] && y === this.def.exitTile[1]) idx = 7;
        else idx = FLOOR_INDEX[this.def.floor] + ((x + y) % 2);
        layer.putTileAt(idx, x, y);
      }
    }

    // collision interior
    this.rebuildSolid();

    // fixtures
    this.interactables = [];
    for (const fx of this.def.fixtures) {
      const tex = this.textures.get(fx.tex);
      const bottomPx = fx.ty * TILE + TILE + (tex.get().height > TILE + 10 ? 10 : 0);
      const img = this.add.image(fx.tx * TILE + TILE / 2, fx.ty * TILE + tex.get().height - (tex.get().height - TILE), fx.tex).setOrigin(0.5, 1).setDepth(fx.ty * TILE + TILE + 4);
      void bottomPx;
      if (fx.interact && fx.interact !== "shop" && fx.interact !== "job") {
        this.interactables.push({ id: `fx_${fx.tex}`, tx: fx.tx, ty: fx.ty + 1, label: fx.label ?? "Periksa", run: () => this.handleFixture(fx.interact!, fx.label ?? "") });
      } else if (fx.interact === "shop" && this.def.shopId) {
        this.interactables.push({ id: `shop_${fx.tx}`, tx: fx.tx, ty: fx.ty + 1, label: `Belanja — ${this.def.name}`, run: () => bus.emit(EV.SHOP_OPEN, { shopId: this.def.shopId }) });
      } else if (fx.interact === "job") {
        this.interactables.push({ id: `job_${fx.tx}`, tx: fx.tx, ty: fx.ty + 1, label: "Mulai Shift Kerja", run: () => bus.emit(EV.JOB_MINIGAME, { jobId: id === "warung" ? "warung" : "minimarket" }) });
      }
    }

    // exit
    this.interactables.push({
      id: "exit",
      tx: this.def.exitTile[0],
      ty: this.def.exitTile[1],
      label: `Keluar (${this.def.name})`,
      run: () => this.exitInterior(),
    });

    // NPC kerja di interior
    for (const npc of NPCS) {
      const spot = INTERIOR_WORKSPOT[id]?.[npc.id];
      if (!spot) continue;
      const block = currentBlock(npc, Math.floor(state.get().timeMin / 60) % 24);
      if (block.poi !== `in:${id}`) continue;
      const tex = charTex(npc.tex);
      const sprite = this.add.sprite(spot[0] * TILE + TILE / 2, spot[1] * TILE + TILE, tex).setOrigin(0.5, 0.9);
      sprite.setDepth(sprite.y);
      this.add.image(sprite.x, sprite.y, "shadow_tex").setDepth(sprite.depth - 0.1);
      sprite.anims.play(`${tex}_idle_down`);
      // Tile interaksi NPC: baris depan workspot (spot+2) agar tidak kalah
      // jarak dari fixture job/shop yang interaksinya memang di baris depan.
      // Fallback: spot+1, lalu tile NPC sendiri (mis. workspot mid-floor).
      let itx = spot[0];
      let ity = spot[1];
      for (const [cx, cy] of [[spot[0], spot[1] + 2], [spot[0], spot[1] + 1], [spot[0], spot[1]]]) {
        if (cx >= 1 && cx <= this.def.w - 2 && cy >= 2 && cy <= this.def.h - 2 && !this.solid.has(`${cx},${cy}`)) {
          itx = cx;
          ity = cy;
          break;
        }
      }
      this.interactables.push({
        id: `npc_${npc.id}`,
        tx: itx,
        ty: ity,
        label: `Bicara dengan ${npc.name}`,
        run: () => bus.emit("npc_talk", { npcId: npc.id }),
      });
    }

    super.create();

    // posisi awal: di pintu keluar (tile mat)
    const s = state.get();
    if (s.scene?.map === id) this.player.setPosition(s.scene.x, s.scene.y);
    else this.player.setPosition(this.def.exitTile[0] * TILE + TILE / 2, this.def.exitTile[1] * TILE + TILE - 6);

    this.applyOutfit();
    bus.on("outfit_changed", () => this.applyOutfit());

    // mode penempatan furnitur
    this.input.on("pointerdown", (pointer: Phaser.Input.Pointer) => {
      if (!this.placing) return;
      const wx = pointer.worldX;
      const wy = pointer.worldY;
      const tx = Math.floor(wx / TILE);
      const ty = Math.floor(wy / TILE);
      if (this.placing.uid) {
        if (moveFurniture(this.placing.uid, tx, ty)) {
          toast("Furnitur dipindah.", "sukses");
          this.rebuildSolid();
          this.rebuildFurnitureSprites();
          this.placing = null;
          this.registry.set("placing", null);
        }
      } else {
        import("../systems/furniture").then(({ placeFurniture }) => {
          if (placeFurniture(this.placing!.itemId, tx, ty)) {
            toast("Furnitur ditempatkan!", "sukses");
            this.rebuildSolid();
            this.rebuildFurnitureSprites();
            this.placing = null;
            this.registry.set("placing", null);
          }
        });
      }
    });
    const offFurnitureMode = bus.on(EV.FURNITURE_MODE, (p) => {
      const payload = p as { itemId?: string; uid?: string } | null;
      if (!payload) {
        this.placing = null;
        this.registry.set("placing", null);
      } else {
        this.placing = { itemId: payload.itemId!, uid: payload.uid };
        this.registry.set("placing", this.placing);
        toast(this.placing.uid ? "Klik tile untuk memindahkan furnitur." : "Klik tile kosong untuk menempatkan furnitur.");
      }
    });
    this.events.once("shutdown", offFurnitureMode);

    this.rebuildFurnitureSprites();
    // jangan biarkan pemain terjebak di tile solid
    this.ensureFreeSpot();
  }

  private applyOutfit() {
    const s = state.get();
    this.player.setTexture(charTex(s.outfit));
  }

  private rebuildFurnitureSprites() {
    const s = state.get();
    for (const [, img] of this.furnitureSprites) img.destroy();
    this.furnitureSprites.clear();
    for (const f of s.furniture) {
      const def = item(f.itemId);
      const tex = this.textures.get(def.furniture ?? f.itemId);
      const img = this.add.image(f.tx * TILE + TILE / 2, f.ty * TILE + tex.get().height, def.furniture ?? f.itemId).setOrigin(0.5, 1);
      img.setDepth(f.ty * TILE + TILE + 2);
      img.setInteractive({ useHandCursor: true });
      img.on("pointerdown", () => {
        if (!this.placing) {
          bus.emit("furniture_selected", { uid: f.uid, itemId: f.itemId });
        }
      });
      this.furnitureSprites.set(f.uid, img);
    }
  }

  rebuildSolid() {
    this.solid = new Set<string>();
    for (let y = 0; y < this.def.h; y++)
      for (let x = 0; x < this.def.w; x++) if (y < 2 || x === 0 || x === this.def.w - 1 || y === this.def.h - 1) this.solid.add(`${x},${y}`);
    for (const fx of this.def.fixtures) if (fx.solid) this.solid.add(`${fx.tx},${fx.ty}`);
    if (this.def.id === "kos") {
      const kosSolid = kosSolidTiles();
      // gabungkan (fixture kos sudah termasuk di dalamnya)
      this.solid = kosSolid;
    }
  }

  mapPixelWidth() {
    return this.def.w * TILE;
  }

  mapPixelHeight() {
    return this.def.h * TILE;
  }

  isTileSolid(tx: number, ty: number): boolean {
    return this.solid.has(`${tx},${ty}`);
  }

  spawnContent() {
    /* fixtures dibuat di create() */
  }

  updateNPCs(_dt: number) {
    /* NPC interior statis di spot kerja */
  }

  onInteract(target: InteractTarget) {
    target.run();
  }

  private handleFixture(kind: string, label: string) {
    const s = state.get();
    switch (kind) {
      case "bed":
        bus.emit("ask_sleep");
        break;
      case "wardrobe":
        bus.emit(EV.WARDROBE_OPEN);
        break;
      case "shower":
        s.needs.kebersihan = 100;
        s.needs.mood = Math.min(100, s.needs.mood + 6);
        toast("Kamu mandi segar. Kebersihan pulih!", "sukses");
        bus.emit("sfx", { name: "pop" });
        bus.emit(EV.STATE_CHANGED);
        break;
      case "desk":
        s.needs.mood = Math.min(100, s.needs.mood + 4);
        toast("Kamu menatap layar PC sebentar... email kosong, seperti biasa. Mood naik sedikit.");
        bus.emit(EV.STATE_CHANGED);
        break;
      default:
        toast(`${label}: tidak ada yang menarik.`);
    }
  }

  private exitInterior() {
    const s = state.get();
    s.scene = { map: this.def.id, x: this.player.x, y: this.player.y };
    bus.emit(EV.TRANSITION, { to: "outdoor" });
    this.cameras.main.fadeOut(260, 12, 14, 22);
    this.time.delayedCall(280, () => {
      this.scene.start("WorldScene", { spawnAt: this.def.exitTo });
    });
  }

  update(time: number, delta: number) {
    super.update(time, delta);
    if (this.placing && this.player) {
      // preview: tidak perlu; cukup cursor
      void canPlace;
      void outdoorWalkable;
    }
  }
}
