// Scene boot: preload semua aset, buat tekstur runtime, siapkan animasi.
import * as Phaser from "phaser";
import { AUDIO_KEYS, CHAR_H, CHAR_W, IMAGE_KEYS, NPC_KEYS, OUTFITS, createCharacterAnims } from "../sprites";

export class BootScene extends Phaser.Scene {
  constructor() {
    super("BootScene");
  }

  preload() {
    for (const key of IMAGE_KEYS) this.load.image(key, `/game/assets/${key}.png`);
    for (const outfit of OUTFITS) this.load.spritesheet(`player_${outfit}`, `/game/assets/player_${outfit}.png`, { frameWidth: CHAR_W, frameHeight: CHAR_H });
    for (const npc of NPC_KEYS) this.load.spritesheet(`npc_${npc}`, `/game/assets/npc_${npc}.png`, { frameWidth: CHAR_W, frameHeight: CHAR_H });
    this.load.spritesheet("icons_atlas", "/game/assets/icons.png", { frameWidth: 24, frameHeight: 24 });
    for (const a of AUDIO_KEYS) this.load.audio(a, `/game/audio/${a}.wav`);

    this.load.on("loaderror", (file: Phaser.Loader.File) => {
      console.error(`[KOTA KITA] Aset gagal dimuat: ${file.key} (${file.url})`);
    });
  }

  create() {
    // tekstur bayangan
    if (!this.textures.exists("shadow_tex")) {
      const g = this.textures.createCanvas("shadow_tex", 28, 10);
      const ctx = g!.getContext();
      const grad = ctx.createRadialGradient(14, 5, 1, 14, 5, 13);
      grad.addColorStop(0, "rgba(20,30,20,0.45)");
      grad.addColorStop(1, "rgba(20,30,20,0)");
      ctx.fillStyle = grad;
      ctx.fillRect(0, 0, 28, 10);
      g!.refresh();
    }
    // tekstur glow lampu
    if (!this.textures.exists("glow_tex")) {
      const g = this.textures.createCanvas("glow_tex", 96, 96);
      const ctx = g!.getContext();
      const grad = ctx.createRadialGradient(48, 48, 4, 48, 48, 46);
      grad.addColorStop(0, "rgba(255,225,150,0.55)");
      grad.addColorStop(0.5, "rgba(255,210,130,0.22)");
      grad.addColorStop(1, "rgba(255,200,110,0)");
      ctx.fillStyle = grad;
      ctx.fillRect(0, 0, 96, 96);
      g!.refresh();
    }
    // tekstur tetes hujan
    if (!this.textures.exists("rain_tex")) {
      const g = this.textures.createCanvas("rain_tex", 2, 10);
      const ctx = g!.getContext();
      ctx.fillStyle = "rgba(190,215,255,0.65)";
      ctx.fillRect(0, 0, 2, 10);
      g!.refresh();
    }
    // tekstur butir salju
    if (!this.textures.exists("snow_tex")) {
      const g = this.textures.createCanvas("snow_tex", 4, 4);
      const ctx = g!.getContext();
      ctx.fillStyle = "rgba(255,255,255,0.95)";
      ctx.beginPath();
      ctx.arc(2, 2, 1.8, 0, Math.PI * 2);
      ctx.fill();
      g!.refresh();
    }

    // animasi karakter
    for (const outfit of OUTFITS) createCharacterAnims(this, `player_${outfit}`);
    for (const npc of NPC_KEYS) createCharacterAnims(this, `npc_${npc}`);

    // lanjut ke scene sesuai save
    const saved = this.registry.get("savedScene") as string | undefined;
    const interiors = ["kos", "warung", "minimarket", "bengkel", "kafe", "rumah_d", "rumah_f"];
    if (saved && interiors.includes(saved)) this.scene.start("InteriorScene", { id: saved });
    else this.scene.start("WorldScene");
  }
}
