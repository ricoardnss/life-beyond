// Basis scene dunia/interior: pergerakan 8 arah + collision tile, waktu, musim, cuaca, interaksi.
import * as Phaser from "phaser";
import { GAME_MIN_PER_REAL_SEC, MAP_H, MAP_W, RUN_MULT, TILE } from "../core/constants";
import { state, timeStr } from "../core/state";
import { bus, EV } from "../core/bus";
import { canRun, speedFactor, tickNeeds, tickTime } from "../systems/systems";
import { charTex, dayNightTint, isNight, SEASON_LOOK, weatherTint } from "../sprites";
import type { Dir } from "../core/types";

export interface InteractTarget {
  id: string;
  tx: number;
  ty: number;
  label: string;
  radius?: number;
  run: () => void;
}

export abstract class BaseScene extends Phaser.Scene {
  player!: Phaser.GameObjects.Sprite;
  shadow!: Phaser.GameObjects.Image;
  overlay!: Phaser.GameObjects.Rectangle;
  seasonOverlay!: Phaser.GameObjects.Rectangle;
  weatherOverlay!: Phaser.GameObjects.Rectangle;
  dir: Dir = "down";
  moving = false;
  running = false;
  interactables: InteractTarget[] = [];
  currentInteract: InteractTarget | null = null;
  private music: Phaser.Sound.BaseSound | null = null;
  private musicMode: "day" | "night" | null = null;
  private rainSound: Phaser.Sound.BaseSound | null = null;
  private rainEmitter: Phaser.GameObjects.Particles.ParticleEmitter | null = null;
  private snowEmitter: Phaser.GameObjects.Particles.ParticleEmitter | null = null;
  private fogRects: Phaser.GameObjects.Rectangle[] = [];
  private lightningRect: Phaser.GameObjects.Rectangle | null = null;
  private lightningTimer = 0;
  private stars: Phaser.GameObjects.Rectangle[] = [];
  private starTimer = 0;
  private lampGlow: Phaser.GameObjects.Image[] = [];
  private windowGlow: Phaser.GameObjects.Image[] = [];
  private lastWeather = "";
  private lastHint = "";
  private stepTimer = 0;

  constructor(key: string) {
    super(key);
  }

  // ===== Dienturunkan =====
  abstract isTileSolid(tx: number, ty: number): boolean;
  abstract mapPixelWidth(): number;
  abstract mapPixelHeight(): number;
  abstract spawnContent(): void;
  abstract onInteract(target: InteractTarget): void;
  abstract updateNPCs(dt: number): void;

  create() {
    const s = state.get();
    const start = s.scene;
    const px = start ? start.x : this.mapPixelWidth() / 2;
    const py = start ? start.y : this.mapPixelHeight() / 2;

    this.spawnContent();

    this.player = this.add.sprite(px, py, charTex(`player_${s.outfit}`)).setOrigin(0.5, 0.9);
    this.player.setDepth(py);
    this.shadow = this.add.image(px, py, "shadow_tex").setDepth(py - 0.1);

    this.cameras.main.setBounds(0, 0, this.mapPixelWidth(), this.mapPixelHeight());
    this.cameras.main.startFollow(this.player, true, 0.14, 0.14);
    this.cameras.main.setRoundPixels(true);
    this.cameras.main.fadeIn(280, 12, 14, 22);

    // bintang malam (parallax lembut, terlihat hanya saat malam)
    this.stars = [];
    const rng = new Phaser.Math.RandomDataGenerator([`stars_${s.day}`]);
    for (let i = 0; i < 46; i++) {
      const size = rng.between(1, 2);
      const star = this.add.rectangle(rng.between(0, this.scale.width), rng.between(0, Math.floor(this.scale.height * 0.55)), size, size, 0xfff8e0, 0).setScrollFactor(0).setDepth(8800);
      this.stars.push(star);
    }

    this.overlay = this.add.rectangle(0, 0, this.scale.width + 8, this.scale.height + 8, 0xffffff, 0).setOrigin(0).setScrollFactor(0).setDepth(9000).setBlendMode(Phaser.BlendModes.MULTIPLY);
    this.seasonOverlay = this.add.rectangle(0, 0, this.scale.width + 8, this.scale.height + 8, 0xffffff, 0).setOrigin(0).setScrollFactor(0).setDepth(9010).setBlendMode(Phaser.BlendModes.MULTIPLY);
    this.weatherOverlay = this.add.rectangle(0, 0, this.scale.width + 8, this.scale.height + 8, 0xffffff, 0).setOrigin(0).setScrollFactor(0).setDepth(9020).setBlendMode(Phaser.BlendModes.MULTIPLY);

    // kabut (2 lapisan mengambang, hanya aktif saat cuaca kabut)
    this.fogRects = [];
    for (let i = 0; i < 2; i++) {
      const fog = this.add.rectangle(0, this.scale.height * (0.35 + i * 0.3), this.scale.width + 8, this.scale.height * 0.55, 0xe8ecf2, 0).setOrigin(0).setScrollFactor(0).setDepth(9600 + i);
      this.fogRects.push(fog);
    }

    // kilat badai
    this.lightningRect = this.add.rectangle(0, 0, this.scale.width + 8, this.scale.height + 8, 0xffffff, 0).setOrigin(0).setScrollFactor(0).setDepth(9700).setBlendMode(Phaser.BlendModes.ADD);

    // hujan
    this.rainEmitter = this.add.particles(0, 0, "rain_tex", {
      lifespan: 420,
      speedX: -40,
      speedY: 520,
      quantity: 6,
      frequency: 22,
      alpha: { start: 0.7, end: 0.3 },
      emitZone: { type: "random", source: new Phaser.Geom.Rectangle(-40, -40, this.scale.width + 120, 40), quantity: 1 } as never,
    }).setScrollFactor(0).setDepth(9500);
    this.rainEmitter.stop();

    // salju
    this.snowEmitter = this.add.particles(0, 0, "snow_tex", {
      lifespan: 5200,
      speedY: { min: 34, max: 62 },
      speedX: { min: -18, max: 18 },
      scale: { min: 0.6, max: 1.2 },
      alpha: { start: 0.9, end: 0.4 },
      quantity: 2,
      frequency: 55,
      emitZone: { type: "random", source: new Phaser.Geom.Rectangle(-40, -30, this.scale.width + 120, 30), quantity: 1 } as never,
    }).setScrollFactor(0).setDepth(9500);
    this.snowEmitter.stop();

    this.lastWeather = state.get().weather;
    this.applyWeatherFx();

    // input
    this.input.keyboard?.on("keydown-E", () => {
      if (this.registry.get("paused")) return;
      if (this.currentInteract) this.onInteract(this.currentInteract);
    });
    const offInteract = bus.on("interact_press", () => {
      if (this.registry.get("paused")) return;
      if (this.currentInteract) this.onInteract(this.currentInteract);
    });
    const offSfx = bus.on("sfx", (p) => {
      const name = (p as { name: string }).name;
      const vol = this.sfxVol();
      this.sound.play(`sfx_${name}`, { volume: vol });
    });
    this.events.once("shutdown", () => {
      offInteract();
      offSfx();
    });

    const onScaleResize = () => {
      if (this.overlay && this.overlay.active) {
        for (const r of [this.overlay, this.seasonOverlay, this.weatherOverlay, this.lightningRect]) {
          if (r && r.active) r.setSize(this.scale.width + 8, this.scale.height + 8);
        }
      }
    };
    this.scale.on("resize", onScaleResize);
    // Listener scale bersifat game-level — wajib dilepas saat scene berhenti/restart,
    // agar tidak menumpuk dan merujuk overlay yang sudah di-destroy (crash saat refresh).
    this.events.once("shutdown", () => {
      this.scale.off("resize", onScaleResize);
    });
  }

  sfxVol(): number {
    try {
      const st = JSON.parse(localStorage.getItem("kk_settings") || "{}");
      return (st.sfx ?? 0.8) as number;
    } catch {
      return 0.8;
    }
  }

  musicVol(): number {
    try {
      const st = JSON.parse(localStorage.getItem("kk_settings") || "{}");
      return (st.music ?? 0.5) as number;
    } catch {
      return 0.5;
    }
  }

  updateAudio() {
    const s = state.get();
    const hour = Math.floor(s.timeMin / 60) % 24;
    const mode: "day" | "night" = hour >= 5 && hour < 18 ? "day" : "night";
    if (mode !== this.musicMode || !this.music) {
      this.music?.stop();
      this.music = this.sound.add(mode === "day" ? "music_day" : "music_night", { loop: true, volume: this.musicVol() });
      if (!this.sound.mute) this.music.play();
      this.musicMode = mode;
    }
    (this.music as Phaser.Sound.WebAudioSound | null)?.setVolume(this.musicVol());

    const wantRain = s.weather === "hujan" || s.weather === "badai";
    const heavy = s.weather === "badai";
    if (wantRain && !this.rainSound) {
      this.rainSound = this.sound.add("rain", { loop: true, volume: this.musicVol() * (heavy ? 0.9 : 0.6) });
      this.rainSound.play();
    } else if (!wantRain && this.rainSound) {
      this.rainSound.stop();
      this.rainSound.destroy();
      this.rainSound = null;
    } else if (wantRain && this.rainSound) {
      (this.rainSound as Phaser.Sound.WebAudioSound | null)?.setVolume(this.musicVol() * (heavy ? 0.9 : 0.6));
    }
    if (this.rainEmitter) {
      if (wantRain && !this.rainEmitter.emitting) this.rainEmitter.start();
      else if (!wantRain && this.rainEmitter.emitting) this.rainEmitter.stop();
      if (wantRain) {
        // badai: deras; hujan biasa: sedang
        (this.rainEmitter as unknown as { quantity: number; frequency: number }).quantity = heavy ? 10 : 6;
        (this.rainEmitter as unknown as { quantity: number; frequency: number }).frequency = heavy ? 10 : 22;
      }
    }
    if (this.snowEmitter) {
      if (s.weather === "salju" && !this.snowEmitter.emitting) this.snowEmitter.start();
      else if (s.weather !== "salju" && this.snowEmitter.emitting) this.snowEmitter.stop();
    }
    const wantFog = s.weather === "kabut";
    for (const f of this.fogRects) f.setVisible(wantFog);
  }

  /** Terapkan efek visual perubahan cuaca (partikel dsb.) — dipanggil saat cuaca berubah. */
  private applyWeatherFx() {
    const s = state.get();
    if (s.weather === this.lastWeather) return;
    this.lastWeather = s.weather;
    this.updateAudio();
  }

  addLampGlows(list: [number, number][]) {
    this.lampGlow = list.map(([tx, ty]) =>
      this.add.image(tx * TILE + TILE / 2, ty * TILE + 4, "glow_tex").setDepth(9200).setBlendMode(Phaser.BlendModes.ADD)
    );
  }

  /** Cahaya hangat dari jendela rumah saat malam (sistem malam). */
  addWindowGlows(list: [number, number][]) {
    this.windowGlow = list.map(([x, y]) =>
      this.add.image(x, y, "glow_tex").setScale(0.42).setDepth(9190).setBlendMode(Phaser.BlendModes.ADD).setAlpha(0)
    );
  }

  updateOverlay() {
    const s = state.get();
    const hour = Math.floor(s.timeMin / 60) % 24;
    const t = dayNightTint(hour);
    const ov = this.overlay;
    if (ov) {
      ov.fillColor = t.color;
      ov.setAlpha(t.alpha);
    }
    // tint musim + cuaca (multiply bertumpuk di atas siang-malam)
    const sl = SEASON_LOOK[s.season] ?? SEASON_LOOK.semi;
    if (this.seasonOverlay) {
      this.seasonOverlay.fillColor = sl.skyTint;
      this.seasonOverlay.setAlpha(sl.skyAlpha);
    }
    const wt = weatherTint(s.weather);
    if (this.weatherOverlay) {
      this.weatherOverlay.fillColor = wt.color;
      this.weatherOverlay.setAlpha(wt.alpha);
    }
    const glowAlpha = isNight(hour) ? 1 : hour >= 18 ? 0.6 : 0;
    for (const g of this.lampGlow) g.setAlpha(glowAlpha);
    for (const g of this.windowGlow) g.setAlpha(isNight(hour) ? 0.75 : 0);
    // bintang hanya di malam hari
    const starAlpha = isNight(hour) ? 0.85 : hour >= 18 ? 0.35 : 0;
    for (const st of this.stars) {
      if (st.active) st.setFillStyle(0xfff8e0, starAlpha);
    }
  }

  // ===== Pergerakan & collision =====
  movePlayer(dt: number) {
    const s = state.get();
    if (this.registry.get("paused")) return;
    const kb = this.input.keyboard!;
    const left = kb.addKey("A").isDown || kb.addKey("LEFT").isDown;
    const right = kb.addKey("D").isDown || kb.addKey("RIGHT").isDown;
    const up = kb.addKey("W").isDown || kb.addKey("UP").isDown;
    const down = kb.addKey("S").isDown || kb.addKey("DOWN").isDown;
    // kontrol sentuh dari React
    const joy = this.registry.get("joy") as { x: number; y: number } | undefined;

    let vx = (right ? 1 : 0) - (left ? 1 : 0);
    let vy = (down ? 1 : 0) - (up ? 1 : 0);
    if (joy && (joy.x !== 0 || joy.y !== 0)) {
      vx = joy.x;
      vy = joy.y;
    }
    const mag = Math.hypot(vx, vy);
    this.moving = mag > 0.01;
    // lari: Shift (desktop) atau tombol LARI sentuh
    const holdRun = kb.addKey("SHIFT").isDown || this.registry.get("touchRun") === true;
    this.running = this.moving && holdRun && canRun();

    if (!this.moving) {
      this.player.anims.play(`${charTex(s.outfit)}_idle_${this.dir}`, true);
      this.registry.set("joy", { x: 0, y: 0 });
      return;
    }
    if (mag > 1) {
      vx /= mag;
      vy /= mag;
    }
    const speed = 92 * speedFactor() * (this.running ? RUN_MULT : 1);
    const dx = vx * speed * dt;
    const dy = vy * speed * dt;

    // arah dominan
    if (Math.abs(vx) > Math.abs(vy)) this.dir = vx > 0 ? "right" : "left";
    else this.dir = vy > 0 ? "down" : "up";

    // collision AABB kaki (slide per sumbu) — tidak bisa menembus dinding
    const w = 18;
    const h = 10;
    const nx = this.player.x + dx;
    if (!this.collides(nx, this.player.y, w, h)) this.player.x = nx;
    const ny = this.player.y + dy;
    if (!this.collides(this.player.x, ny, w, h)) this.player.y = ny;

    this.player.x = Phaser.Math.Clamp(this.player.x, TILE, this.mapPixelWidth() - TILE);
    this.player.y = Phaser.Math.Clamp(this.player.y, TILE + 20, this.mapPixelHeight() - TILE);

    this.player.anims.play(`${charTex(s.outfit)}_walk_${this.dir}`, true);
    s.stats.distanceWalked += speed * dt;
    if (this.running) s.needs.energi = Math.max(0, s.needs.energi - 0.25 * dt);

    // langkah kaki
    this.stepTimer -= dt * (this.running ? 1.6 : 1);
    if (this.stepTimer <= 0) {
      this.stepTimer = 0.32;
      this.sound.play("sfx_step", { volume: this.sfxVol() * 0.4 });
    }
  }

  private collides(cx: number, cy: number, w: number, h: number): boolean {
    const x0 = cx - w / 2;
    const x1 = cx + w / 2;
    const y0 = cy - h; // kaki
    const y1 = cy - 1;
    const corners = [
      [x0, y0], [x1, y0], [x0, y1], [x1, y1],
      [cx, y0], [cx, y1], [x0, cy - h / 2], [x1, cy - h / 2],
    ];
    for (const [x, y] of corners) {
      if (this.isTileSolid(Math.floor(x / TILE), Math.floor(y / TILE))) return true;
    }
    return false;
  }

  scanInteracts() {
    let best: InteractTarget | null = null;
    let bestD = Infinity;
    for (const t of this.interactables) {
      const d = Phaser.Math.Distance.Between(this.player.x, this.player.y - 8, t.tx * TILE + TILE / 2, t.ty * TILE + TILE / 2);
      const r = (t.radius ?? 46);
      if (d < r && d < bestD) {
        best = t;
        bestD = d;
      }
    }
    this.currentInteract = best;
    // Label mentah saja — UI yang menyematkan prefix [E] (desktop) atau tombol aksi (sentuh).
    const hint = best ? best.label : "";
    if (hint !== this.lastHint) {
      this.lastHint = hint;
      bus.emit(EV.INTERACT_HINT, hint || null);
    }
  }

  savePosition(map: string) {
    const s = state.get();
    s.scene = { map, x: this.player.x, y: this.player.y };
  }

  /**
   * Safety valve: bila kotak collision pemain menabrak tile solid (save lama/kasus tepi),
   * geser ke posisi bebas terdekat agar tidak terjebak permanen.
   */
  protected ensureFreeSpot(radius = 6) {
    if (!this.player) return;
    const w = 18;
    const h = 10;
    if (!this.collides(this.player.x, this.player.y, w, h)) return;
    const tx = Math.floor(this.player.x / TILE);
    const ty = Math.floor(this.player.y / TILE);
    for (let r = 1; r <= radius; r++) {
      for (let dy = -r; dy <= r; dy++) {
        for (let dx = -r; dx <= r; dx++) {
          if (Math.max(Math.abs(dx), Math.abs(dy)) !== r) continue;
          const px = (tx + dx) * TILE + TILE / 2;
          const py = (ty + dy) * TILE + TILE;
          if (!this.collides(px, py, w, h)) {
            this.player.setPosition(px, py);
            const s = state.get();
            if (s.scene) {
              s.scene.x = px;
              s.scene.y = py;
            }
            return;
          }
        }
      }
    }
  }

  /** Efek cuaca per-frame: kabut mengambang + kilat badai. */
  private updateWeatherAnim(dt: number, timeMs: number) {
    const s = state.get();
    // kabut: dua lapisan naik-turun + geser pelan
    if (s.weather === "kabut") {
      this.fogRects.forEach((f, i) => {
        const t = timeMs / 1000;
        f.setAlpha(0.22 + 0.1 * Math.sin(t * 0.35 + i * 2.1));
        f.x = -4 + ((t * (6 + i * 4)) % (this.scale.width + 8)) - (i === 1 ? this.scale.width / 2 : 0);
      });
    }
    // badai: kilat acak + guntur
    if (s.weather === "badai" && this.lightningRect) {
      this.lightningTimer -= dt;
      if (this.lightningTimer <= 0) {
        this.lightningTimer = 4 + Math.random() * 8;
        const lr = this.lightningRect;
        lr.setAlpha(0.72);
        this.tweens.add({ targets: lr, alpha: 0, duration: 260, ease: "Quad.easeOut" });
        this.time.delayedCall(200 + Math.random() * 500, () => {
          if (this.sound && this.cache.audio.exists("thunder")) {
            this.sound.play("thunder", { volume: this.sfxVol() * 0.9 });
          }
        });
      }
    }
    // bintang berkelip
    this.starTimer -= dt;
    if (this.starTimer <= 0) {
      this.starTimer = 0.9;
      const hour = Math.floor(s.timeMin / 60) % 24;
      if (isNight(hour)) {
        for (const st of this.stars) {
          if (st.active) st.setFillStyle(0xfff8e0, 0.4 + Math.random() * 0.55);
        }
      }
    }
  }

  update(_time: number, delta: number) {
    const dt = Math.min(delta / 1000, 0.05);
    if (this.registry.get("paused")) {
      this.updateOverlay();
      return;
    }
    tickTime(dt, GAME_MIN_PER_REAL_SEC);
    tickNeeds(dt, GAME_MIN_PER_REAL_SEC, {
      running: this.running,
      walking: this.moving,
      rain: state.get().weather === "hujan" || state.get().weather === "badai",
    });
    this.movePlayer(dt);
    this.shadow.setPosition(this.player.x, this.player.y);
    this.shadow.setDepth(this.player.depth - 0.1);
    this.player.setDepth(this.player.y);
    this.updateNPCs(dt);
    this.scanInteracts();
    this.updateOverlay();
    this.updateAudio();
    this.updateWeatherAnim(dt, _time);
    this.applyWeatherFx();
    // jam UI (throttle)
    this.uiTimer -= dt;
    if (this.uiTimer <= 0) {
      this.uiTimer = 1;
      bus.emit("clock", { time: timeStr(state.get().timeMin) });
    }
  }

  private uiTimer = 0;
}
