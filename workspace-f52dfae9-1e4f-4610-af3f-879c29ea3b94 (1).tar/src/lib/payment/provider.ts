// Adapter payment — gateway bisa diganti tanpa menyentuh sistem order (Bagian F-4).

export type WebhookOutcome = "paid" | "failed" | "expired" | "refund" | "pending";

export interface ParsedWebhook {
  valid: boolean; // signature valid
  eventId: string; // id unik event dari gateway (kunci idempotensi)
  orderId: string;
  outcome: WebhookOutcome;
  amountIdr: number;
  currency: string;
  providerRef?: string;
  raw: unknown;
}

export interface CreatePaymentResult {
  provider: string;
  providerRef: string;
  redirectUrl: string;
  expiresAt: string;
  mode: "development" | "sandbox" | "production";
}

export interface PaymentProvider {
  id: string;
  mode: "development" | "sandbox" | "production";
  createPayment(order: { id: string; amountIdr: number; gems: number; userId: string; productName: string }): Promise<CreatePaymentResult>;
  parseWebhook(headers: Headers, rawBody: string): ParsedWebhook;
}

export function activeProviderId(): string {
  return process.env.PAYMENT_PROVIDER || "mockpay";
}

export function providerIsConfigured(id: string): boolean {
  switch (id) {
    case "mockpay":
      return true; // selalu tersedia, tapi berstatus DEVELOPMENT ONLY
    case "midtrans":
      return Boolean(process.env.MIDTRANS_SERVER_KEY && process.env.MIDTRANS_CLIENT_KEY);
    default:
      return false;
  }
}

export async function getProvider(id?: string): Promise<PaymentProvider> {
  const pid = id || activeProviderId();
  switch (pid) {
    case "midtrans": {
      const mod = await import("./midtrans");
      return new mod.MidtransSnapProvider();
    }
    case "mockpay":
    default: {
      const mod = await import("./mock");
      return new mod.MockPayProvider();
    }
  }
}
