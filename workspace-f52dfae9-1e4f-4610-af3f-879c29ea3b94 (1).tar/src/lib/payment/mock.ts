// MockPay — PROVIDER MOCK, STATUS: DEVELOPMENT ONLY.
// Tidak pernah menghubungi jaringan. Dipakai hanya saat kredensial gateway produksi belum tersedia.
// Seluruh UI yang memakai provider ini WAJIB menampilkan label DEVELOPMENT ONLY.
import { createHmac, randomUUID } from "crypto";
import type { CreatePaymentResult, ParsedWebhook, PaymentProvider } from "./provider";

export const MOCKPAY_SECRET = process.env.MOCKPAY_SECRET || "mockpay-dev-secret-DEVELOPMENT-ONLY";

function sign(parts: string[]): string {
  return createHmac("sha256", MOCKPAY_SECRET).update(parts.join("|")).digest("hex");
}

export class MockPayProvider implements PaymentProvider {
  id = "mockpay";
  mode: "development" = "development";

  async createPayment(order: { id: string; amountIdr: number; gems: number }): Promise<CreatePaymentResult> {
    const expiresAt = new Date(Date.now() + 1000 * 60 * 60).toISOString();
    return {
      provider: this.id,
      providerRef: `mock_${randomUUID()}`,
      // halaman "gateway" simulasi internal (hash route SPA), berlabel DEVELOPMENT ONLY
      redirectUrl: `#/store/pay/${encodeURIComponent(order.id)}`,
      expiresAt,
      mode: "development",
    };
  }

  parseWebhook(headers: Headers, rawBody: string): ParsedWebhook {
    let body: Record<string, unknown>;
    try {
      body = JSON.parse(rawBody);
    } catch {
      return { valid: false, eventId: "", orderId: "", outcome: "failed", amountIdr: 0, currency: "IDR", raw: rawBody };
    }
    const eventId = String(body.event_id ?? "");
    const orderId = String(body.order_id ?? "");
    const outcomeRaw = String(body.outcome ?? "");
    const amountIdr = Number(body.amount_idr ?? -1);
    const currency = String(body.currency ?? "IDR");
    const signature = String(body.signature ?? "");
    const expected = sign([eventId, orderId, outcomeRaw, String(amountIdr), currency]);

    if (!eventId || !orderId || !signature || signature !== expected) {
      return { valid: false, eventId, orderId, outcome: "failed", amountIdr, currency, raw: body };
    }
    const outcome = (["paid", "failed", "expired", "refund", "pending"] as const).includes(outcomeRaw as never)
      ? (outcomeRaw as ParsedWebhook["outcome"])
      : "failed";
    return { valid: true, eventId, orderId, outcome, amountIdr, currency, raw: body };
  }

  /** Dipakai halaman mock checkout untuk MEMBENTUK payload webhook tersignature (simulasi gateway). */
  static buildSignedWebhook(eventId: string, orderId: string, outcome: string, amountIdr: number, currency = "IDR"): string {
    const signature = sign([eventId, orderId, outcome, String(amountIdr), currency]);
    return JSON.stringify({ event_id: eventId, order_id: orderId, outcome, amount_idr: amountIdr, currency, signature, provider: "mockpay" });
  }
}
