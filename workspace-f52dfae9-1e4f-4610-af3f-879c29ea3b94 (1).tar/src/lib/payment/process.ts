// Prosesor webhook payment — JANTUNG KEAMANAN transaksi (Bagian F-3/F-5).
// Prinsip: harga dari DB, verifikasi signature backend, idempotensi via PaymentEvent unik
// + unique constraint ledger(reason,refId), update saldo ATOMIK (transaction), saldo tak pernah negatif.
import { db } from "@/lib/db";
import { audit } from "@/lib/api-helpers";
import type { ParsedWebhook, PaymentProvider } from "./provider";

export interface ProcessResult {
  httpStatus: number;
  message: string;
  duplicate?: boolean;
  invalid?: boolean;
  orderId?: string;
}

export async function processWebhook(provider: PaymentProvider, headers: Headers, rawBody: string): Promise<ProcessResult> {
  const parsed: ParsedWebhook = provider.parseWebhook(headers, rawBody);

  // 1) signature wajib valid
  if (!parsed.valid) {
    try {
      await db.paymentEvent.create({
        data: {
          providerEventId: parsed.eventId || `invalid_${Date.now()}_${Math.random().toString(36).slice(2)}`,
          provider: provider.id,
          eventType: "invalid_signature",
          signatureValid: false,
          payload: rawBody.slice(0, 4000),
        },
      });
    } catch { /* duplikat event invalid: abaikan */ }
    return { httpStatus: 403, message: "Signature webhook tidak valid.", invalid: true };
  }

  // 2) catat event sekali (unique providerEventId) — idempotensi level event
  try {
    await db.paymentEvent.create({
      data: {
        providerEventId: parsed.eventId,
        orderId: parsed.orderId,
        provider: provider.id,
        eventType: parsed.outcome,
        signatureValid: true,
        payload: rawBody.slice(0, 4000),
      },
    });
  } catch {
    // event duplikat dari gateway — jangan proses dua kali
    return { httpStatus: 200, message: "Event sudah pernah diproses (idempoten).", duplicate: true, orderId: parsed.orderId };
  }

  // 3) order harus ada
  const order = await db.order.findUnique({ where: { id: parsed.orderId }, include: { product: true } });
  if (!order) {
    return { httpStatus: 404, message: "Order tidak ditemukan.", orderId: parsed.orderId };
  }

  // 4) validasi nominal & mata uang dari sumber tepercaya (DB)
  if (parsed.outcome === "paid" || parsed.outcome === "refund") {
    if (parsed.amountIdr !== order.amountIdr || parsed.currency !== order.currency) {
      return { httpStatus: 400, message: "Nominal/mata uang webhook tidak cocok dengan order.", orderId: order.id };
    }
  }

  // 5) transisi status
  if (parsed.outcome === "paid") {
    if (order.status !== "pending") {
      return { httpStatus: 200, message: `Order sudah berstatus ${order.status} (tidak diproses ulang).`, duplicate: true, orderId: order.id };
    }
    try {
      // ATOMIK: order -> paid; wallet += gems; ledger insert (unique reason+refId mencegah kredit ganda)
      await db.$transaction(async (tx) => {
        await tx.order.update({ where: { id: order.id, status: "pending" }, data: { status: "paid", paidAt: new Date(), providerRef: parsed.providerRef ?? order.providerRef } });
        const wallet = await tx.premiumWallet.upsert({
          where: { userId: order.userId },
          update: { balance: { increment: order.gems } },
          create: { userId: order.userId, balance: order.gems },
        });
        await tx.premiumLedger.create({
          data: {
            userId: order.userId,
            delta: order.gems,
            balanceAfter: wallet.balance,
            reason: "topup",
            refType: "order",
            refId: order.id,
            note: `${order.gems} Gems via ${provider.id}`,
          },
        });
        await tx.order.update({ where: { id: order.id }, data: { status: "fulfilled", fulfilledAt: new Date() } });
      });
      return { httpStatus: 200, message: "Pembayaran diterima, Gems dikirim.", orderId: order.id };
    } catch (e) {
      console.error("[webhook] gagal kredit atomik", e);
      return { httpStatus: 500, message: "Gagal memproses kredit (akan dicoba ulang gateway).", orderId: order.id };
    }
  }

  if (parsed.outcome === "failed" || parsed.outcome === "expired") {
    if (order.status !== "pending") {
      return { httpStatus: 200, message: `Order sudah berstatus ${order.status}.`, duplicate: true, orderId: order.id };
    }
    await db.order.update({ where: { id: order.id }, data: { status: parsed.outcome === "expired" ? "expired" : "failed" } });
    return { httpStatus: 200, message: `Order ditandai ${parsed.outcome}.`, orderId: order.id };
  }

  if (parsed.outcome === "refund") {
    if (!["paid", "fulfilled"].includes(order.status)) {
      return { httpStatus: 400, message: "Refund hanya untuk order paid/fulfilled.", orderId: order.id };
    }
    const done = await refundOrderInternal(order.id, provider.id, "refund_webhook");
    return done.httpStatus === 200
      ? { httpStatus: 200, message: "Refund diproses, Gems ditarik kembali.", orderId: order.id }
      : done;
  }

  return { httpStatus: 200, message: "Webhook pending dicatat.", orderId: order.id };
}

/** Refund internal (admin / webhook). Saldo tidak boleh negatif. */
export async function refundOrderInternal(orderId: string, actor: string, source: "admin" | "refund_webhook", actorInfo?: { id: string; email: string }): Promise<ProcessResult> {
  const order = await db.order.findUnique({ where: { id: orderId } });
  if (!order) return { httpStatus: 404, message: "Order tidak ditemukan." };
  if (!["paid", "fulfilled"].includes(order.status)) {
    return { httpStatus: 400, message: "Refund hanya berlaku untuk order berstatus paid/fulfilled." };
  }
  try {
    await db.$transaction(async (tx) => {
      const wallet = await tx.premiumWallet.findUnique({ where: { userId: order.userId } });
      const balance = wallet?.balance ?? 0;
      const deduct = Math.min(order.gems, balance); // saldo tidak boleh negatif
      const newBalance = balance - deduct;
      await tx.premiumWallet.upsert({
        where: { userId: order.userId },
        update: { balance: newBalance },
        create: { userId: order.userId, balance: newBalance },
      });
      await tx.premiumLedger.create({
        data: {
          userId: order.userId,
          delta: -deduct,
          balanceAfter: newBalance,
          reason: "refund",
          refType: "order",
          refId: order.id,
          note: deduct < order.gems ? `Refund ${deduct}/${order.gems} Gems (saldo kurang — sisanya hangus, tercatat audit)` : `Refund ${order.gems} Gems`,
        },
      });
      await tx.order.update({ where: { id: orderId }, data: { status: "refunded" } });
    });
  } catch (e) {
    // ledger unique(reason,refId) — refund ganda otomatis ditolak
    console.error("[refund] error", e);
    return { httpStatus: 409, message: "Refund sudah pernah diproses untuk order ini.", duplicate: true, orderId };
  }
  await audit("refund", actorInfo?.id ?? null, actorInfo?.email ?? null, "order", orderId, { actor, source, gems: order.gems });
  return { httpStatus: 200, message: "Refund diproses.", orderId };
}
