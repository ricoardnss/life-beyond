// Midtrans Snap adapter — mengikuti dokumentasi resmi Midtrans (docs.midtrans.com).
// - Create: POST {APP}/snap/v1/transactions, Basic Auth username=SERVER_KEY password kosong.
// - Webhook: signature_key = SHA512(order_id + status_code + gross_amount + ServerKey).
// - settlement/capture(accept) = paid; deny/cancel/failure = failed; expire = expired.
// WAJIB diaktifkan hanya setelah MIDTRANS_SERVER_KEY & MIDTRANS_CLIENT_KEY tersedia,
// dan ulangi verifikasi field terhadap dokumen resmi sebelum produksi.
import { createHash } from "crypto";
import type { CreatePaymentResult, ParsedWebhook, PaymentProvider } from "./provider";

const APP = () => (process.env.MIDTRANS_IS_PRODUCTION === "true" ? "https://app.midtrans.com" : "https://app.sandbox.midtrans.com");

export class MidtransSnapProvider implements PaymentProvider {
  id = "midtrans";
  mode: "sandbox" | "production" = process.env.MIDTRANS_IS_PRODUCTION === "true" ? "production" : "sandbox";

  private serverKey() {
    const k = process.env.MIDTRANS_SERVER_KEY;
    if (!k) throw new Error("MIDTRANS_SERVER_KEY belum diset");
    return k;
  }

  async createPayment(order: { id: string; amountIdr: number; gems: number; productName: string; userId: string }): Promise<CreatePaymentResult> {
    const res = await fetch(`${APP()}/snap/v1/transactions`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Accept: "application/json",
        Authorization: `Basic ${Buffer.from(`${this.serverKey()}:`).toString("base64")}`,
      },
      body: JSON.stringify({
        transaction_details: {
          order_id: order.id,
          gross_amount: order.amountIdr, // Rupiah, tanpa desimal
        },
        item_details: [
          {
            id: order.id,
            name: order.productName.slice(0, 50),
            price: order.amountIdr,
            quantity: 1,
          },
        ],
        custom_field1: order.userId,
        expiry: { unit: "hour", duration: 1 },
      }),
    });
    if (!res.ok) {
      const text = await res.text();
      throw new Error(`Midtrans Snap gagal (${res.status}): ${text.slice(0, 300)}`);
    }
    const data = (await res.json()) as { token: string; redirect_url: string };
    return {
      provider: this.id,
      providerRef: data.token,
      redirectUrl: data.redirect_url,
      expiresAt: new Date(Date.now() + 1000 * 60 * 60).toISOString(),
      mode: this.mode,
    };
  }

  parseWebhook(headers: Headers, rawBody: string): ParsedWebhook {
    let body: Record<string, unknown>;
    try {
      body = JSON.parse(rawBody);
    } catch {
      return { valid: false, eventId: "", orderId: "", outcome: "failed", amountIdr: 0, currency: "IDR", raw: rawBody };
    }
    const orderId = String(body.order_id ?? "");
    const statusCode = String(body.status_code ?? "");
    const grossAmount = String(body.gross_amount ?? "");
    const signatureKey = String(body.signature_key ?? "");
    const transactionStatus = String(body.transaction_status ?? "");
    const fraudStatus = String(body.fraud_status ?? "accept");
    const transactionTime = String(body.transaction_time ?? new Date().toISOString());
    const eventId = `${orderId}:${transactionStatus}:${transactionTime}`;

    // verifikasi SHA512(order_id + status_code + gross_amount + ServerKey)
    const expected = createHash("sha512").update(`${orderId}${statusCode}${grossAmount}${this.serverKey()}`).digest("hex");
    if (!signatureKey || signatureKey !== expected) {
      return { valid: false, eventId, orderId, outcome: "failed", amountIdr: Number(grossAmount || 0), currency: "IDR", raw: body };
    }

    let outcome: ParsedWebhook["outcome"];
    if (transactionStatus === "settlement" || (transactionStatus === "capture" && fraudStatus.toLowerCase() === "accept")) outcome = "paid";
    else if (transactionStatus === "expire") outcome = "expired";
    else if (transactionStatus === "refund" || transactionStatus === "partial_refund") outcome = "refund";
    else if (["deny", "cancel", "failure"].includes(transactionStatus)) outcome = "failed";
    else outcome = "pending";

    return {
      valid: true,
      eventId,
      orderId,
      outcome,
      amountIdr: Number(grossAmount || 0),
      currency: "IDR",
      providerRef: String(body.transaction_id ?? ""),
      raw: body,
    };
  }
}
