// Helper respons API seragam + guard autentikasi/otorisasi.
import { db } from "@/lib/db";
import { sessionFromRequest } from "@/lib/auth";

export function json(data: unknown, status = 200, headers?: Record<string, string>): Response {
  return new Response(JSON.stringify(data), {
    status,
    headers: { "Content-Type": "application/json", ...(headers ?? {}) },
  });
}

export function err(status: number, message: string, extra?: Record<string, unknown>): Response {
  return json({ error: message, ...(extra ?? {}) }, status);
}

export interface AuthUser {
  id: string;
  email: string;
  role: string;
}

export async function requireUser(req: Request): Promise<{ user: AuthUser } | { error: Response }> {
  const session = sessionFromRequest(req);
  if (!session) return { error: err(401, "Kamu belum masuk. Silakan login dulu.") };
  const user = await db.user.findUnique({ where: { id: session.uid } });
  if (!user) return { error: err(401, "Sesi tidak valid.") };
  return { user: { id: user.id, email: user.email, role: user.role } };
}

export async function requireAdmin(req: Request): Promise<{ user: AuthUser } | { error: Response }> {
  const res = await requireUser(req);
  if ("error" in res) return res;
  // role selalu diverifikasi dari DB, bukan dari payload cookie yang bisa basi
  if (res.user.role !== "admin") return { error: err(403, "Akses khusus admin.") };
  return res;
}

export async function audit(action: string, actorId: string | null, actorEmail: string | null, targetType: string, targetId: string | null, meta?: unknown) {
  await db.auditLog.create({
    data: {
      action,
      actorId,
      actorEmail,
      targetType,
      targetId,
      meta: meta ? JSON.stringify(meta) : null,
    },
  });
}

export function newOrderId(): string {
  const t = Date.now().toString(36).toUpperCase();
  const r = Math.random().toString(36).slice(2, 6).toUpperCase();
  return `KK-ORD-${t}-${r}`;
}
