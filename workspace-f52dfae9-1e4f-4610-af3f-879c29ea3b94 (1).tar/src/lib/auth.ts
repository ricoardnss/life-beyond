// Sesi login berbasis cookie HMAC — ringan, stateless, httpOnly.
import { createHmac, timingSafeEqual } from "crypto";

const SECRET = process.env.SESSION_SECRET || "kotakita-dev-secret-GANTI-DI-PRODUKSI";
export const SESSION_COOKIE = "kk_session";
const SESSION_TTL_MS = 1000 * 60 * 60 * 24 * 14; // 14 hari

interface SessionPayload {
  uid: string;
  email: string;
  role: string;
  exp: number;
}

function b64url(input: string): string {
  return Buffer.from(input).toString("base64url");
}

function sign(data: string): string {
  return createHmac("sha256", SECRET).update(data).digest("base64url");
}

export function createSessionToken(uid: string, email: string, role: string): string {
  const payload: SessionPayload = { uid, email, role, exp: Date.now() + SESSION_TTL_MS };
  const body = b64url(JSON.stringify(payload));
  return `${body}.${sign(body)}`;
}

export function parseSessionToken(token: string | undefined | null): SessionPayload | null {
  if (!token) return null;
  const [body, sig] = token.split(".");
  if (!body || !sig) return null;
  const expected = sign(body);
  try {
    const a = Buffer.from(sig);
    const b = Buffer.from(expected);
    if (a.length !== b.length || !timingSafeEqual(a, b)) return null;
    const payload = JSON.parse(Buffer.from(body, "base64url").toString()) as SessionPayload;
    if (!payload.uid || payload.exp < Date.now()) return null;
    return payload;
  } catch {
    return null;
  }
}

export function sessionFromRequest(req: Request): SessionPayload | null {
  // 1) Cookie (jalur utama — httpOnly).
  const cookie = req.headers.get("cookie") ?? "";
  const m = cookie.match(new RegExp(`${SESSION_COOKIE}=([^;]+)`));
  if (m) {
    const p = parseSessionToken(decodeURIComponent(m[1]));
    if (p) return p;
  }
  // 2) Fallback header — untuk preview di dalam iframe lintas-situs, tempat browser
  //    memblokir pengiriman cookie pihak ketiga (SameSite=Lax tidak terkirim).
  const hdr = req.headers.get("x-session-token");
  if (hdr) return parseSessionToken(decodeURIComponent(hdr.trim()));
  return null;
}

function isHttps(req: Request): boolean {
  const proto = req.headers.get("x-forwarded-proto") ?? "";
  if (proto) return proto.split(",")[0].trim() === "https";
  try {
    return new URL(req.url).protocol === "https:";
  } catch {
    return false;
  }
}

/** Cookie sesi: di HTTPS (termasuk di balik proxy/preview) pakai SameSite=None; Secure; Partitioned
 *  agar tetap terkirim di konteks iframe; di HTTP lokal tetap Lax. */
export function sessionCookie(req: Request, token: string): string {
  const base = `${SESSION_COOKIE}=${encodeURIComponent(token)}; Path=/; HttpOnly; Max-Age=${Math.floor(SESSION_TTL_MS / 1000)}`;
  if (isHttps(req)) {
    return `${base}; SameSite=None; Secure; Partitioned`;
  }
  return `${base}; SameSite=Lax`;
}

export function clearSessionCookie(req?: Request): string {
  const base = `${SESSION_COOKIE}=; Path=/; HttpOnly; Max-Age=0`;
  if (req && isHttps(req)) return `${base}; SameSite=None; Secure; Partitioned`;
  return `${base}; SameSite=Lax`;
}
