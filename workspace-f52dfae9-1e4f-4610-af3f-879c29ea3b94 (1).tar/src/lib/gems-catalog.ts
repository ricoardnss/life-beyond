// Katalog SKU kosmetik premium (Arunika Gems).
// Satu-satunya sumber harga Gems untuk pembelanjaan — frontend TIDAK boleh mengirim harga.
// Semua item bersifat kosmetik / kenyamanan, tidak merusak keseimbangan game (Bagian E).
export interface GemSku {
  sku: string;
  name: string;
  priceGems: number;
  kind: "skin" | "outfit" | "decor" | "comfort" | "bundle";
  description: string;
}

export const GEM_SKUS: GemSku[] = [
  {
    sku: "skin.golden",
    name: "Skin Emas Arunika",
    priceGems: 150,
    kind: "skin",
    description: "Pakaian emas eksklusif dengan efek kilau halus. Gaya pemilik kota.",
  },
  {
    sku: "outfit.cyber",
    name: "Jaket Neon Cyber",
    priceGems: 120,
    kind: "outfit",
    description: "Jaket neon dengan garis cyan, cocok untuk malam-malam Kota Arunika.",
  },
  {
    sku: "outfit.sunset",
    name: "Kostum Sunset Warmth",
    priceGems: 100,
    kind: "outfit",
    description: "Kostum bernuansa jingga senja yang hangat dan tenang.",
  },
  {
    sku: "decor.neon.sign",
    name: "Papan Neon Kafe",
    priceGems: 200,
    kind: "decor",
    description: "Dekorasi papan neon untuk kamar kosmu. Bikin kamar terasa seperti kafe.",
  },
  {
    sku: "comfort.fan.mini",
    name: "Kipas Mini Premium",
    priceGems: 60,
    kind: "comfort",
    description: "Kenyamanan: kipas hening untuk kamar. Tidur sedikit lebih segar (+energi tidur).",
  },
  {
    sku: "bundle.city.pack",
    name: "Paket Kota Lengkap",
    priceGems: 350,
    kind: "bundle",
    description: "Skin Emas + Jaket Neon + Papan Neon. Hemat 120 Gems.",
  },
];

export function findSku(sku: string): GemSku | undefined {
  return GEM_SKUS.find((s) => s.sku === sku);
}
