// Rate limiting in-memory per IP+route (produksi: pakai store durable/Supabase Edge).
// Satu instance dibagi lintas route bundle (Turbopack menduplikasi modul per route).
const g = globalThis as unknown as { __kkRateBuckets?: Map<string, { count: number; reset: number }> };
const buckets: Map<string, { count: number; reset: number }> = g.__kkRateBuckets ?? (g.__kkRateBuckets = new Map());

export function rateLimit(req: Request, bucket: string, max: number, windowMs: number): { ok: boolean; retryAfter?: number } {
  const ip =
    req.headers.get("x-forwarded-for")?.split(",")[0]?.trim() ||
    req.headers.get("x-real-ip") ||
    "local";
  const key = `${bucket}:${ip}`;
  const now = Date.now();
  const b = buckets.get(key);
  if (!b || b.reset < now) {
    buckets.set(key, { count: 1, reset: now + windowMs });
    return { ok: true };
  }
  b.count += 1;
  if (b.count > max) {
    return { ok: false, retryAfter: Math.ceil((b.reset - now) / 1000) };
  }
  return { ok: true };
}

/** Khusus pengujian/development: kosongkan semua bucket. */
export function resetRateLimits() {
  buckets.clear();
}

// bersihkan bucket kadaluarsa secara periodik
setInterval(() => {
  const now = Date.now();
  for (const [k, v] of buckets) if (v.reset < now) buckets.delete(k);
}, 60_000).unref?.();
