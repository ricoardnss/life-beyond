// Sesi klien: fallback token di localStorage untuk lingkungan iframe lintas-situs
// (cookie SameSite=Lax diblokir browser pada iframe pihak ketiga).
// Cookie tetap menjadi jalur utama; header X-Session-Token dipakai sebagai cadangan.
const TOKEN_KEY = "kk_session_token";

export function saveSessionToken(token: string) {
  try {
    localStorage.setItem(TOKEN_KEY, token);
  } catch {
    /* penyimpanan penuh / diblokir: cookie masih jalan */
  }
}

export function getSessionToken(): string | null {
  try {
    return localStorage.getItem(TOKEN_KEY);
  } catch {
    return null;
  }
}

export function clearSessionToken() {
  try {
    localStorage.removeItem(TOKEN_KEY);
  } catch {
    /* abaikan */
  }
}

/** Header autentikasi tambahan untuk semua fetch API (aman dipanggil di client). */
export function authHeaders(): Record<string, string> {
  const t = getSessionToken();
  return t ? { "X-Session-Token": t } : {};
}
