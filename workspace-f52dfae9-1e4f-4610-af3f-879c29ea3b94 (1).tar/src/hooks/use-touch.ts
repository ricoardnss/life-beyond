"use client";

import { useMemo, useSyncExternalStore } from "react";

/** Berlangganan perubahan media query. Stabil per query string. */
function makeSubscribe(query: string) {
  return (cb: () => void) => {
    const mq = window.matchMedia(query);
    mq.addEventListener?.("change", cb);
    return () => mq.removeEventListener?.("change", cb);
  };
}

/**
 * Media query reaktif yang aman SSR (server selalu false,
 * client ikut berubah saat orientasi/perangkat berubah).
 */
export function useMediaQuery(query: string): boolean {
  const subscribe = useMemo(() => makeSubscribe(query), [query]);
  return useSyncExternalStore(
    subscribe,
    () => window.matchMedia(query).matches,
    () => false,
  );
}

/**
 * Perangkat sentuh (pointer: coarse).
 * Override untuk pengujian/debug: ?touch=1 (paksa aktif) / ?touch=0 (paksa nonaktif)
 * di URL sebelum hash, mis. "/?touch=1#/play".
 */
export function useIsTouch(): boolean {
  const coarse = useMediaQuery("(pointer: coarse)");
  if (typeof window !== "undefined") {
    const qp = new URLSearchParams(window.location.search).get("touch");
    if (qp === "1") return true;
    if (qp === "0") return false;
  }
  return coarse;
}
