// POST /api/gems/spend — belanja kosmetik premium dengan Gems.
// Harga dari katalog server; nonce client mencegah double-spend klik ganda.
import { db } from "@/lib/db";
import { err, json, requireUser, audit } from "@/lib/api-helpers";
import { findSku } from "@/lib/gems-catalog";
import { rateLimit } from "@/lib/rate-limit";

export async function POST(req: Request) {
  const rl = rateLimit(req, "gems_spend", 30, 60_000);
  if (!rl.ok) return err(429, "Terlalu banyak permintaan.");

  const auth = await requireUser(req);
  if ("error" in auth) return auth.error;

  let body: { sku?: string; nonce?: string };
  try {
    body = await req.json();
  } catch {
    return err(400, "Body tidak valid.");
  }
  const sku = findSku(String(body.sku ?? ""));
  const nonce = String(body.nonce ?? "").slice(0, 40);
  if (!sku) return err(404, "SKU tidak ditemukan.");
  if (!/^[a-zA-Z0-9_-]{6,40}$/.test(nonce)) return err(400, "Nonce tidak valid.");

  const refId = `${sku.sku}:${nonce}`;
  const existing = await db.premiumLedger.findUnique({
    where: { reason_refId: { reason: "spend", refId } },
  });
  if (existing) return err(409, "Permintaan ini sudah pernah diproses (idempoten).");

  const owned = await db.entitlement.findUnique({
    where: { userId_sku: { userId: auth.user.id, sku: sku.sku } },
  });
  if (owned) return err(409, "Item ini sudah kamu miliki.");

  if (sku.sku === "bundle.city.pack") {
    return err(400, "Paket bundel dibelanja per komponen di katalog.");
  }

  try {
    const result = await db.$transaction(async (tx) => {
      const wallet = await tx.premiumWallet.findUnique({ where: { userId: auth.user.id } });
      const balance = wallet?.balance ?? 0;
      if (balance < sku.priceGems) {
        throw Object.assign(new Error("Saldo Gems tidak cukup."), { code: "INSUFFICIENT" });
      }
      const newBalance = balance - sku.priceGems;
      await tx.premiumWallet.update({ where: { userId: auth.user.id }, data: { balance: newBalance } });
      await tx.premiumLedger.create({
        data: { userId: auth.user.id, delta: -sku.priceGems, balanceAfter: newBalance, reason: "spend", refType: "game_sku", refId, note: sku.name },
      });
      // bundle: beri semua komponen
      const skus = sku.sku === "bundle.city.pack" ? ["skin.golden", "outfit.cyber", "decor.neon.sign"] : [sku.sku];
      for (const s of skus) {
        await tx.entitlement.upsert({ where: { userId_sku: { userId: auth.user.id, sku: s } }, update: {}, create: { userId: auth.user.id, sku: s } });
      }
      return { balance: newBalance };
    });
    await audit("gems_spend", auth.user.id, auth.user.email, "sku", sku.sku, { price: sku.priceGems });
    return json({ ok: true, sku: sku.sku, balance: result.balance, price: sku.priceGems });
  } catch (e) {
    if ((e as { code?: string }).code === "INSUFFICIENT") {
      return err(400, "Saldo Gems tidak cukup. Top up dulu di KOTA KITA STORE.");
    }
    console.error("[gems/spend] error", e);
    return err(500, "Gagal memproses pembelanjaan.");
  }
}
