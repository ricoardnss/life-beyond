// GET /api/gems/catalog — katalog SKU premium + entitlements user (jika login).
import { GEM_SKUS } from "@/lib/gems-catalog";
import { db } from "@/lib/db";
import { sessionFromRequest } from "@/lib/auth";
import { json } from "@/lib/api-helpers";

export async function GET(req: Request) {
  const session = sessionFromRequest(req);
  let owned: string[] = [];
  let gems: number | null = null;
  if (session) {
    const user = await db.user.findUnique({ where: { id: session.uid }, include: { entitlements: true, wallet: true } });
    if (user) {
      owned = user.entitlements.map((e) => e.sku);
      gems = user.wallet?.balance ?? 0;
    }
  }
  return json({ skus: GEM_SKUS, owned, gems });
}
