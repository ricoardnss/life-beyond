// GET /api/gems/entitlements — daftar kosmetik premium milik user.
import { json, requireUser } from "@/lib/api-helpers";
import { db } from "@/lib/db";

export async function GET(req: Request) {
  const auth = await requireUser(req);
  if ("error" in auth) return auth.error;
  const rows = await db.entitlement.findMany({ where: { userId: auth.user.id } });
  return json({ entitlements: rows.map((r) => r.sku) });
}
