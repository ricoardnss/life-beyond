// GET /api/auth/me — profil + saldo Gems + entitlements
import { db } from "@/lib/db";
import { sessionFromRequest } from "@/lib/auth";
import { err, json } from "@/lib/api-helpers";

export async function GET(req: Request) {
  const session = sessionFromRequest(req);
  if (!session) return err(401, "Belum masuk.");
  const user = await db.user.findUnique({
    where: { id: session.uid },
    include: { wallet: true, entitlements: true },
  });
  if (!user) return err(401, "Sesi tidak valid.");
  return json({
    user: { id: user.id, email: user.email, displayName: user.displayName, role: user.role },
    gems: user.wallet?.balance ?? 0,
    entitlements: user.entitlements.map((e) => e.sku),
  });
}
