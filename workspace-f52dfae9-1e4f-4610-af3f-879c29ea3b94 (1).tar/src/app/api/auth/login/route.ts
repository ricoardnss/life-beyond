// POST /api/auth/login
import { db } from "@/lib/db";
import { verifyPassword } from "@/lib/password";
import { createSessionToken, sessionCookie } from "@/lib/auth";
import { err, json, audit } from "@/lib/api-helpers";
import { rateLimit } from "@/lib/rate-limit";

export async function POST(req: Request) {
  const rl = rateLimit(req, "login", 30, 60_000);
  if (!rl.ok) return err(429, "Terlalu banyak percobaan login. Tunggu sebentar.");

  let body: { email?: string; password?: string };
  try {
    body = await req.json();
  } catch {
    return err(400, "Body tidak valid.");
  }
  const email = String(body.email ?? "").trim().toLowerCase();
  const password = String(body.password ?? "");

  const user = await db.user.findUnique({ where: { email } });
  if (!user || !verifyPassword(password, user.passwordHash)) {
    return err(401, "Email atau password salah.");
  }
  await audit("login", user.id, user.email, "user", user.id);
  const token = createSessionToken(user.id, user.email, user.role);
  // Token ikut dikirim di body sebagai cadangan utk iframe lintas-situs (cookie diblokir).
  return json({ ok: true, sessionToken: token, user: { id: user.id, email: user.email, displayName: user.displayName, role: user.role } }, 200, { "Set-Cookie": sessionCookie(req, token) });
}
