// POST /api/auth/register — buat akun baru.
import { db } from "@/lib/db";
import { hashPassword } from "@/lib/password";
import { createSessionToken, sessionCookie } from "@/lib/auth";
import { err, json, audit } from "@/lib/api-helpers";
import { rateLimit } from "@/lib/rate-limit";

export async function POST(req: Request) {
  const rl = rateLimit(req, "register", 30, 60_000);
  if (!rl.ok) return err(429, "Terlalu banyak percobaan. Coba lagi nanti.");

  let body: { email?: string; password?: string; displayName?: string };
  try {
    body = await req.json();
  } catch {
    return err(400, "Body tidak valid.");
  }
  const email = String(body.email ?? "").trim().toLowerCase();
  const password = String(body.password ?? "");
  const displayName = String(body.displayName ?? "").trim();

  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return err(400, "Format email tidak valid.");
  if (password.length < 8) return err(400, "Password minimal 8 karakter.");
  if (displayName.length < 2 || displayName.length > 24) return err(400, "Nama tampilan 2-24 karakter.");

  const exists = await db.user.findUnique({ where: { email } });
  if (exists) return err(409, "Email sudah terdaftar. Coba masuk saja.");

  const user = await db.user.create({
    data: { email, passwordHash: hashPassword(password), displayName, role: "user" },
  });
  await db.premiumWallet.create({ data: { userId: user.id, balance: 0 } });
  await audit("register", user.id, user.email, "user", user.id);

  const token = createSessionToken(user.id, user.email, user.role);
  // Token ikut dikirim di body sebagai cadangan utk iframe lintas-situs (cookie diblokir).
  return json({ ok: true, sessionToken: token, user: { id: user.id, email: user.email, displayName: user.displayName, role: user.role } }, 201, { "Set-Cookie": sessionCookie(req, token) });
}
