// POST /api/auth/logout
import { clearSessionCookie, sessionFromRequest } from "@/lib/auth";
import { json } from "@/lib/api-helpers";

export async function POST(req: Request) {
  const session = sessionFromRequest(req);
  void session;
  return json({ ok: true }, 200, { "Set-Cookie": clearSessionCookie(req) });
}
