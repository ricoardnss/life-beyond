// GET /api/health — status layanan.
import { db } from "@/lib/db";
import { json } from "@/lib/api-helpers";

export async function GET() {
  let dbOk = false;
  try {
    await db.product.count();
    dbOk = true;
  } catch {
    dbOk = false;
  }
  return json({
    ok: true,
    service: "KOTA KITA: Life Beyond",
    db: dbOk ? "tersambung" : "tidak tersambung",
    paymentProvider: process.env.PAYMENT_PROVIDER || "mockpay",
    time: new Date().toISOString(),
  });
}
