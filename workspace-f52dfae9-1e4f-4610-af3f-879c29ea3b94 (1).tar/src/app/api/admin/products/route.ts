// POST /api/admin/products — tambah paket top-up (admin).
import { db } from "@/lib/db";
import { audit, err, json, requireAdmin } from "@/lib/api-helpers";

export async function POST(req: Request) {
  const auth = await requireAdmin(req);
  if ("error" in auth) return auth.error;

  let body: { id?: string; name?: string; gems?: number; priceIdr?: number; description?: string; promoLabel?: string | null; sortOrder?: number; active?: boolean; imageUrl?: string | null };
  try {
    body = await req.json();
  } catch {
    return err(400, "Body tidak valid.");
  }
  const id = String(body.id ?? "").trim().toLowerCase().replace(/[^a-z0-9-]/g, "-");
  const name = String(body.name ?? "").trim();
  const gems = Number(body.gems);
  const priceIdr = Number(body.priceIdr);
  const description = String(body.description ?? "").trim();

  if (!/^[a-z0-9-]{3,40}$/.test(id)) return err(400, "ID produk 3-40 karakter (a-z, 0-9, -).");
  if (name.length < 2) return err(400, "Nama produk minimal 2 karakter.");
  if (!Number.isInteger(gems) || gems < 1 || gems > 1_000_000) return err(400, "Jumlah Gems tidak valid.");
  if (!Number.isInteger(priceIdr) || priceIdr < 0 || priceIdr > 100_000_000) return err(400, "Harga Rupiah tidak valid.");
  if (description.length < 3) return err(400, "Deskripsi minimal 3 karakter.");

  const exists = await db.product.findUnique({ where: { id } });
  if (exists) return err(409, "ID produk sudah dipakai.");

  const product = await db.product.create({
    data: {
      id, name, gems, priceIdr, description,
      promoLabel: body.promoLabel ? String(body.promoLabel).slice(0, 20) : null,
      imageUrl: body.imageUrl ? String(body.imageUrl).slice(0, 300) : null,
      sortOrder: Number.isInteger(body.sortOrder) ? Number(body.sortOrder) : 99,
      active: body.active ?? true,
    },
  });
  await audit("product_create", auth.user.id, auth.user.email, "product", id, { gems, priceIdr });
  return json({ product }, 201);
}
