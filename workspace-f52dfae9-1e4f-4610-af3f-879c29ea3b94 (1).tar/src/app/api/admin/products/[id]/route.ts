// PATCH /api/admin/products/[id] — edit/aktif-nonaktifkan produk. DELETE — hapus.
import { db } from "@/lib/db";
import { audit, err, json, requireAdmin } from "@/lib/api-helpers";

export async function PATCH(req: Request, { params }: { params: Promise<{ id: string }> }) {
  const auth = await requireAdmin(req);
  if ("error" in auth) return auth.error;
  const { id } = await params;

  const product = await db.product.findUnique({ where: { id } });
  if (!product) return err(404, "Produk tidak ditemukan.");

  let body: { name?: string; gems?: number; priceIdr?: number; description?: string; promoLabel?: string | null; sortOrder?: number; active?: boolean };
  try {
    body = await req.json();
  } catch {
    return err(400, "Body tidak valid.");
  }

  const data: Record<string, unknown> = {};
  if (body.name !== undefined) {
    if (String(body.name).trim().length < 2) return err(400, "Nama minimal 2 karakter.");
    data.name = String(body.name).trim();
  }
  if (body.gems !== undefined) {
    if (!Number.isInteger(Number(body.gems)) || Number(body.gems) < 1) return err(400, "Gems tidak valid.");
    data.gems = Number(body.gems);
  }
  if (body.priceIdr !== undefined) {
    if (!Number.isInteger(Number(body.priceIdr)) || Number(body.priceIdr) < 0) return err(400, "Harga tidak valid.");
    data.priceIdr = Number(body.priceIdr);
  }
  if (body.description !== undefined) data.description = String(body.description);
  if (body.promoLabel !== undefined) data.promoLabel = body.promoLabel ? String(body.promoLabel).slice(0, 20) : null;
  if (body.sortOrder !== undefined) data.sortOrder = Number(body.sortOrder);
  if (body.active !== undefined) data.active = Boolean(body.active);

  const updated = await db.product.update({ where: { id }, data });
  await audit("product_update", auth.user.id, auth.user.email, "product", id, data);
  return json({ product: updated });
}

export async function DELETE(req: Request, { params }: { params: Promise<{ id: string }> }) {
  const auth = await requireAdmin(req);
  if ("error" in auth) return auth.error;
  const { id } = await params;

  const used = await db.order.count({ where: { productId: id } });
  if (used > 0) {
    // jangan hapus produk yang punya riwayat order — nonaktifkan saja
    await db.product.update({ where: { id }, data: { active: false } });
    await audit("product_deactivate", auth.user.id, auth.user.email, "product", id, { reason: "punya riwayat order" });
    return json({ ok: true, deactivated: true, message: "Produk punya riwayat order — dinonaktifkan, bukan dihapus." });
  }
  await db.product.delete({ where: { id } });
  await audit("product_delete", auth.user.id, auth.user.email, "product", id, null);
  return json({ ok: true, deleted: true });
}
