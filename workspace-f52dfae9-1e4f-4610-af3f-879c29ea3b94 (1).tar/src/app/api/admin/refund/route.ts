// POST /api/admin/refund — proses refund order melalui alur aman.
// Validasi status, potong Gems (tanpa saldo negatif), ledger + audit tercatat.
import { db } from "@/lib/db";
import { err, json, requireAdmin } from "@/lib/api-helpers";
import { refundOrderInternal } from "@/lib/payment/process";
import { rateLimit } from "@/lib/rate-limit";

export async function POST(req: Request) {
  const rl = rateLimit(req, "admin_refund", 20, 60_000);
  if (!rl.ok) return err(429, "Terlalu banyak permintaan.");

  const auth = await requireAdmin(req);
  if ("error" in auth) return auth.error;

  let body: { orderId?: string };
  try {
    body = await req.json();
  } catch {
    return err(400, "Body tidak valid.");
  }
  const orderId = String(body.orderId ?? "");
  const order = await db.order.findUnique({ where: { id: orderId } });
  if (!order) return err(404, "Order tidak ditemukan.");
  if (!["paid", "fulfilled"].includes(order.status)) {
    return err(400, `Refund hanya untuk order paid/fulfilled (order ini: ${order.status}).`);
  }

  const result = await refundOrderInternal(orderId, auth.user.email, "admin", { id: auth.user.id, email: auth.user.email });
  return json({ ok: result.httpStatus === 200, message: result.message, orderId }, result.httpStatus);
}
