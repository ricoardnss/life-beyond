// GET /api/admin/orders — daftar semua order (admin). ?userId= filter.
import { db } from "@/lib/db";
import { json, requireAdmin } from "@/lib/api-helpers";

export async function GET(req: Request) {
  const auth = await requireAdmin(req);
  if ("error" in auth) return auth.error;
  const url = new URL(req.url);
  const userId = url.searchParams.get("userId") || undefined;
  const orders = await db.order.findMany({
    where: userId ? { userId } : undefined,
    orderBy: { createdAt: "desc" },
    take: 100,
    include: { product: { select: { name: true } } },
  });
  return json({
    orders: orders.map((o) => ({
      id: o.id,
      userId: o.userId,
      productName: o.product.name,
      gems: o.gems,
      amountIdr: o.amountIdr,
      status: o.status,
      provider: o.provider,
      createdAt: o.createdAt,
      paidAt: o.paidAt,
      fulfilledAt: o.fulfilledAt,
    })),
  });
}
