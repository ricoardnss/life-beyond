// GET /api/admin/stats — ringkasan untuk admin panel.
import { db } from "@/lib/db";
import { json, requireAdmin } from "@/lib/api-helpers";

export async function GET(req: Request) {
  const auth = await requireAdmin(req);
  if ("error" in auth) return auth.error;

  const [users, ordersTotal, ordersPending, ordersPaid, ordersFulfilled, ordersRefunded, revenueAgg, gemsAgg, products, ledgerCount] = await Promise.all([
    db.user.count(),
    db.order.count(),
    db.order.count({ where: { status: "pending" } }),
    db.order.count({ where: { status: "paid" } }),
    db.order.count({ where: { status: "fulfilled" } }),
    db.order.count({ where: { status: "refunded" } }),
    db.order.aggregate({ where: { status: "fulfilled" }, _sum: { amountIdr: true } }),
    db.premiumLedger.aggregate({ where: { reason: "topup" }, _sum: { delta: true } }),
    db.product.count(),
    db.premiumLedger.count(),
  ]);

  return json({
    users,
    products,
    orders: { total: ordersTotal, pending: ordersPending, paid: ordersPaid, fulfilled: ordersFulfilled, refunded: ordersRefunded },
    revenueIdr: revenueAgg._sum.amountIdr ?? 0,
    gemsSold: gemsAgg._sum.delta ?? 0,
    ledgerEntries: ledgerCount,
  });
}
