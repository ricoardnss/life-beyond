// GET /api/admin/ledger — riwayat saldo Gems (audit keuangan).
import { db } from "@/lib/db";
import { json, requireAdmin } from "@/lib/api-helpers";

export async function GET(req: Request) {
  const auth = await requireAdmin(req);
  if ("error" in auth) return auth.error;
  const url = new URL(req.url);
  const userId = url.searchParams.get("userId") || undefined;
  const rows = await db.premiumLedger.findMany({
    where: userId ? { userId } : undefined,
    orderBy: { createdAt: "desc" },
    take: 100,
  });
  return json({ ledger: rows });
}
