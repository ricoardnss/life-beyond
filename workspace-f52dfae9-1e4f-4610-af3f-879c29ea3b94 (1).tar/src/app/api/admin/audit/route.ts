// GET /api/admin/audit — log audit perubahan penting.
import { db } from "@/lib/db";
import { json, requireAdmin } from "@/lib/api-helpers";

export async function GET(req: Request) {
  const auth = await requireAdmin(req);
  if ("error" in auth) return auth.error;
  const rows = await db.auditLog.findMany({ orderBy: { createdAt: "desc" }, take: 100 });
  return json({ audit: rows });
}
