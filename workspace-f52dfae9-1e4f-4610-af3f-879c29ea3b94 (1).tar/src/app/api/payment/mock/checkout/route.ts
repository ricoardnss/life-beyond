// POST /api/payment/mock/checkout — SIMULASI GATEWAY. STATUS: DEVELOPMENT ONLY.
// Endpoint ini berperan SEBAGAI gateway palsu yang mengirim webhook tersignature ke
// jalur pemrosesan yang sama dengan produksi (signature, idempotensi, kredit atomik).
// Dinonaktifkan otomatis jika PAYMENT_PROVIDER != mockpay.
import { MockPayProvider } from "@/lib/payment/mock";
import { processWebhook } from "@/lib/payment/process";
import { activeProviderId } from "@/lib/payment/provider";
import { db } from "@/lib/db";
import { err, json, requireUser } from "@/lib/api-helpers";
import { rateLimit } from "@/lib/rate-limit";

export async function POST(req: Request) {
  if (activeProviderId() !== "mockpay") {
    return err(403, "Mock checkout dinonaktifkan: provider pembayaran produksi aktif.");
  }
  const rl = rateLimit(req, "mock_checkout", 60, 60_000);
  if (!rl.ok) return err(429, "Terlalu banyak percobaan.");

  const auth = await requireUser(req);
  if ("error" in auth) return auth.error;

  let body: { orderId?: string; result?: string };
  try {
    body = await req.json();
  } catch {
    return err(400, "Body tidak valid.");
  }
  const orderId = String(body.orderId ?? "");
  const result = String(body.result ?? "");

  // order harus milik user ini
  const order = await db.order.findUnique({ where: { id: orderId } });
  if (!order) return err(404, "Order tidak ditemukan.");
  if (order.userId !== auth.user.id) return err(403, "Order ini bukan milikmu.");
  if (order.provider !== "mockpay") return err(400, "Order ini tidak memakai MockPay.");
  if (order.status !== "pending") return err(409, `Order sudah berstatus ${order.status}.`);

  const outcomeMap: Record<string, string> = { sukses: "paid", gagal: "failed", kedaluwarsa: "expired" };
  const outcome = outcomeMap[result];
  if (!outcome) return err(400, "Hasil simulasi tidak dikenal.");

  const eventId = `mockevt_${orderId}_${outcome}_${Date.now()}`;
  const rawBody = MockPayProvider.buildSignedWebhook(eventId, orderId, outcome, order.amountIdr, order.currency);

  // jalur identik dengan webhook gateway sungguhan
  const mockHeaders = new Headers({ "content-type": "application/json" });
  const processed = await processWebhook(new MockPayProvider(), mockHeaders, rawBody);
  return json({ ok: processed.httpStatus < 400, message: processed.message, orderId }, processed.httpStatus);
}
