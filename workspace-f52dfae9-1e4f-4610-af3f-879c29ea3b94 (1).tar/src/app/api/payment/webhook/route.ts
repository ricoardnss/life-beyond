// POST /api/payment/webhook — endpoint callback gateway (Midtrans/MockPay).
// Verifikasi signature di backend, idempoten, kredit atomik.
import { getProvider, activeProviderId } from "@/lib/payment/provider";
import { processWebhook } from "@/lib/payment/process";
import { err, json } from "@/lib/api-helpers";
import { rateLimit } from "@/lib/rate-limit";

export async function POST(req: Request) {
  const rl = rateLimit(req, "webhook", 120, 60_000);
  if (!rl.ok) return err(429, "Terlalu banyak callback.");

  const raw = await req.text();
  const provider = await getProvider(activeProviderId());
  const result = await processWebhook(provider, req.headers, raw);
  // Gateway mengharapkan 2xx agar tidak retry; 403/404/400 tetap informatif
  return json({ ok: result.httpStatus < 400, message: result.message, orderId: result.orderId }, result.httpStatus);
}
