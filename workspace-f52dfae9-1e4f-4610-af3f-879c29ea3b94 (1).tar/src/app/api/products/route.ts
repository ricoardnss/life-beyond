// GET /api/products — katalog publik (produk aktif). ?all=1 khusus admin.
import { db } from "@/lib/db";
import { err, json } from "@/lib/api-helpers";
import { sessionFromRequest } from "@/lib/auth";

export async function GET(req: Request) {
  const url = new URL(req.url);
  const all = url.searchParams.get("all") === "1";
  if (all) {
    const session = sessionFromRequest(req);
    if (!session) return err(401, "Belum masuk.");
    const u = await db.user.findUnique({ where: { id: session.uid } });
    if (u?.role !== "admin") return err(403, "Akses khusus admin.");
    const products = await db.product.findMany({ orderBy: { sortOrder: "asc" } });
    return json({ products });
  }
  const products = await db.product.findMany({ where: { active: true }, orderBy: { sortOrder: "asc" } });
  return json({ products });
}
