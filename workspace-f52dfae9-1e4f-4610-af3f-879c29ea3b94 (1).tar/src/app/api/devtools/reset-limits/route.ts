// POST /api/__dev/reset-limits — HANYA development: reset bucket rate limit untuk pengujian.
import { resetRateLimits } from "@/lib/rate-limit";
import { err, json } from "@/lib/api-helpers";

export async function POST() {
  if (process.env.NODE_ENV !== "development") {
    return err(404, "Tidak ditemukan.");
  }
  resetRateLimits();
  return json({ ok: true });
}
