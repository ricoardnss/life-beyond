// GET/DELETE /api/saves/[slot] — akses save milik sendiri saja.
import { db } from "@/lib/db";
import { err, json, requireUser } from "@/lib/api-helpers";

export async function GET(req: Request, { params }: { params: Promise<{ slot: string }> }) {
  const auth = await requireUser(req);
  if ("error" in auth) return auth.error;
  const { slot } = await params;
  const slotNum = Number(slot);
  if (!Number.isInteger(slotNum) || slotNum < 1 || slotNum > 3) return err(400, "Slot harus 1-3.");
  const save = await db.gameSave.findUnique({
    where: { userId_slot: { userId: auth.user.id, slot: slotNum } },
  });
  if (!save) return err(404, "Slot kosong.");
  return json({ slot: save.slot, data: save.data, savedAt: save.playedAt });
}

export async function DELETE(req: Request, { params }: { params: Promise<{ slot: string }> }) {
  const auth = await requireUser(req);
  if ("error" in auth) return auth.error;
  const { slot } = await params;
  const slotNum = Number(slot);
  if (!Number.isInteger(slotNum) || slotNum < 1 || slotNum > 3) return err(400, "Slot harus 1-3.");
  await db.gameSave.deleteMany({ where: { userId: auth.user.id, slot: slotNum } });
  return json({ ok: true });
}
