// GET /api/saves — daftar save milik user (ringkas).
// POST /api/saves — upsert save {slot, data}.
import { db } from "@/lib/db";
import { err, json, requireUser } from "@/lib/api-helpers";
import { rateLimit } from "@/lib/rate-limit";

export async function GET(req: Request) {
  const auth = await requireUser(req);
  if ("error" in auth) return auth.error;
  const url = new URL(req.url);
  const slot = url.searchParams.get("slot");
  if (slot) {
    const slotNum = Number(slot);
    if (!Number.isInteger(slotNum) || slotNum < 1 || slotNum > 3) return err(400, "Slot harus 1-3.");
    const save = await db.gameSave.findUnique({
      where: { userId_slot: { userId: auth.user.id, slot: Number(slot) } },
    });
    // PEMBATASAN AKSES: hanya milik sendiri (dijamin lewat query by userId)
    if (!save) return err(404, "Slot kosong.");
    return json({ slot: save.slot, data: save.data, savedAt: save.playedAt });
  }
  const saves = await db.gameSave.findMany({
    where: { userId: auth.user.id },
    orderBy: { slot: "asc" },
    select: { slot: true, data: true, playedAt: true },
  });
  return json(saves);
}

export async function POST(req: Request) {
  const rl = rateLimit(req, "save_post", 60, 60_000);
  if (!rl.ok) return err(429, "Terlalu sering menyimpan.");
  const auth = await requireUser(req);
  if ("error" in auth) return auth.error;

  let body: { slot?: number; data?: string };
  try {
    body = await req.json();
  } catch {
    return err(400, "Body tidak valid.");
  }
  const slot = Number(body.slot);
  const data = String(body.data ?? "");
  if (!Number.isInteger(slot) || slot < 1 || slot > 3) return err(400, "Slot harus 1-3.");
  if (data.length > 400_000) return err(413, "Data save terlalu besar.");

  const saved = await db.gameSave.upsert({
    where: { userId_slot: { userId: auth.user.id, slot } },
    update: { data, playedAt: new Date() },
    create: { userId: auth.user.id, slot, data, playedAt: new Date() },
  });
  return json({ ok: true, slot: saved.slot, savedAt: saved.playedAt });
}
