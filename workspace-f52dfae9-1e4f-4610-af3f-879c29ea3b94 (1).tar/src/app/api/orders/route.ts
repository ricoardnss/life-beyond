// POST /api/orders — buat order top-up (harga SELALU dari DB, bukan dari client).
// GET /api/orders — riwayat order milik sendiri.
import { db } from "@/lib/db";
import { err, json, newOrderId, requireUser } from "@/lib/api-helpers";
import { rateLimit } from "@/lib/rate-limit";
import { getProvider } from "@/lib/payment/provider";

export async function POST(req: Request) {
  const rl = rateLimit(req, "order_create", 60, 60_000);
  if (!rl.ok) return err(429, "Terlalu banyak permintaan order. Tunggu sebentar.");

  const auth = await requireUser(req);
  if ("error" in auth) return auth.error;

  let body: { productId?: string };
  try {
    body = await req.json();
  } catch {
    return err(400, "Body tidak valid.");
  }
  const productId = String(body.productId ?? "");
  const product = await db.product.findUnique({ where: { id: productId } });
  if (!product || !product.active) return err(404, "Produk tidak tersedia.");

  const provider = await getProvider();
  const order = await db.order.create({
    data: {
      id: newOrderId(),
      userId: auth.user.id,
      productId: product.id,
      gems: product.gems, // server-side dari DB
      amountIdr: product.priceIdr, // server-side dari DB
      status: "pending",
      provider: provider.id,
      providerRef: null,
      expiresAt: new Date(Date.now() + 1000 * 60 * 60),
    },
  });

  try {
    const pay = await provider.createPayment({
      id: order.id,
      amountIdr: order.amountIdr,
      gems: order.gems,
      userId: auth.user.id,
      productName: product.name,
    });
    await db.order.update({ where: { id: order.id }, data: { providerRef: pay.providerRef } });
    return json(
      {
        orderId: order.id,
        gems: order.gems,
        amountIdr: order.amountIdr,
        status: order.status,
        provider: pay.provider,
        mode: pay.mode,
        redirectUrl: pay.redirectUrl,
      },
      201
    );
  } catch (e) {
    await db.order.update({ where: { id: order.id }, data: { status: "failed" } });
    console.error("[order] gagal create payment", e);
    return err(502, "Gagal menghubungi penyedia pembayaran. Coba lagi nanti.");
  }
}

export async function GET(req: Request) {
  const auth = await requireUser(req);
  if ("error" in auth) return auth.error;
  const orders = await db.order.findMany({
    where: { userId: auth.user.id },
    orderBy: { createdAt: "desc" },
    take: 50,
    include: { product: { select: { name: true } } },
  });
  return json({
    orders: orders.map((o) => ({
      id: o.id,
      productName: o.product.name,
      gems: o.gems,
      amountIdr: o.amountIdr,
      status: o.status,
      provider: o.provider,
      createdAt: o.createdAt,
      paidAt: o.paidAt,
    })),
  });
}
