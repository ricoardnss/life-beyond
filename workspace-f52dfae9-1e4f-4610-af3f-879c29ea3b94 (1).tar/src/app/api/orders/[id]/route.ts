// GET /api/orders/[id] — detail order, hanya pemilik atau admin.
import { db } from "@/lib/db";
import { err, json, requireUser } from "@/lib/api-helpers";

export async function GET(req: Request, { params }: { params: Promise<{ id: string }> }) {
  const auth = await requireUser(req);
  if ("error" in auth) return auth.error;
  const { id } = await params;

  const order = await db.order.findUnique({
    where: { id },
    include: { product: { select: { name: true, gems: true } } },
  });
  if (!order) return err(404, "Order tidak ditemukan.");
  // PEMBATASAN AKSES: pemilik atau admin
  if (order.userId !== auth.user.id && auth.user.role !== "admin") {
    return err(403, "Order ini bukan milikmu.");
  }
  return json({
    order: {
      id: order.id,
      productId: order.productId,
      productName: order.product.name,
      gems: order.gems,
      amountIdr: order.amountIdr,
      currency: order.currency,
      status: order.status,
      provider: order.provider,
      createdAt: order.createdAt,
      paidAt: order.paidAt,
      fulfilledAt: order.fulfilledAt,
      expiresAt: order.expiresAt,
    },
  });
}
