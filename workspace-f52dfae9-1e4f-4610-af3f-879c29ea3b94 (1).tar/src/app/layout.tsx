import type { Metadata, Viewport } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "KOTA KITA: Life Beyond — Simulasi Kehidupan Pixel",
  description:
    "A little life. A thousand possibilities. Game simulasi kehidupan pixel-art di Kota Arunika + KOTA KITA STORE untuk top-up Arunika Gems.",
  keywords: ["KOTA KITA", "Life Beyond", "life simulator", "pixel art", "game Indonesia", "Kota Arunika", "top up"],
  authors: [{ name: "KOTA KITA Studio" }],
};

export const viewport: Viewport = {
  themeColor: "#0B0E1A",
  width: "device-width",
  initialScale: 1,
  // Game: cegah pinch-zoom tak sengaja saat memainkan, dan hormati notch/safe-area.
  maximumScale: 1,
  userScalable: false,
  viewportFit: "cover",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="id" suppressHydrationWarning>
      <body className={`${geistSans.variable} ${geistMono.variable} antialiased bg-[#0B0E1A] text-white`}>
        {children}
        <Toaster />
      </body>
    </html>
  );
}
