# -*- coding: utf-8 -*-
"""gen_audio_extra.py — SFX tambahan: guntur badai (musim/cuaca lengkap)."""
import math, random, struct, wave

OUT = "/home/z/my-project/public/game/audio"

def write_wav(name, samples, rate=22050):
    with wave.open(f"{OUT}/{name}.wav", "w") as w:
        w.setnchannels(1)
        w.setsampwidth(2)
        w.setframerate(rate)
        frames = bytearray()
        for v in samples:
            v = max(-1.0, min(1.0, v))
            frames += struct.pack("<h", int(v * 32000))
        w.writeframes(bytes(frames))

def thunder(seed=11):
    rng = random.Random(seed)
    rate = 22050
    dur = 2.6
    n = int(rate * dur)
    out = []
    # derau rendah berlapis dengan envelope tumpul (rumble) + dua gelombang derak
    for i in range(n):
        t = i / rate
        env = math.exp(-2.6 * t) * min(1.0, t * 40)
        a = rng.uniform(-1, 1)
        b = rng.uniform(-1, 1)
        v = (a * 0.6 + b * 0.4) * env
        # resonansi rendah
        v += 0.35 * math.sin(2 * math.pi * (48 + 18 * math.exp(-3 * t)) * t) * env
        out.append(v * 0.85)
    # normalisasi lembut
    m = max(abs(v) for v in out) or 1
    return [v / m * 0.9 for v in out]

write_wav("thunder", thunder())
print("thunder.wav OK")
