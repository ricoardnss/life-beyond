# -*- coding: utf-8 -*-
"""gen_audio.py — Audio sintetis KOTA KITA: musik lo-fi siang/malam, hujan, SFX.
Semua audio dibuat dari nol (bebas lisensi), disimpan sebagai WAV 22050 Hz mono 16-bit."""
import math
import random
import struct
import wave

SR = 22050
OUT = "/home/z/my-project/public/game/audio"

N = {
    "C2": 65.41, "D2": 73.42, "E2": 82.41, "F2": 87.31, "G2": 98.0, "A2": 110.0, "B2": 123.47,
    "C3": 130.81, "D3": 146.83, "E3": 164.81, "F3": 174.61, "G3": 196.0, "A3": 220.0, "B3": 246.94,
    "C4": 261.63, "D4": 293.66, "E4": 329.63, "F4": 349.23, "G4": 392.0, "A4": 440.0, "B4": 493.88,
    "C5": 523.25, "D5": 587.33, "E5": 659.26, "G5": 783.99, "A5": 880.0, "C6": 1046.5,
}


def write_wav(name, data):
    """data: list of float -1..1"""
    path = f"{OUT}/{name}"
    pcm = b"".join(struct.pack("<h", max(-32767, min(32767, int(s * 32767)))) for s in data)
    with wave.open(path, "wb") as w:
        w.setnchannels(1)
        w.setsampwidth(2)
        w.setframerate(SR)
        w.writeframes(pcm)
    print(f"  ✓ {name} ({len(data)/SR:.1f}s, {len(pcm)/1024:.0f} KB)")


def make_buffer(seconds):
    return [0.0] * int(SR * seconds)


def add_tone(buf, start, dur, freq, vol=0.2, wave_type="sine", attack=0.02, release=0.06, vib=0.0, vibf=5.0):
    i0 = int(start * SR)
    n = int(dur * SR)
    phase = 0.0
    for i in range(n):
        idx = i0 + i
        if idx >= len(buf):
            break
        t = i / SR
        if t < attack:
            env = t / max(attack, 1e-4)
        elif t > dur - release:
            env = max(0.0, (dur - t) / max(release, 1e-4))
        else:
            env = 1.0
        f = freq * (1.0 + vib * math.sin(2 * math.pi * vibf * t))
        phase += 2 * math.pi * f / SR
        if wave_type == "sine":
            s = math.sin(phase)
        elif wave_type == "tri":
            s = 2 / math.pi * math.asin(math.sin(phase))
        elif wave_type == "soft":
            s = 0.6 * math.sin(phase) + 0.4 * math.sin(phase * 2)
        else:
            s = math.sin(phase)
        buf[idx] += s * vol * env


def add_noise_hit(buf, start, dur, vol=0.2, lp=0.3, rnd=None):
    rnd = rnd or random
    i0 = int(start * SR)
    n = int(dur * SR)
    prev = 0.0
    for i in range(n):
        idx = i0 + i
        if idx >= len(buf):
            break
        t = i / SR
        env = max(0.0, 1.0 - t / dur) ** 2
        w = rnd.uniform(-1, 1)
        prev = prev * lp + w * (1 - lp)
        buf[idx] += prev * vol * env


def loopify(buf, fade=0.4):
    """Sambung ekor ke kepala agar loop mulus."""
    n = len(buf)
    f = int(fade * SR)
    for i in range(f):
        t = i / f
        buf[i] += buf[n - f + i] * t
    return buf[: n - f]


def music_day():
    rnd = random.Random(11)
    bar = 3.0
    chords = [
        ["C3", "E3", "G3", "B3"], ["A2", "C3", "E3", "G3"],
        ["F2", "A2", "C3", "E3"], ["G2", "B2", "D3", "F3"],
    ]
    melody = [["E4", "G4", "B4", "G4"], ["C4", "E4", "G4", "E4"], ["A3", "C4", "F4", "A4"], ["B3", "D4", "G4", "B4"]]
    total = bar * 2 * 4 + 0.5
    buf = make_buffer(total)
    for ci, ch in enumerate(chords):
        t0 = ci * bar * 2
        # bass
        for b in range(8):
            add_tone(buf, t0 + b * 0.75, 0.6, N[ch[0]] / 2, 0.10, "sine", release=0.2)
        # pad
        for note in ch:
            add_tone(buf, t0, bar * 2 - 0.3, N[note], 0.045, "tri", attack=0.6, release=0.5)
        # arpeggio
        arp = ch + [ch[1]]
        for e in range(16):
            note = arp[e % len(arp)]
            v = 0.075 if e % 4 == 0 else 0.05
            add_tone(buf, t0 + e * 0.375, 0.32, N[note] * 2, v, "tri", release=0.12)
        # melodi lembut
        for m in range(4):
            add_tone(buf, t0 + m * 1.5, 1.2, N[melody[ci][m]], 0.06, "sine", attack=0.08, vib=0.004, release=0.3)
        # shaker halus
        for e in range(16):
            if e % 2 == 1:
                add_noise_hit(buf, t0 + e * 0.375, 0.05, 0.012, lp=0.85, rnd=rnd)
    loopify(buf)
    write_wav("music_day.wav", buf)


def music_night():
    rnd = random.Random(23)
    bar = 3.4
    chords = [["A2", "C3", "E3", "G3"], ["D2", "F2", "A2", "C3"], ["F2", "A2", "C3", "E3"], ["E2", "G2", "B2", "D3"]]
    total = bar * 2 * 4 + 0.5
    buf = make_buffer(total)
    for ci, ch in enumerate(chords):
        t0 = ci * bar * 2
        for note in ch:
            add_tone(buf, t0, bar * 2 - 0.4, N[note], 0.035, "sine", attack=1.0, release=0.8)
        add_tone(buf, t0, bar * 2, N[ch[0]] / 2, 0.09, "sine", release=0.5)
        # nada tunggal langka, sedih
        for m, (dt, note) in enumerate([(0.0, "E4"), (2.4, "C4"), (4.6, "A3"), (7.2, "B3")]):
            add_tone(buf, t0 + dt, 1.6, N[note], 0.05, "sine", attack=0.2, vib=0.005, release=0.7)
        for e in range(4):
            add_noise_hit(buf, t0 + 0.85 + e * 1.7, 0.06, 0.008, lp=0.9, rnd=rnd)
    loopify(buf)
    write_wav("music_night.wav", buf)


def rain():
    rnd = random.Random(31)
    total = 14.0
    buf = make_buffer(total)
    prev = 0.0
    for i in range(len(buf)):
        w = rnd.uniform(-1, 1)
        prev = prev * 0.82 + w * 0.18
        buf[i] = prev * 0.32
    # percikan tetes acak
    for _ in range(240):
        t = rnd.uniform(0, total - 0.05)
        add_noise_hit(buf, t, 0.03, 0.06, lp=0.5, rnd=rnd)
    # gemuruh jauh sekali-sekali
    add_noise_hit(buf, 9.0, 1.6, 0.05, lp=0.97, rnd=rnd)
    loopify(buf, 1.0)
    write_wav("rain.wav", buf)


def sfx():
    rnd = random.Random(7)
    # langkah kaki
    b = make_buffer(0.12)
    add_noise_hit(b, 0, 0.09, 0.5, lp=0.55, rnd=rnd)
    write_wav("sfx_step.wav", b)
    # pintu
    b = make_buffer(0.45)
    add_tone(b, 0, 0.3, 340, 0.16, "tri", attack=0.01, release=0.1, vib=0.06, vibf=9)
    add_tone(b, 0.05, 0.3, 260, 0.12, "tri", attack=0.02, release=0.15)
    add_noise_hit(b, 0.34, 0.06, 0.3, lp=0.5, rnd=rnd)
    write_wav("sfx_door.wav", b)
    # koin
    b = make_buffer(0.3)
    add_tone(b, 0, 0.1, 987.77, 0.2, "sine", release=0.03)
    add_tone(b, 0.09, 0.2, 1318.5, 0.22, "sine", release=0.12)
    write_wav("sfx_coin.wav", b)
    # klik UI
    b = make_buffer(0.06)
    add_tone(b, 0, 0.045, 1600, 0.14, "sine", release=0.02)
    write_wav("sfx_click.wav", b)
    # makan
    b = make_buffer(0.5)
    for i in range(3):
        add_noise_hit(b, i * 0.14, 0.09, 0.34, lp=0.45, rnd=rnd)
    write_wav("sfx_eat.wav", b)
    # sukses
    b = make_buffer(0.65)
    for i, n in enumerate(("C5", "E5", "G5", "C6")):
        add_tone(b, i * 0.11, 0.3, N[n], 0.16, "tri", release=0.15)
    write_wav("sfx_success.wav", b)
    # gagal
    b = make_buffer(0.6)
    for i, f in enumerate((320, 260, 190)):
        add_tone(b, i * 0.16, 0.22, f, 0.18, "soft", release=0.1)
    write_wav("sfx_fail.wav", b)
    # notifikasi ponsel
    b = make_buffer(0.7)
    add_tone(b, 0, 0.5, 880, 0.12, "sine", attack=0.005, release=0.3)
    add_tone(b, 0.02, 0.5, 1760, 0.05, "sine", release=0.35)
    write_wav("sfx_notify.wav", b)
    # pop chat
    b = make_buffer(0.15)
    add_tone(b, 0, 0.1, 520, 0.18, "sine", attack=0.005, vib=0.15, vibf=40, release=0.05)
    write_wav("sfx_pop.wav", b)
    # kunci koin jual/beli gagal (reject)
    b = make_buffer(0.25)
    add_tone(b, 0, 0.18, 180, 0.2, "soft", release=0.1)
    write_wav("sfx_reject.wav", b)


if __name__ == "__main__":
    import os

    os.makedirs(OUT, exist_ok=True)
    print("Musik:")
    music_day()
    music_night()
    print("Ambience:")
    rain()
    print("SFX:")
    sfx()
