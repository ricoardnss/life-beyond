# -*- coding: utf-8 -*-
"""gen_icons.py — Atlas ikon item 24x24 (8 kolom x 3 baris) + manifest JSON.
Dipakai React (CSS background-position) dan Phaser (atlas frame)."""
import json
import random

from pixel import C, P, save, shade

OUT = "/home/z/my-project/public/game/assets"
S = 24

WOOD = P["wood"]
GOLD = (240, 200, 90, 255)


def plate(c, y=14):
    """Piring dasar untuk makanan."""
    c.ellipse(12, y + 2, 10, 4, (222, 220, 214, 255))
    c.ellipse(12, y + 1, 9, 3, (240, 238, 232, 255))


def i_nasi_goreng():
    c = C(S, S)
    plate(c)
    c.ellipse(12, 13, 7, 3.4, (196, 132, 60, 255))
    c.ellipse(11, 12, 6, 2.6, (216, 152, 76, 255))
    for x, y in ((8, 13), (14, 11), (16, 14), (10, 15)):
        c.set(x, y, (110, 150, 70, 255))  # daun bawang
    c.rect(15, 10, 3, 2, (230, 170, 90, 255))
    c.outline(soft=True)
    return c


def i_ayam_geprek():
    c = C(S, S)
    plate(c)
    c.ellipse(12, 13, 8, 4, (214, 150, 80, 255))  # ayam goreng
    c.ellipse(12, 12, 7, 3, (232, 176, 104, 255))
    c.noise(6, 9, 12, 7, [(180, 116, 56, 255), (150, 90, 44, 255)], 0.35, random.Random(2))  # crispy
    c.set(7, 15, (200, 70, 60, 255))  # cabai
    c.set(16, 15, (200, 70, 60, 255))
    c.rect(8, 16, 8, 1, (170, 60, 50, 255))
    c.outline(soft=True)
    return c


def i_mie_instan():
    c = C(S, S)
    c.rect(4, 5, 16, 15, (230, 90, 70, 255))  # bungkus
    c.rect(5, 6, 14, 13, (240, 110, 84, 255))
    c.rect(6, 8, 12, 7, (250, 230, 200, 255))  # label
    c.rect(8, 10, 8, 2, (200, 70, 56, 255))
    c.rect(8, 13, 6, 1, (200, 70, 56, 255))
    c.hline(4, 18, 16, (190, 70, 56, 255))
    c.outline(soft=True)
    return c


def i_roti():
    c = C(S, S)
    c.ellipse(12, 14, 9, 5, (222, 168, 100, 255))
    c.ellipse(12, 12, 8, 4, (238, 190, 120, 255))
    c.hline(8, 11, 8, (200, 140, 80, 255))  # belahan roti
    c.rect(6, 17, 12, 2, (206, 150, 86, 255))
    c.outline(soft=True)
    return c


def i_nasi_bungkus():
    c = C(S, S)
    c.rect(6, 8, 12, 12, (250, 244, 228, 255))  # kertas
    c.rect(6, 8, 12, 3, (238, 230, 210, 255))
    c.ellipse(12, 11, 5, 2.4, (250, 246, 238, 255))  # nasi
    c.noise(8, 9, 8, 4, [(232, 228, 218, 255)], 0.4, random.Random(3))
    c.hline(6, 13, 12, (200, 190, 170, 255))
    c.rect(10, 17, 4, 3, (180, 170, 150, 255))  # lipatan bawah
    c.outline(soft=True)
    return c


def i_jus_jeruk():
    c = C(S, S)
    c.rect(7, 7, 10, 13, (250, 244, 232, 255))
    c.rect(8, 10, 8, 9, (240, 160, 60, 255))
    c.hline(8, 12, 8, (248, 190, 100, 255))
    c.rect(6, 5, 12, 2, (230, 226, 218, 255))  # tutup
    c.ellipse(18, 8, 3, 3, (240, 170, 70, 255))  # irisan jeruk
    c.ellipse(18, 8, 1.6, 1.6, (250, 210, 120, 255))
    c.outline(soft=True)
    return c


def i_es_teh():
    c = C(S, S)
    c.rect(7, 8, 10, 12, (250, 244, 232, 255))
    c.rect(8, 10, 8, 9, (190, 130, 60, 255))  # teh
    c.hline(8, 12, 8, (230, 180, 100, 255))
    c.rect(7, 8, 10, 2, (250, 244, 232, 255))
    c.rect(16, 6, 1, 12, (240, 240, 240, 255))  # sedotan
    c.set(17, 5, (240, 240, 240, 255))
    c.outline(soft=True)
    return c


def i_kopi():
    c = C(S, S)
    c.rect(6, 9, 12, 10, (250, 244, 232, 255))  # gelas
    c.rect(7, 12, 10, 6, (110, 74, 48, 255))  # kopi
    c.rect(7, 11, 10, 2, (200, 160, 120, 255))  # susu di atas
    c.rect(6, 9, 12, 2, (230, 226, 218, 255))
    c.vline(17, 7, 12, (240, 240, 240, 255))
    c.outline(soft=True)
    return c


def i_air_botol():
    c = C(S, S)
    c.rect(9, 4, 6, 3, (90, 130, 190, 255))  # tutup
    c.rect(8, 7, 8, 13, (200, 226, 244, 255))
    c.rect(9, 8, 2, 11, (226, 240, 250, 255))
    c.rect(8, 12, 8, 4, (170, 205, 230, 255))  # label
    c.rect(8, 20, 8, 1, (180, 214, 236, 255))
    c.outline(soft=True)
    return c


def i_telur():
    c = C(S, S)
    c.ellipse(9, 13, 4.5, 6, (244, 230, 208, 255))
    c.ellipse(15, 15, 4.5, 5.5, (238, 222, 196, 255))
    c.ellipse(8, 11, 1.6, 2.4, (252, 244, 228, 255))
    c.outline(soft=True)
    return c


def i_cabai():
    c = C(S, S)
    for (x1, y1, x2, y2, wdt) in ((8, 8, 15, 16, 3), (13, 7, 17, 14, 2)):
        steps = max(abs(x2 - x1), abs(y2 - y1))
        for i in range(steps):
            t = i / steps
            x = x1 + (x2 - x1) * t
            y = y1 + (y2 - y1) * t
            c.rect(x, y, wdt - i // 5, 2, (210, 60, 50, 255))
    c.set(8, 7, (90, 140, 70, 255))  # tangkai
    c.set(13, 6, (90, 140, 70, 255))
    c.outline(soft=True)
    return c


def i_beras():
    c = C(S, S)
    c.rect(5, 8, 14, 12, (232, 220, 196, 255))  # karung
    c.rect(5, 8, 14, 3, (214, 202, 178, 255))
    c.hline(5, 12, 14, (210, 198, 174, 255))
    c.rect(9, 4, 6, 4, (214, 202, 178, 255))  # ikat atas
    c.noise(6, 14, 12, 5, [(244, 236, 220, 255)], 0.3, random.Random(4))  # butir
    c.outline(soft=True)
    return c


def i_sabun():
    c = C(S, S)
    c.rect(5, 10, 14, 8, (150, 200, 220, 255))
    c.rect(6, 11, 12, 6, (180, 220, 236, 255))
    c.hline(6, 11, 12, (210, 236, 246, 255))
    c.ellipse(16, 9, 3, 2, (200, 232, 244, 160))  # gelembung
    c.ellipse(18, 14, 2, 1.6, (200, 232, 244, 160))
    c.outline(soft=True)
    return c


def i_obat():
    c = C(S, S)
    c.rect(9, 4, 6, 4, (220, 90, 80, 255))  # tutup
    c.rect(7, 8, 10, 12, (240, 244, 248, 255))
    c.rect(8, 10, 8, 6, (250, 250, 252, 255))
    c.rect(9, 12, 6, 1, (220, 90, 80, 255))
    c.outline(soft=True)
    return c


def i_buku():
    c = C(S, S)
    c.rect(4, 6, 14, 13, (150, 90, 60, 255))
    c.rect(6, 8, 12, 11, (238, 232, 218, 255))
    c.rect(6, 8, 2, 11, (200, 140, 100, 255))
    c.hline(9, 11, 7, (180, 174, 160, 255))
    c.hline(9, 13, 7, (180, 174, 160, 255))
    c.hline(9, 15, 5, (180, 174, 160, 255))
    c.outline(soft=True)
    return c


def i_sketchbook():
    c = C(S, S)
    c.rect(4, 5, 15, 14, (90, 70, 110, 255))
    c.rect(6, 7, 12, 11, (244, 240, 232, 255))
    # sketsa gunung + matahari
    for i in range(5):
        c.rect(8 + i, 14 - i, 1, 1 + i, (150, 150, 150, 255))
        c.rect(14 - i + 2, 14 - i, 1, 1 + i, (150, 150, 150, 255))
    c.ellipse(16, 10, 2, 2, (240, 180, 90, 255))
    c.outline(soft=True)
    return c


def i_kaos():
    c = C(S, S)
    c.rect(6, 6, 12, 13, (90, 170, 130, 255))
    c.rect(4, 6, 4, 6, (80, 150, 114, 255))
    c.rect(16, 6, 4, 6, (80, 150, 114, 255))
    c.rect(9, 4, 6, 3, (80, 150, 114, 255))  # kerah
    c.rect(6, 17, 12, 2, (74, 136, 104, 255))
    c.outline(soft=True)
    return c


def i_jaket():
    c = C(S, S)
    c.rect(6, 6, 12, 14, (96, 118, 168, 255))
    c.rect(4, 6, 4, 7, (76, 94, 140, 255))
    c.rect(16, 6, 4, 7, (76, 94, 140, 255))
    c.rect(9, 4, 6, 3, (76, 94, 140, 255))
    c.vline(12, 8, 12, (60, 74, 112, 255))
    c.rect(8, 15, 3, 2, (240, 200, 90, 255))  # kancing
    c.rect(13, 15, 3, 2, (240, 200, 90, 255))
    c.outline(soft=True)
    return c


def i_paket():
    c = C(S, S)
    c.rect(4, 7, 16, 12, (196, 148, 92, 255))
    c.rect(4, 7, 16, 3, (216, 170, 110, 255))
    c.hline(4, 12, 16, (160, 116, 70, 255))
    c.vline(11, 7, 12, (222, 196, 150, 255))
    c.rect(10, 10, 4, 4, (240, 210, 120, 255))  # lakban label
    c.outline(soft=True)
    return c


def i_sparepart():
    c = C(S, S)
    import math

    for a in range(0, 360, 30):
        x = 12 + 7 * math.cos(math.radians(a))
        y = 12 + 7 * math.sin(math.radians(a))
        c.ellipse(x, y, 2.4, 2.4, (110, 116, 126, 255))
    c.ellipse(12, 12, 8, 8, (140, 146, 156, 255))
    c.ellipse(12, 12, 3, 3, (70, 74, 82, 255))
    c.ellipse(10, 10, 2, 2, (180, 186, 196, 255))
    c.outline(soft=True)
    return c


def i_sampah():
    c = C(S, S)
    c.ellipse(11, 16, 7, 4, (150, 140, 120, 255))
    c.rect(6, 8, 5, 8, (198, 172, 118, 255))  # kaleng
    c.rect(12, 10, 6, 6, (140, 160, 140, 255))  # botol
    c.rect(8, 5, 8, 3, (180, 150, 100, 255))  # kardus kecil
    c.set(16, 7, (210, 190, 150, 255))
    c.outline(soft=True)
    return c


def i_kucing():
    c = C(S, S)
    c.ellipse(12, 15, 8, 5, (222, 150, 80, 255))
    c.ellipse(17, 9, 5, 4.4, (222, 150, 80, 255))
    c.set(14, 4, (222, 150, 80, 255))
    c.set(20, 4, (222, 150, 80, 255))
    c.set(14, 5, (170, 110, 60, 255))
    c.set(20, 5, (170, 110, 60, 255))
    c.set(16, 9, (40, 32, 30, 255))
    c.set(19, 9, (40, 32, 30, 255))
    c.rect(5, 18, 2, 4, (200, 130, 66, 255))
    c.rect(8, 19, 2, 3, (200, 130, 66, 255))
    c.rect(4, 12, 4, 2, (222, 150, 80, 255))  # ekor
    c.outline(soft=True)
    return c


def i_hadiah_bunga():
    c = C(S, S)
    c.rect(9, 12, 6, 9, (150, 100, 70, 255))  # bungkus
    c.rect(9, 12, 6, 2, (170, 120, 86, 255))
    for (x, y, col) in ((10, 8, P["red"]), (14, 6, P["yellow"]), (13, 10, (240, 170, 200, 255))):
        c.ellipse(x, y, 2.4, 2.4, col)
        c.set(x, y, (250, 240, 200, 255))
    c.vline(12, 11, 3, (90, 140, 70, 255))
    c.outline(soft=True)
    return c


def i_hadiah_kue():
    c = C(S, S)
    c.rect(6, 10, 12, 10, (240, 200, 150, 255))  # kotak
    c.rect(6, 10, 12, 2, (250, 220, 170, 255))
    c.hline(6, 15, 12, (220, 170, 120, 255))
    c.vline(11, 10, 10, (220, 170, 120, 255))
    c.rect(10, 7, 4, 3, (160, 107, 224, 255))  # pita
    c.ellipse(8, 7, 2, 1.6, (160, 107, 224, 255))
    c.ellipse(16, 7, 2, 1.6, (160, 107, 224, 255))
    c.outline(soft=True)
    return c


ICONS = {
    "nasi_goreng": i_nasi_goreng, "ayam_geprek": i_ayam_geprek, "mie_instan": i_mie_instan,
    "roti": i_roti, "nasi_bungkus": i_nasi_bungkus, "jus_jeruk": i_jus_jeruk,
    "es_teh": i_es_teh, "kopi": i_kopi,
    "air_botol": i_air_botol, "telur": i_telur, "cabai": i_cabai, "beras": i_beras,
    "sabun": i_sabun, "obat": i_obat, "buku": i_buku, "sketchbook": i_sketchbook,
    "kaos": i_kaos, "jaket": i_jaket, "paket": i_paket, "sparepart": i_sparepart,
    "sampah": i_sampah, "kucing": i_kucing, "hadiah_bunga": i_hadiah_bunga, "hadiah_kue": i_hadiah_kue,
}


def main():
    cols = 8
    rows = 3
    sheet = C(S * cols, S * rows)
    manifest = {}
    for idx, (name, fn) in enumerate(ICONS.items()):
        x, y = (idx % cols) * S, (idx // cols) * S
        sheet.img.alpha_composite(fn().img, (x, y))
        manifest[name] = {"x": x, "y": y, "w": S, "h": S}
    save(sheet.img, f"{OUT}/icons.png")
    with open(f"{OUT}/manifest.json", "w") as f:
        json.dump({"iconSize": S, "icons": manifest}, f, indent=1)
    print(f"Manifest: {len(manifest)} ikon")


if __name__ == "__main__":
    main()
