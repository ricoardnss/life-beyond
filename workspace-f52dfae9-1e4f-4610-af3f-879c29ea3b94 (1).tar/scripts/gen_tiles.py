# -*- coding: utf-8 -*-
"""gen_tiles.py — Tileset 32x32: outdoor (jalan, rumput, air) + interior."""
import random

from pixel import C, P, save, shade

T = 32
OUT = "/home/z/my-project/public/game/assets"


def grass_tile(seed, flowers=False):
    rng = random.Random(seed)
    c = C(T, T, P["grass"])
    c.noise(0, 0, T, T, [P["grass_d"]], 0.06, rng)
    c.noise(0, 0, T, T, [P["grass_l"]], 0.045, rng)
    # helai rumput pendek 2px
    for _ in range(10):
        x, y = rng.randrange(1, T - 1), rng.randrange(1, T - 2)
        c.vline(x, y, 2, P["grass_d"] if rng.random() < 0.6 else P["grass_l"])
    if flowers:
        for _ in range(4):
            x, y = rng.randrange(3, T - 4), rng.randrange(3, T - 4)
            col = rng.choice([P["white"], P["red"], P["yellow"], (240, 170, 200, 255)])
            c.rect(x, y, 2, 2, col)
            c.set(x + 1, y, shade(col, 1.2))
            c.set(x + 1, y + 2, P["grass_d"])
    return c


def dirt_tile(seed):
    rng = random.Random(seed)
    c = C(T, T, P["dirt"])
    c.noise(0, 0, T, T, [P["dirt_d"]], 0.09, rng)
    c.noise(0, 0, T, T, [shade(P["dirt"], 1.12)], 0.05, rng)
    for _ in range(3):
        x, y = rng.randrange(2, T - 3), rng.randrange(2, T - 3)
        c.rect(x, y, 2, 1, (128, 108, 78, 255))
    return c


def road_tile(seed, variant="plain"):
    rng = random.Random(seed)
    c = C(T, T, P["road"])
    c.noise(0, 0, T, T, [P["road_d"], P["road_l"]], 0.05, rng)
    if variant == "crack":
        x, y = rng.randrange(6, 12), 2
        for _ in range(26):
            c.set(x, y, P["road_d"])
            c.set(x + 1, y, shade(P["road_d"], 0.9))
            x += rng.choice([0, 1, 1, -1])
            y += 1
            if y >= T - 1:
                break
    elif variant == "mark_h":
        for sx in (3, 19):
            c.rect(sx, 15, 10, 2, P["mark"])
            c.rect(sx, 15, 10, 1, shade(P["mark"], 1.1))
    elif variant == "mark_v":
        for sy in (3, 19):
            c.rect(15, sy, 2, 10, P["mark"])
            c.rect(15, sy, 1, 10, shade(P["mark"], 1.1))
    elif variant == "crosswalk":
        for yy in (5, 13, 21, 29):
            c.rect(2, yy, 28, 4, P["white"])
            c.rect(2, yy + 3, 28, 1, (200, 200, 196, 255))
    elif variant == "edge_top":
        # kerb batas trotoar -> jalan
        c.hline(0, 0, T, (188, 182, 168, 255))
        c.hline(0, 1, T, shade(P["road"], 1.25))
    return c


def sidewalk_tile(seed, v2=False):
    rng = random.Random(seed)
    base = shade(P["side"], 0.97) if v2 else P["side"]
    c = C(T, T, base)
    # nat ubin
    c.hline(0, 0, T, P["side_d"])
    c.hline(0, 16, T, P["side_d"])
    c.vline(0, 0, T, P["side_d"])
    c.vline(16, 0, T, P["side_d"])
    c.noise(0, 0, T, T, [P["side_l"]], 0.04, rng)
    c.noise(0, 0, T, T, [P["side_d"]], 0.03, rng)
    return c


def water_tile(seed, frame=0):
    rng = random.Random(seed + frame * 100)
    c = C(T, T, P["water"])
    c.noise(0, 0, T, T, [P["water_d"]], 0.06, rng)
    # riak: garis lengkung pendek
    for _ in range(5):
        x, y = rng.randrange(0, T - 8), rng.randrange(2, T - 3)
        for dx in range(6):
            c.set(x + dx, y + (1 if dx in (2, 3) else 0), P["water_l"] if frame else shade(P["water_l"], 0.92))
    if frame == 1:
        for _ in range(4):
            x, y = rng.randrange(0, T - 6), rng.randrange(2, T - 2)
            c.set(x, y, P["white"])
    return c


def gravel_tile(seed):
    rng = random.Random(seed)
    c = C(T, T, (150, 142, 128, 255))
    c.noise(0, 0, T, T, [(128, 120, 106, 255), (172, 164, 150, 255), (112, 104, 92, 255)], 0.16, rng)
    return c


# ---------- Interior ----------
def ceramic_tile(seed):
    rng = random.Random(seed)
    a = (222, 214, 196, 255)
    b = (206, 196, 178, 255)
    c = C(T, T, a)
    for yy in range(0, T, 16):
        for xx in range(0, T, 16):
            if (xx // 16 + yy // 16) % 2 == 1:
                c.rect(xx, yy, 16, 16, b)
    for v in (0, 16):
        c.hline(0, v, T, shade(a, 0.82))
        c.vline(v, 0, T, shade(a, 0.82))
    c.noise(0, 0, T, T, [shade(a, 1.05)], 0.02, rng)
    return c


def wood_tile(seed):
    rng = random.Random(seed)
    c = C(T, T, P["wood"])
    for y in range(0, T, 8):
        c.hline(0, y, T, P["wood_d"])
        c.hline(0, y + 1, T, P["wood_l"])
        # sambungan papan acak
        x = rng.randrange(4, 28)
        c.vline(x, y + 2, 6, P["wood_d"])
        if rng.random() < 0.5:
            kx, ky = rng.randrange(3, 27), y + rng.randrange(3, 6)
            c.ellipse(kx, ky, 2, 1.4, P["wood_d"])
            c.ellipse(kx, ky, 1, 0.8, shade(P["wood_d"], 0.85))
    return c


def concrete_tile(seed):
    rng = random.Random(seed)
    c = C(T, T, (196, 190, 180, 255))
    c.noise(0, 0, T, T, [(178, 172, 162, 255), (210, 205, 196, 255)], 0.07, rng)
    for _ in range(2):
        x, y = rng.randrange(2, T - 8), rng.randrange(2, T - 4)
        for dx in range(rng.randrange(4, 9)):
            c.set(x + dx, y, (170, 164, 154, 255))
    return c


def wall_tile(seed, with_base=True):
    rng = random.Random(seed)
    c = C(T, T, (226, 206, 184, 255))
    c.noise(0, 0, T, T, [(214, 194, 172, 255)], 0.05, rng)
    c.hline(0, 0, T, (240, 224, 204, 255))
    if with_base:
        c.hline(0, T - 7, T, (150, 116, 88, 255))
        c.hline(0, T - 6, T, (170, 134, 104, 255))
        c.hline(0, T - 1, T, (120, 92, 70, 255))
    return c


def mat_tile(seed):
    c = ceramic_tile(seed)
    c.rect(4, 8, 24, 18, (150, 100, 66, 255))
    c.rect(5, 9, 22, 16, (170, 118, 76, 255))
    c.rect(6, 10, 20, 14, (150, 100, 66, 255))
    c.rect(7, 11, 18, 12, (170, 118, 76, 255))
    for x in range(7, 25, 4):
        c.vline(x, 11, 12, (150, 100, 66, 255))
    return c


def main():
    # tileset_outdoor: 8x2 grid
    sheet = C(T * 8, T * 2)
    tiles = [
        grass_tile(1), grass_tile(2), grass_tile(3, flowers=False), dirt_tile(4),
        road_tile(5), road_tile(6, "mark_h"), road_tile(7, "mark_v"), road_tile(8, "crosswalk"),
        sidewalk_tile(9), sidewalk_tile(10, True), water_tile(11, 0), water_tile(11, 1),
        grass_tile(12, flowers=True), gravel_tile(13), road_tile(14, "crack"), road_tile(15, "edge_top"),
    ]
    for i, t in enumerate(tiles):
        sheet.img.alpha_composite(t.img, ((i % 8) * T, (i // 8) * T))
    save(sheet.img, f"{OUT}/tileset_outdoor.png")

    # tileset_interior: 8x1
    sheet2 = C(T * 8, T)
    tiles2 = [ceramic_tile(21), ceramic_tile(22), wood_tile(23), wood_tile(24), concrete_tile(25), wall_tile(26), wall_tile(27), mat_tile(28)]
    for i, t in enumerate(tiles2):
        sheet2.img.alpha_composite(t.img, (i * T, 0))
    save(sheet2.img, f"{OUT}/tileset_interior.png")


if __name__ == "__main__":
    main()
