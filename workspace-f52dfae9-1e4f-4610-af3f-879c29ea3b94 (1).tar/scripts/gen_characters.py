# -*- coding: utf-8 -*-
"""
gen_characters.py — Spritesheet karakter KOTA KITA.
Frame 32x48, sheet 128x192. Baris: bawah, kanan, atas, kiri. Kolom: idle, jalan1, jalan2, jalan3.
Gaya rambut & aksesori parametrik agar tiap NPC punya siluet unik (bukan reskin warna).
"""
import random

from PIL import Image

from pixel import C, P, save, shade

FRAME_W, FRAME_H = 32, 48
DIRS = ["down", "right", "up", "left"]

OUT_DIR = "/home/z/my-project/public/game/assets"


def rounded_rect(c, x, y, w, h, col):
    """Persegi dengan sudut atas-bawah dipangkas 1px — siluet lebih halus."""
    c.rect(x + 1, y, w - 2, h, col)
    c.rect(x, y + 1, w, h - 2, col)


def draw_head(c, ox, oy, ch, frame, bob):
    """Kepala 10x12 di offset (ox,oy). bob = offset vertikal animasi."""
    y0 = oy + bob
    x0 = ox
    skin = P["skin"][ch["skin"]]
    skin_sh = P["skin_sh"][ch["skin"]]
    hair = ch["hair"]
    style = ch["style"]
    d = ch["_dir"]

    # basis kepala
    rounded_rect(c, x0, y0, 10, 12, skin)
    c.rect(x0, y0 + 2, 10, 9, skin)
    # shading sisi kanan kepala
    c.vline(x0 + 9, y0 + 3, 8, skin_sh)

    if d == "down":
        # wajah: rambut menutupi atas + sisi
        c.rect(x0, y0, 10, 4, hair)
        c.rect(x0, y0 + 4, 2, 7, hair)  # pelipis kiri
        c.rect(x0 + 8, y0 + 4, 2, 7, hair)
        # mata
        c.set(x0 + 3, y0 + 7, P["black"])
        c.set(x0 + 4, y0 + 7, P["black"])
        c.set(x0 + 6, y0 + 7, P["black"])
        c.set(x0 + 7, y0 + 7, P["black"])
        # mulut halus
        c.set(x0 + 5, y0 + 10, skin_sh)
    elif d == "right":
        # profil kanan: rambut menutupi belakang (kiri), wajah depan
        c.rect(x0, y0, 7, 4, hair)
        c.rect(x0, y0 + 4, 2, 8, hair)
        c.set(x0 + 7, y0 + 7, P["black"])  # satu mata
        c.set(x0 + 5, y0 + 10, skin_sh)
    elif d == "up":
        # belakang kepala: penuh rambut
        c.rect(x0, y0, 10, 12, hair)
        c.rect(x0 + 2, y0 + 2, 6, 8, hair)
        # highlight rambut
        c.hline(x0 + 2, y0 + 2, 4, shade(hair, 1.25))
    elif d == "left":  # digambar sebagai mirror via sheet
        c.rect(x0, y0, 7, 4, hair)
        c.rect(x0 + 8, y0 + 4, 2, 8, hair)
        c.set(x0 + 2, y0 + 7, P["black"])
        c.set(x0 + 5, y0 + 10, skin_sh)

    # gaya rambut / aksesori kepala
    if style == "short":
        c.rect(x0, y0, 10, 3, hair)
        c.hline(x0 + 1, y0 - 1, 8, hair)
    elif style == "curly":
        c.rect(x0, y0, 10, 4, hair)
        for i, dx in enumerate(range(0, 10, 3)):
            c.ellipse(x0 + dx + 1.5, y0 - 0.5, 1.6, 1.6, hair if i % 2 == 0 else shade(hair, 1.15))
        c.rect(x0, y0 + 4, 2, 8, hair)
        c.rect(x0 + 8, y0 + 4, 2, 8, hair)
    elif style == "spiky":
        c.rect(x0, y0, 10, 3, hair)
        for i in range(4):
            c.set(x0 + 1 + i * 2 + 1, y0 - 2, hair)
            c.set(x0 + 1 + i * 2 + 1, y0 - 1, hair)
    elif style == "long":
        c.rect(x0, y0, 10, 4, hair)
        c.hline(x0 + 1, y0 - 1, 8, hair)
        if d == "down":
            c.rect(x0 - 1, y0 + 4, 3, 9, hair)  # untaian kiri
            c.rect(x0 + 8, y0 + 4, 3, 9, hair)
        elif d == "up":
            c.rect(x0 + 1, y0 + 4, 8, 9, hair)
            c.vline(x0 + 3, y0 + 5, 7, shade(hair, 0.85))
        else:
            c.rect(x0 - 1 if d == "right" else x0 + 9, y0 + 3, 3, 9, hair)
    elif style == "bun":
        c.rect(x0, y0, 10, 4, hair)
        c.ellipse(x0 + 5, y0 - 2, 3, 2, hair)  # sanggul atas
        c.rect(x0, y0 + 4, 2, 7, hair)
        c.rect(x0 + 8, y0 + 4, 2, 7, hair)
    elif style == "cap":
        cap = ch.get("capColor", (52, 62, 90, 255))
        c.rect(x0, y0, 10, 5, cap)
        c.hline(x0 + 1, y0 - 1, 8, cap)
        if d == "down":
            c.rect(x0 + 1, y0 + 4, 8, 1, shade(cap, 0.8))  # brim depan
        elif d == "right":
            c.rect(x0 + 6, y0 + 4, 5, 1, shade(cap, 0.8))
        elif d == "left":
            c.rect(x0 - 1, y0 + 4, 5, 1, shade(cap, 0.8))
        c.set(x0 + 5, y0 + 1, shade(cap, 1.3))
    elif style == "hijab":
        hj = ch["hair"]
        c.ellipse(x0 + 5, y0 + 5, 7, 8, hj)  # kerudung membulat
        c.rect(x0, y0 + 2, 10, 6, hj)
        if d == "down":
            c.rect(x0 + 2, y0 + 5, 6, 7, skin)  # wajah oval
            c.rect(x0, y0 + 8, 2, 6, hj)
            c.rect(x0 + 8, y0 + 8, 2, 6, hj)
            c.set(x0 + 3, y0 + 7, P["black"])
            c.set(x0 + 4, y0 + 7, P["black"])
            c.set(x0 + 6, y0 + 7, P["black"])
            c.set(x0 + 7, y0 + 7, P["black"])
        elif d == "right":
            c.rect(x0 + 4, y0 + 5, 4, 7, skin)
            c.set(x0 + 7, y0 + 7, P["black"])
            c.rect(x0, y0 + 8, 3, 6, hj)
        elif d == "up":
            pass  # penuh kerudung
        else:
            c.rect(x0 + 2, y0 + 5, 4, 7, skin)
            c.set(x0 + 2, y0 + 7, P["black"])
            c.rect(x0 + 7, y0 + 8, 3, 6, hj)
        # penutup dada kerudung
        c.rect(x0 + 2, y0 + 13, 6, 2, shade(hj, 0.9))
    elif style == "beret":
        c.rect(x0, y0, 10, 3, hair)
        c.ellipse(x0 + 4, y0 + 0.5, 5, 2, hair)  # miring
        c.rect(x0 + 2, y0 + 3, 7, 1, shade(hair, 0.8))
        c.rect(x0, y0 + 4, 2, 7, hair)
        c.rect(x0 + 8, y0 + 4, 2, 7, hair)
    elif style == "strawhat":
        st = ch.get("hatColor", (222, 196, 128, 255))
        c.ellipse(x0 + 5, y0 + 2, 8, 3, st)  # brim lebar
        c.ellipse(x0 + 5, y0 - 1, 4, 2.5, shade(st, 1.1))
        c.hline(x0 + 1, y0 + 3, 9, shade(st, 0.8))
    elif style == "pony":
        c.rect(x0, y0, 10, 4, hair)
        c.hline(x0 + 1, y0 - 1, 8, hair)
        c.rect(x0, y0 + 4, 2, 6, hair)
        c.rect(x0 + 8, y0 + 4, 2, 6, hair)
        # ekor kuda di belakang: terlihat saat menghadap atas/samping
        if d == "up":
            c.rect(x0 + 3, y0 + 4, 4, 7, hair)
            c.rect(x0 + 4, y0 + 11, 2, 4, shade(hair, 0.9))
        elif d == "down":
            c.rect(x0 + 4, y0 - 3, 2, 3, hair)  # ikatan kecil di atas
        else:
            c.rect(x0 + (9 if d == "right" else -1), y0 + 2, 2, 6, hair)
    elif style == "afro":
        c.ellipse(x0 + 5, y0 + 2, 12, 10, hair)
        c.rect(x0 + 2, y0 + 4, 8, 4, hair)
        # bulatan teksur afro
        c.ellipse(x0 + 2, y0 - 1, 3, 3, shade(hair, 1.18))
        c.ellipse(x0 + 7, y0 - 1, 3, 3, shade(hair, 0.9))
        c.rect(x0, y0 + 4, 2, 7, hair)
        c.rect(x0 + 8, y0 + 4, 2, 7, hair)
    elif style == "bald":
        c.hline(x0 + 2, y0 + 1, 6, shade(skin, 1.15))
        c.hline(x0 + 1, y0 + 3, 2, shade(skin, 0.92))  # kilau botak
    # highlight rambut generik
    if style not in ("bald", "hijab", "strawhat", "cap"):
        c.hline(x0 + 3, y0 + 1, 3, shade(hair, 1.25))


def draw_body(c, ox, oy, ch, frame, bob):
    y0 = oy + bob
    x0 = ox
    shirt = ch["shirt"]
    shirt2 = ch.get("shirt2", shade(ch["shirt"], 0.82))
    pants = ch["pants"]
    shoes = ch["shoes"]
    d = ch["_dir"]
    f = frame

    # kaki dulu (di belakang torso)
    leg_top = y0 + 30
    if d in ("down", "up"):
        lx, rx = x0 + 1, x0 + 7
        if f == 0 or f == 2:
            c.rect(lx, leg_top, 4, 14, pants)
            c.rect(rx, leg_top, 4, 14, pants)
            c.rect(lx, leg_top + 14, 5, 3, shoes)
            c.rect(rx - 1, leg_top + 14, 5, 3, shoes)
        elif f == 1:  # kiri maju
            c.rect(lx, leg_top, 4, 12, pants)
            c.rect(lx, leg_top + 12, 5, 3, shoes)
            c.rect(rx, leg_top + 1, 4, 13, pants)
            c.rect(rx - 1, leg_top + 15, 5, 3, shoes)
        else:  # kanan maju
            c.rect(lx, leg_top + 1, 4, 13, pants)
            c.rect(lx, leg_top + 15, 5, 3, shoes)
            c.rect(rx, leg_top, 4, 12, pants)
            c.rect(rx - 1, leg_top + 12, 5, 3, shoes)
        if d == "up":
            c.vline(lx, leg_top, 12, shade(pants, 0.85))
            c.vline(rx, leg_top, 12, shade(pants, 0.85))
    else:
        # samping: langkah menyilang
        fwd = 1 if d == "right" else -1
        bx = x0 + 4
        if f == 0 or f == 2:
            c.rect(bx - 1, leg_top, 5, 14, pants)
            c.rect(bx - 1, leg_top + 14, 6, 3, shoes)
            c.vline(bx - 1, leg_top, 14, shade(pants, 0.85))
        elif f == 1:
            c.rect(bx + fwd, leg_top, 4, 12, pants)
            c.rect(bx + fwd, leg_top + 12, 5, 3, shoes)
            c.rect(bx - fwd - 2, leg_top, 4, 13, pants)
            c.rect(bx - fwd - 2, leg_top + 13, 5, 3, shoes)
        else:
            c.rect(bx - fwd - 2, leg_top, 4, 12, pants)
            c.rect(bx - fwd - 2, leg_top + 12, 5, 3, shoes)
            c.rect(bx + fwd, leg_top, 4, 13, pants)
            c.rect(bx + fwd, leg_top + 13, 5, 3, shoes)

    # torso
    ty = y0 + 15
    c.rect(x0 + 1, ty, 10, 15, shirt)
    c.rect(x0 + 1, ty, 10, 2, shade(shirt, 1.12))  # bahu terang
    if d == "down":
        c.vline(x0 + 10, ty + 2, 12, shade(shirt, 0.85))  # shading sisi
        c.vline(x0 + 5, ty + 2, 6, shirt2)  # garis kancing/kream
    elif d == "up":
        c.rect(x0 + 3, ty + 2, 6, 12, shade(shirt, 0.92))
    else:
        c.rect(x0 + 1, ty, 10, 15, shirt)
        c.vline(x0 + 1 if ch["_dir"] == "right" else x0 + 10, ty + 2, 12, shade(shirt, 0.85))

    # lengan
    arm_col = shirt
    hand = P["skin"][ch["skin"]]
    if d in ("down", "up"):
        swing = 1 if f == 1 else (-1 if f == 3 else 0)
        c.rect(x0 - 1, ty + 2 + max(0, swing), 2, 9 - abs(swing), arm_col)
        c.rect(x0 + 11, ty + 2 + max(0, -swing), 2, 9 - abs(swing), arm_col)
        c.rect(x0 - 1, ty + 11 + max(0, swing), 2, 2, hand)
        c.rect(x0 + 11, ty + 11 + max(0, -swing), 2, 2, hand)
    else:
        fwd = 1 if d == "right" else -1
        swing = 2 if f == 1 else (-2 if f == 3 else 0)
        ax = x0 + 5 + fwd * swing
        c.rect(ax, ty + 3, 3, 8, arm_col)
        c.rect(ax, ty + 11, 3, 2, hand)

    # aksesori tubuh
    extra = ch.get("extra")
    if extra == "apron" and d in ("down", "up"):
        ap = (240, 234, 220, 255)
        c.rect(x0 + 2, ty + 4, 8, 11, ap)
        c.vline(x0 + 5, ty + 4, 11, shade(ap, 0.9))
        c.set(x0 + 3, ty + 1, shade(ap, 0.85))
        c.set(x0 + 8, ty + 1, shade(ap, 0.85))
    elif extra == "vest" and d in ("down", "up"):
        v = ch.get("vestColor", P["leaf"])
        c.rect(x0 + 1, ty, 3, 15, v)
        c.rect(x0 + 8, ty, 3, 15, v)
        c.rect(x0 + 4, ty + 1, 4, 1, shade(v, 0.9))
    elif extra == "scarf" and d in ("down", "up"):
        c.rect(x0 + 2, ty + 1, 8, 2, ch.get("scarfColor", P["red"]))

    # bayangan kolam kaki digambar scene (bukan di sprite)


def draw_frame(c, gx, gy, ch, frame):
    bob = -1 if frame in (1, 3) else 0
    ch["_dir"] = DIRS[gy]
    if ch["_dir"] == "left":
        # gambar mirror dari kanan: gambar ke kanvas temp lalu flip
        tmp = C(FRAME_W, FRAME_H)
        draw_frame_raw(tmp, 0, 0, ch, frame, "right")
        tmp.img = tmp.img.transpose(Image.FLIP_LEFT_RIGHT)
        c.img.paste(tmp.img, (gx, gy))
        return
    draw_frame_raw(c, gx, gy, ch, frame, ch["_dir"])


def draw_frame_raw(c, ox, oy, ch, frame, d):
    bob = -1 if frame in (1, 3) else 0
    ch["_dir"] = d
    draw_body(c, ox + 11, oy + 1, ch, frame, bob)
    draw_head(c, ox + 11, oy + 3, ch, frame, bob)


def gen_character(ch, path):
    sheet = C(FRAME_W * 4, FRAME_H * 4)
    for gy, d in enumerate(DIRS):
        for gx, f in enumerate(range(4)):
            cell = C(FRAME_W, FRAME_H)
            ch["_dir"] = d
            if d == "left":
                tmp = C(FRAME_W, FRAME_H)
                draw_frame_raw(tmp, 0, 0, ch, f, "right")
                tmp.img = tmp.img.transpose(Image.FLIP_LEFT_RIGHT)
                cell.img.alpha_composite(tmp.img)
            else:
                draw_frame_raw(cell, 0, 0, ch, f, d)
            cell.outline()
            sheet.img.alpha_composite(cell.img, (gx * FRAME_W, gy * FRAME_H))
    save(sheet.img, path)


# ---------- Definisi karakter ----------
BROWN = (92, 62, 44, 255)
DBROWN = (62, 40, 30, 255)
BLACK_H = (38, 32, 36, 255)
DARKORANGE = (200, 108, 60, 255)
NAVY = (52, 62, 90, 255)

PLAYER_DEFAULT = dict(skin=1, hair=BROWN, style="short", shirt=(96, 130, 158, 255), pants=(70, 74, 88, 255), shoes=(50, 44, 48, 255))
OUTFITS = {
    "default": PLAYER_DEFAULT,
    "kaos_merah": dict(skin=1, hair=BROWN, style="short", shirt=(214, 80, 70, 255), pants=(86, 98, 128, 255), shoes=(50, 44, 48, 255)),
    "jaket_denim": dict(skin=1, hair=BROWN, style="short", shirt=(96, 118, 168, 255), shirt2=(70, 90, 130, 255), pants=(46, 46, 52, 255), shoes=(38, 34, 38, 255)),
    "golden": dict(skin=1, hair=(190, 150, 60, 255), style="curly", shirt=(230, 190, 80, 255), shirt2=(190, 150, 60, 255), pants=(160, 120, 50, 255), shoes=(120, 92, 40, 255)),
    "cyber": dict(skin=1, hair=BLACK_H, style="spiky", shirt=(40, 44, 56, 255), shirt2=(79, 216, 224, 255), pants=(36, 38, 48, 255), shoes=(79, 216, 224, 255)),
    "sunset": dict(skin=1, hair=DBROWN, style="long", shirt=(240, 150, 80, 255), shirt2=(240, 200, 120, 255), pants=(150, 90, 70, 255), shoes=(100, 62, 50, 255)),
}

NPCS = {
    "bu_sari": dict(skin=1, hair=DBROWN, style="bun", shirt=(226, 214, 190, 255), pants=(122, 84, 58, 255), shoes=(70, 50, 40, 255), extra="apron"),
    "pak_budi": dict(skin=2, hair=(50, 44, 40, 255), style="cap", capColor=(46, 54, 74, 255), shirt=(108, 118, 84, 255), pants=(88, 96, 70, 255), shoes=(52, 44, 40, 255)),
    "dinda": dict(skin=0, hair=(150, 110, 170, 255), style="hijab", shirt=(150, 210, 190, 255), pants=(70, 74, 88, 255), shoes=(50, 44, 48, 255)),
    "rian": dict(skin=1, hair=BLACK_H, style="cap", capColor=(46, 90, 56, 255), shirt=(235, 150, 70, 255), pants=(70, 74, 88, 255), shoes=(50, 44, 48, 255), extra="vest", vestColor=(70, 140, 84, 255)),
    "maya": dict(skin=0, hair=BLACK_H, style="long", shirt=(245, 240, 232, 255), pants=(80, 80, 90, 255), shoes=(50, 44, 48, 255), extra="vest", vestColor=(206, 74, 66, 255)),
    "bang_jefri": dict(skin=2, hair=BLACK_H, style="spiky", shirt=(79, 190, 200, 255), pants=(54, 58, 66, 255), shoes=(44, 40, 44, 255)),
    "tante_wati": dict(skin=1, hair=(88, 60, 46, 255), style="curly", shirt=(228, 150, 170, 255), shirt2=(240, 200, 210, 255), pants=(190, 110, 130, 255), shoes=(90, 60, 60, 255)),
    "mas_tony": dict(skin=1, hair=BLACK_H, style="short", shirt=(62, 78, 110, 255), pants=(170, 156, 120, 255), shoes=(50, 44, 48, 255)),
    "sinta": dict(skin=0, hair=(150, 90, 60, 255), style="beret", shirt=(216, 170, 80, 255), pants=(90, 84, 110, 255), shoes=(50, 44, 48, 255), extra="scarf", scarfColor=(160, 107, 224, 255)),
    "om_hermanto": dict(skin=3, hair=(200, 190, 170, 255), style="strawhat", hatColor=(222, 196, 128, 255), shirt=(230, 220, 196, 255), pants=(122, 96, 66, 255), shoes=(70, 56, 44, 255)),
}



# ---------- 28 warga baru (permintaan pemain) ----------
# Gaya parametrik: short/curly/spiky/long/bun/cap/hijab/beret/strawhat/bald + extra apron/vest/scarf
NEW_NPCS = {
    "chelsea":  dict(skin=0, hair=(196, 120, 70, 255), style="long", shirt=(214, 138, 148, 255), shirt2=(232, 190, 190, 255), pants=(90, 84, 110, 255), shoes=(50, 44, 48, 255)),
    "rico":     dict(skin=1, hair=BLACK_H, style="spiky", shirt=(94, 130, 96, 255), pants=(52, 56, 66, 255), shoes=(44, 40, 44, 255), extra="vest", vestColor=(60, 90, 70, 255)),
    "akbar":    dict(skin=2, hair=BLACK_H, style="short", shirt=(86, 100, 130, 255), pants=(60, 60, 70, 255), shoes=(44, 40, 44, 255)),
    "virly":    dict(skin=0, hair=(120, 78, 160, 255), style="bun", shirt=(226, 214, 190, 255), shirt2=(180, 160, 140, 255), pants=(100, 90, 120, 255), shoes=(70, 50, 60, 255)),
    "zaki":     dict(skin=1, hair=(70, 50, 40, 255), style="cap", capColor=(120, 70, 60, 255), shirt=(222, 170, 90, 255), pants=(70, 74, 88, 255), shoes=(50, 44, 48, 255)),
    "pijar":    dict(skin=1, hair=(60, 70, 90, 255), style="spiky", shirt=(240, 210, 120, 255), pants=(54, 58, 66, 255), shoes=(44, 40, 44, 255), extra="scarf", scarfColor=(90, 130, 110, 255)),
    "andini":   dict(skin=0, hair=(90, 60, 40, 255), style="long", shirt=(150, 190, 200, 255), shirt2=(200, 226, 230, 255), pants=(80, 80, 90, 255), shoes=(50, 44, 48, 255)),
    "rahma":    dict(skin=1, hair=(110, 80, 60, 255), style="hijab", shirt=(200, 180, 210, 255), pants=(80, 84, 96, 255), shoes=(50, 44, 48, 255)),
    "aulia":    dict(skin=0, hair=BLACK_H, style="pony", shirt=(238, 232, 220, 255), pants=(90, 96, 110, 255), shoes=(50, 44, 48, 255)),
    "agata":    dict(skin=1, hair=(150, 90, 60, 255), style="curly", shirt=(210, 130, 100, 255), shirt2=(235, 190, 160, 255), pants=(100, 84, 76, 255), shoes=(60, 50, 46, 255)),
    "andika":   dict(skin=1, hair=BLACK_H, style="short", shirt=(70, 90, 80, 255), pants=(58, 62, 72, 255), shoes=(44, 40, 44, 255), extra="vest", vestColor=(100, 120, 90, 255)),
    "coco":     dict(skin=2, hair=(56, 44, 40, 255), style="afro", shirt=(224, 160, 80, 255), pants=(70, 60, 56, 255), shoes=(46, 42, 44, 255)),
    "defriska": dict(skin=0, hair=(140, 60, 80, 255), style="long", shirt=(232, 200, 210, 255), shirt2=(210, 160, 175, 255), pants=(88, 90, 104, 255), shoes=(52, 46, 50, 255)),
    "vanesa":   dict(skin=0, hair=(160, 120, 60, 255), style="pony", shirt=(170, 140, 200, 255), shirt2=(200, 180, 220, 255), pants=(84, 88, 100, 255), shoes=(50, 44, 48, 255)),
    "yami":     dict(skin=1, hair=(34, 30, 36, 255), style="long", shirt=(60, 62, 76, 255), shirt2=(94, 98, 116, 255), pants=(40, 40, 48, 255), shoes=(36, 34, 38, 255), extra="scarf", scarfColor=(140, 60, 70, 255)),
    "asta":     dict(skin=3, hair=(232, 226, 210, 255), style="spiky", shirt=(96, 104, 124, 255), pants=(56, 58, 68, 255), shoes=(44, 40, 44, 255)),
    "yuno":     dict(skin=0, hair=(180, 190, 170, 255), style="short", shirt=(150, 200, 170, 255), pants=(70, 74, 88, 255), shoes=(50, 44, 48, 255)),
    "riski":    dict(skin=1, hair=BLACK_H, style="cap", capColor=(40, 60, 90, 255), shirt=(210, 210, 200, 255), pants=(66, 70, 80, 255), shoes=(46, 42, 46, 255)),
    "alip":     dict(skin=2, hair=(48, 40, 36, 255), style="short", shirt=(180, 140, 90, 255), pants=(60, 56, 52, 255), shoes=(44, 40, 44, 255), extra="apron"),
    "amar":     dict(skin=1, hair=(40, 36, 34, 255), style="hijab", shirt=(220, 220, 210, 255), pants=(80, 84, 96, 255), shoes=(50, 44, 48, 255)),
    "abi":      dict(skin=1, hair=(60, 48, 42, 255), style="bald", shirt=(130, 110, 90, 255), pants=(70, 66, 60, 255), shoes=(50, 46, 42, 255)),
    "ali":      dict(skin=0, hair=BLACK_H, style="short", shirt=(110, 150, 170, 255), pants=(58, 62, 72, 255), shoes=(46, 42, 46, 255)),
    "eka":      dict(skin=1, hair=(90, 70, 50, 255), style="bun", shirt=(240, 180, 120, 255), shirt2=(246, 220, 170, 255), pants=(96, 90, 82, 255), shoes=(56, 50, 46, 255)),
    "deka":     dict(skin=2, hair=BLACK_H, style="afro", shirt=(100, 140, 150, 255), pants=(62, 60, 66, 255), shoes=(44, 40, 44, 255), extra="vest", vestColor=(80, 110, 120, 255)),
    "celyin":   dict(skin=0, hair=(210, 170, 90, 255), style="long", shirt=(250, 230, 190, 255), shirt2=(236, 206, 160, 255), pants=(110, 100, 90, 255), shoes=(60, 54, 50, 255)),
    "sandra":   dict(skin=1, hair=(80, 60, 46, 255), style="pony", shirt=(190, 120, 110, 255), shirt2=(220, 170, 160, 255), pants=(84, 88, 100, 255), shoes=(50, 44, 48, 255)),
    "cindy":    dict(skin=0, hair=(150, 100, 70, 255), style="curly", shirt=(240, 240, 235, 255), pants=(90, 90, 100, 255), shoes=(52, 46, 50, 255)),
    "syifa":    dict(skin=1, hair=(90, 110, 90, 255), style="hijab", shirt=(190, 210, 190, 255), pants=(84, 88, 96, 255), shoes=(50, 44, 48, 255)),
}
NPCS.update(NEW_NPCS)


def main():
    import os

    os.makedirs(OUT_DIR, exist_ok=True)
    for name, spec in OUTFITS.items():
        gen_character(dict(spec), f"{OUT_DIR}/player_{name}.png")
    print("Pemain + outfit:")
    for name in OUTFITS:
        print(f"  player_{name}.png")
    for name, spec in NPCS.items():
        gen_character(dict(spec), f"{OUT_DIR}/npc_{name}.png")
    print("NPC:")
    for name in NPCS:
        print(f"  npc_{name}.png")

    # Kucing oren untuk misi "Kucing Hilang"
    rng = random.Random(7)
    cat = C(20, 14)
    cat.ellipse(10, 9, 7, 4, (222, 150, 80, 255))
    cat.ellipse(15, 5, 3.5, 3, (222, 150, 80, 255))
    cat.set(13, 2, (222, 150, 80, 255))
    cat.set(17, 2, (222, 150, 80, 255))
    cat.set(13, 3, (170, 110, 60, 255))
    cat.set(17, 3, (170, 110, 60, 255))
    cat.set(13, 5, (40, 32, 30, 255))
    cat.set(17, 5, (40, 32, 30, 255))
    for i in range(3):
        cat.rect(5 - i, 11 + i % 2, 2, 3, (200, 130, 66, 255))
        cat.rect(14 + i, 11 + i % 2, 2, 3, (200, 130, 66, 255))
    cat.rect(2, 7, 4, 2, (222, 150, 80, 255))
    cat.noise(4, 6, 12, 6, [(190, 120, 60, 255)], 0.08, rng)
    cat.outline()
    save(cat.img, f"{OUT_DIR}/cat.png")


if __name__ == "__main__":
    main()
