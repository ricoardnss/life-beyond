# -*- coding: utf-8 -*-
"""
pixel.py — Helper pixel-art untuk generator aset KOTA KITA: Life Beyond.
Semua aset digenerate programatik (100% buatan sendiri, bebas hak cipta).
Palet konsisten bernuansa kota kecil Indonesia: hangat di siang, sedikit melankolis di malam.
"""
import math
import random

from PIL import Image

# ---------- Palet global ----------
P = {
    "outline": (43, 31, 36, 255),        # outline hangat gelap
    "outline_soft": (58, 42, 47, 255),
    "skin": [(242, 201, 160, 255), (217, 160, 107, 255), (190, 132, 86, 255), (150, 100, 66, 255)],
    "skin_sh": [(219, 172, 133, 255), (190, 132, 88, 255), (161, 107, 70, 255), (124, 81, 54, 255)],
    "grass": (110, 148, 72, 255),
    "grass_d": (86, 122, 54, 255),
    "grass_l": (134, 172, 88, 255),
    "dirt": (176, 148, 104, 255),
    "dirt_d": (146, 120, 82, 255),
    "road": (74, 74, 84, 255),
    "road_d": (62, 62, 71, 255),
    "road_l": (88, 88, 98, 255),
    "mark": (232, 216, 120, 255),
    "side": (198, 191, 174, 255),
    "side_d": (168, 159, 143, 255),
    "side_l": (216, 210, 194, 255),
    "water": (78, 157, 176, 255),
    "water_d": (61, 132, 150, 255),
    "water_l": (205, 238, 242, 255),
    "roof": (181, 84, 59, 255),
    "roof_d": (143, 63, 46, 255),
    "roof_l": (209, 110, 78, 255),
    "wall_cream": (240, 227, 200, 255),
    "wall_green": (184, 216, 176, 255),
    "wall_blue": (184, 208, 232, 255),
    "wall_pink": (236, 208, 208, 255),
    "wall_sh": [(214, 199, 170, 255), (156, 186, 148, 255), (154, 176, 196, 255), (200, 176, 176, 255)],
    "wood": (156, 107, 63, 255),
    "wood_d": (122, 79, 46, 255),
    "wood_l": (190, 140, 88, 255),
    "white": (245, 242, 235, 255),
    "black": (38, 32, 36, 255),
    "leaf": (74, 122, 60, 255),
    "leaf_d": (56, 96, 46, 255),
    "leaf_l": (98, 148, 72, 255),
    "metal": (150, 155, 165, 255),
    "metal_d": (110, 114, 124, 255),
    "glass": (170, 220, 230, 255),
    "glass_d": (130, 190, 205, 255),
    "red": (214, 80, 70, 255),
    "red_d": (170, 58, 52, 255),
    "cyan": (79, 216, 224, 255),
    "violet": (160, 107, 224, 255),
    "orange": (240, 160, 90, 255),
    "yellow": (240, 208, 96, 255),
    "shadow": (30, 40, 30, 70),
}


def hexc(h):
    h = h.lstrip("#")
    return (int(h[0:2], 16), int(h[2:4], 16), int(h[4:6], 16), 255)


def shade(c, f):
    """Kalikan brightness warna (f<1 gelap, f>1 terang)."""
    return tuple(max(0, min(255, int(v * f))) for v in c[:3]) + (c[3],)


class C:
    """Kanvas pixel kecil dengan utilitas gambar."""

    def __init__(self, w, h, bg=(0, 0, 0, 0)):
        self.w, self.h = w, h
        self.img = Image.new("RGBA", (w, h), bg)
        self.p = self.img.load()

    def set(self, x, y, c):
        x, y = int(x), int(y)
        if 0 <= x < self.w and 0 <= y < self.h:
            self.p[x, y] = c

    def get(self, x, y):
        return self.p[x, y]

    def rect(self, x, y, w, h, c):
        for yy in range(int(y), int(y + h)):
            for xx in range(int(x), int(x + w)):
                self.set(xx, yy, c)

    def hline(self, x, y, w, c):
        self.rect(x, y, w, 1, c)

    def vline(self, x, y, h, c):
        self.rect(x, y, 1, h, c)

    def ellipse(self, cx, cy, rx, ry, c):
        for yy in range(int(cy - ry), int(cy + ry) + 1):
            for xx in range(int(cx - rx), int(cx + rx) + 1):
                dx = (xx - cx) / max(rx, 0.001)
                dy = (yy - cy) / max(ry, 0.001)
                if dx * dx + dy * dy <= 1.0:
                    self.set(xx, yy, c)

    def noise(self, x, y, w, h, colors, density, rng):
        """Taburan pixel variasi material."""
        for _ in range(int(w * h * density)):
            xx = int(rng.uniform(x, x + w))
            yy = int(rng.uniform(y, y + h))
            self.set(xx, yy, rng.choice(colors))

    def dither(self, x, y, w, h, c, rng, density=0.25):
        for _ in range(int(w * h * density)):
            xx = int(rng.uniform(x, x + w))
            yy = int(rng.uniform(y, y + h))
            self.set(xx, yy, c)

    def outline(self, color=None, soft=False):
        """Outline 4-arah di sekeliling pixel non-transparan (di dalam kanvas)."""
        col = color or (P["outline_soft"] if soft else P["outline"])
        marks = []
        for y in range(self.h):
            for x in range(self.w):
                if self.get(x, y)[3] > 0:
                    continue
                for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)):
                    nx, ny = x + dx, y + dy
                    if 0 <= nx < self.w and 0 <= ny < self.h and self.get(nx, ny)[3] > 0:
                        marks.append((x, y))
                        break
        for x, y in marks:
            self.set(x, y, col)

    def to_image(self):
        return self.img


def save(img, path):
    img.save(path)
    print(f"  ✓ {path.split('/')[-1]}  ({img.size[0]}x{img.size[1]})")


def blob(canvas, cx, cy, r, c, rng, squash=0.75):
    """Gumpalan organik (kanopi pohon, semak) dengan tepi bergerigi halus."""
    for yy in range(int(cy - r), int(cy + r) + 1):
        for xx in range(int(cx - r), int(cx + r) + 1):
            dx = (xx - cx) / r
            dy = (yy - cy) / (r * squash)
            d = dx * dx + dy * dy
            if d <= 1.0 - rng.uniform(0, 0.18):
                canvas.set(xx, yy, c)


def shadow_ellipse(canvas, cx, cy, rx, ry):
    canvas.ellipse(cx, cy, rx, ry, P["shadow"])
