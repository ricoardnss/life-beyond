# -*- coding: utf-8 -*-
"""gen_fixtures.py — Fixture interior: shower, kasir/counter, papan menu, rak, kulkas."""
import random

from pixel import C, P, save, shade

OUT = "/home/z/my-project/public/game/assets"


def p_shower():
    c = C(40, 56)
    # lantai kamar mandi
    c.rect(2, 40, 36, 14, (208, 214, 220, 255))
    c.hline(2, 40, 36, (170, 176, 186, 255))
    # dindaian
    for i in range(3):
        c.rect(6 + i * 12, 44, 8, 1, (180, 186, 196, 255))
    # tiang + kepala shower
    c.rect(4, 6, 3, 36, P["metal_d"])
    c.rect(4, 6, 1, 36, shade(P["metal_d"], 1.3))
    c.rect(4, 6, 16, 3, P["metal_d"])
    c.rect(18, 8, 6, 3, (150, 156, 166, 255))
    c.rect(19, 11, 4, 2, (190, 216, 230, 255))
    # tetes air
    for x, y in ((19, 15), (21, 18), (20, 22), (22, 25)):
        c.vline(x, y, 2, (200, 228, 240, 180))
    # tirai
    for i in range(0, 14, 3):
        c.rect(24 + i, 14, 2, 30, (150, 190, 210, 255) if (i // 3) % 2 == 0 else (130, 170, 192, 255))
    c.rect(24, 14, 14, 2, (110, 146, 168, 255))
    # genangan
    c.ellipse(22, 50, 9, 2.4, (190, 216, 230, 120))
    c.outline(soft=True)
    return c


def p_counter():
    c = C(32, 30)
    c.rect(0, 4, 32, 10, P["wood"])       # top
    c.rect(0, 4, 32, 3, P["wood_l"])
    c.rect(0, 13, 32, 2, P["wood_d"])
    c.rect(2, 15, 28, 13, shade(P["wood"], 0.9))  # badan
    c.rect(4, 17, 10, 9, shade(P["wood"], 1.05))  # pintu kabinet
    c.rect(18, 17, 10, 9, shade(P["wood"], 1.05))
    c.set(9, 21, P["yellow"])
    c.set(23, 21, P["yellow"])
    c.rect(6, 0, 20, 5, (0, 0, 0, 0))  # ruang objek di atas
    c.outline(soft=True)
    return c


def p_menu():
    c = C(48, 26)
    c.rect(1, 1, 46, 24, (70, 52, 48, 255))
    c.rect(3, 3, 42, 20, (244, 236, 216, 255))
    # garis menu
    for i, y in enumerate((6, 11, 16)):
        c.rect(6, y, 22, 2, (90, 84, 80, 255))
        c.rect(32, y, 8, 2, (90, 84, 80, 255) if i != 1 else P["red"])
    # ikon cangkir
    c.rect(36, 8, 6, 4, P["white"])
    c.set(42, 9, P["white"])
    c.outline(soft=True)
    return c


def p_shelf():
    c = C(32, 42)
    c.rect(1, 2, 30, 38, (130, 96, 66, 255))
    c.rect(2, 3, 28, 36, (160, 122, 84, 255))
    # rak + barang
    for row in range(3):
        y = 6 + row * 12
        c.hline(3, y + 8, 26, (110, 80, 54, 255))
        for i in range(4):
            col = [(240, 160, 80, 255), (120, 180, 140, 255), (220, 90, 80, 255), (240, 210, 120, 255)][(row + i) % 4]
            c.rect(5 + i * 6, y + 2, 5, 6, col)
            c.rect(5 + i * 6, y + 2, 5, 2, shade(col, 1.2))
    c.outline()
    return c


def p_fridge():
    c = C(32, 52)
    c.rect(2, 2, 28, 48, (226, 230, 238, 255))
    c.rect(3, 3, 26, 20, (238, 242, 248, 255))
    c.rect(3, 25, 26, 24, (238, 242, 248, 255))
    # pintu kaca
    c.rect(6, 6, 20, 14, P["glass"])
    c.rect(6, 6, 20, 3, shade(P["glass"], 1.2))
    # isi botol
    for i, col in enumerate([P["cyan"], P["orange"], P["red"], P["yellow"], P["violet"]]):
        c.rect(8 + i * 4, 10, 3, 8, col)
        c.rect(8 + i * 4, 9, 3, 2, (240, 240, 240, 255))
    c.hline(2, 23, 28, (170, 176, 188, 255))
    # pegangan
    c.rect(26, 8, 2, 14, (150, 156, 166, 255))
    c.rect(26, 28, 2, 14, (150, 156, 166, 255))
    c.outline()
    return c


if __name__ == "__main__":
    for name, fn in {"p_shower.png": p_shower, "p_counter.png": p_counter, "p_menu.png": p_menu, "p_shelf.png": p_shelf, "p_fridge.png": p_fridge}.items():
        save(fn().img, f"{OUT}/{name}")
