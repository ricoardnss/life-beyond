# -*- coding: utf-8 -*-
"""gen_props.py — Bangunan, props jalan, furnitur interior, gerobak, air mancur."""
import random

from pixel import C, P, blob, save, shade

OUT = "/home/z/my-project/public/game/assets"


def shingle_rows(c, x, y, w, h, base):
    """Permukaan genteng: baris gelap tiap 4px + highlight."""
    for yy in range(h):
        c.hline(x, y + yy, w, base if (yy // 4) % 2 == 0 else shade(base, 0.88))
        if yy % 4 == 3:
            c.hline(x, y + yy, w, shade(base, 0.72))
    c.noise(x, y, w, h, [shade(base, 1.12)], 0.03, random.Random(3))


def hip_roof(c, x, y, w, h, col):
    """Atap limas sederhana: trapesium turun dengan garis genteng."""
    ridge = max(4, w - h)
    for i in range(h):
        t = i / max(1, h - 1)
        half_l = (w - ridge) / 2 * t
        rw = ridge + 2 * half_l
        c.rect(int(x + (w - rw) / 2), y + i, int(rw), 1, col if i % 5 < 3 else shade(col, 0.9))
    c.hline(int(x + (w - ridge) / 2), y, ridge, shade(col, 1.15))
    c.hline(x, y + h - 1, w, shade(col, 0.62))


def sign_board(c, x, y, w, h, bg, icon=None):
    c.rect(x, y, w, h, (60, 48, 52, 255))
    c.rect(x + 1, y + 1, w - 2, h - 2, bg)
    if icon == "cup":  # cangkir
        c.rect(x + w // 2 - 4, y + h // 2 - 3, 8, 5, P["white"])
        c.rect(x + w // 2 + 4, y + h // 2 - 2, 2, 3, P["white"])
        c.rect(x + w // 2 - 3, y + h // 2 + 2, 6, 1, shade(bg, 0.6))
        for dx in (2, 5):
            c.set(x + w // 2 - 4 + dx, y + h // 2 - 5, (220, 220, 220, 200))
    elif icon == "wrench":
        c.vline(x + w // 2, y + h // 2 - 4, 8, (70, 74, 84, 255))
        c.ellipse(x + w // 2, y + h // 2 - 4, 3, 3, (70, 74, 84, 255))
        c.ellipse(x + w // 2, y + h // 2 - 4, 1.4, 1.4, bg)
    elif icon == "cart":
        c.rect(x + w // 2 - 5, y + h // 2 - 3, 10, 5, P["white"])
        c.set(x + w // 2 - 3, y + h // 2 + 3, P["white"])
        c.set(x + w // 2 + 3, y + h // 2 + 3, P["white"])
    elif icon == "leaf":
        c.ellipse(x + w // 2, y + h // 2, 4, 3, (98, 148, 72, 255))
        c.vline(x + w // 2, y + h // 2 - 4, 8, (74, 122, 60, 255))


def door(c, x, y, w, h, col=(96, 66, 44, 255)):
    c.rect(x, y, w, h, shade(col, 0.7))
    c.rect(x + 1, y + 1, w - 2, h - 1, col)
    c.hline(x + 1, y + 1, w - 2, shade(col, 1.2))
    c.set(x + w - 3, y + h // 2, P["yellow"])  # pegangan


def window(c, x, y, w, h, lit=False, frame=(96, 66, 44, 255)):
    c.rect(x - 1, y - 1, w + 2, h + 2, frame)
    c.rect(x, y, w, h, (250, 226, 150, 255) if lit else P["glass"])
    c.rect(x, y, w, h // 2, (255, 240, 180, 255) if lit else shade(P["glass"], 1.15))
    c.vline(x + w // 2, y, h, frame)
    c.hline(x, y + h // 2, w, frame)
    if not lit:
        c.rect(x + 1, y + 1, w // 2 - 1, h // 2 - 1, shade(P["glass"], 1.3))


# ---------- Bangunan ----------
def building_warung():
    W, H = 128, 96
    c = C(W, H)
    wall = P["wall_cream"]
    # badan
    c.rect(2, 36, W - 4, H - 40, wall)
    c.rect(2, 36, W - 4, 3, shade(wall, 0.85))
    c.vline(W - 5, 39, H - 43, P["wall_sh"][0])
    # atap
    hip_roof(c, 0, 8, W, 30, P["roof"])
    # awning bergaris
    for i in range(0, W - 8, 16):
        col = P["red"] if (i // 16) % 2 == 0 else P["white"]
        c.rect(4 + i, 40, 16, 12, col)
        c.rect(4 + i, 40, 16, 2, shade(col, 1.2))
        c.rect(4 + i, 50, 16, 2, shade(col, 0.8))
    c.hline(4, 52, W - 8, P["outline_soft"])
    # papan nama di atas awning
    c.rect(20, 26, 60, 12, (70, 52, 48, 255))
    c.rect(21, 27, 58, 10, (244, 236, 216, 255))
    sign_board(c, 68, 24, 18, 14, (244, 236, 216, 255), icon="cup")
    # jendela etalase + pintu
    window(c, 12, 60, 34, 22, lit=True)
    window(c, 54, 60, 26, 22, lit=True)
    door(c, 88, 58, 20, 34, (110, 76, 50, 255))
    # kursi plastik merah di depan (bagian sprite)
    for px in (10, 100):
        c.rect(px, H - 10, 8, 8, P["red"])
        c.rect(px, H - 2, 8, 2, P["red_d"])
    c.outline()
    return c


def building_minimarket():
    W, H = 128, 96
    c = C(W, H)
    wall = (214, 218, 224, 255)
    c.rect(2, 30, W - 4, H - 34, wall)
    c.vline(W - 5, 33, H - 37, (180, 184, 192, 255))
    hip_roof(c, 0, 6, W, 26, (110, 118, 132, 255))
    # papan brand
    c.rect(6, 20, 116, 18, (46, 50, 60, 255))
    c.rect(8, 22, 112, 14, (240, 90, 70, 255))
    sign_board(c, 12, 21, 16, 16, (240, 90, 70, 255), icon="cart")
    for i in range(3):
        c.rect(38 + i * 26, 26, 20, 6, P["white"])  # strip teks stilasi
    # pintu kaca + etalase
    c.rect(10, 46, 108, 6, (120, 126, 138, 255))
    window(c, 14, 54, 30, 30, lit=True, frame=(120, 126, 138, 255))
    door(c, 52, 52, 24, 40, (150, 200, 214, 255))
    c.vline(63, 53, 38, (120, 126, 138, 255))
    window(c, 84, 54, 30, 30, lit=True, frame=(120, 126, 138, 255))
    # kulkas minuman terlihat di etalase kanan
    c.rect(90, 62, 18, 16, (230, 234, 240, 255))
    c.rect(92, 64, 6, 5, P["cyan"])
    c.rect(100, 64, 6, 5, P["orange"])
    c.outline()
    return c


def building_bengkel():
    W, H = 128, 88
    c = C(W, H)
    c.rect(2, 30, W - 4, H - 34, (196, 188, 172, 255))
    hip_roof(c, 0, 6, W, 26, (122, 118, 128, 255))
    c.rect(8, 18, 80, 16, (58, 56, 60, 255))
    c.rect(9, 19, 78, 14, (222, 148, 60, 255))
    sign_board(c, 14, 18, 16, 16, (222, 148, 60, 255), icon="wrench")
    for i in range(2):
        c.rect(38 + i * 24, 22, 18, 6, (58, 56, 60, 255))
    # pintu rol
    for yy in range(50, H - 4, 5):
        c.rect(14, yy, 72, 4, (150, 150, 158, 255) if (yy // 5) % 2 == 0 else (132, 132, 140, 255))
    c.rect(14, 50, 72, H - 54, (0, 0, 0, 0))
    for yy in range(50, H - 4, 5):
        c.rect(14, yy, 72, 3, (150, 150, 158, 255))
    c.rect(14, 50, 72, 2, (110, 110, 118, 255))
    c.rect(14, H - 6, 72, 2, (110, 110, 118, 255))
    # jendela kecil + ban bertumpuk
    window(c, 96, 50, 20, 16, frame=(96, 66, 44, 255))
    for i, ty in enumerate((H - 10, H - 16)):
        c.ellipse(8, ty, 8, 4, (40, 40, 44, 255))
        c.ellipse(8, ty, 3, 1.5, (90, 90, 96, 255))
    c.outline()
    return c


def building_kafe():
    W, H = 112, 96
    c = C(W, H)
    wall = (232, 214, 196, 255)
    c.rect(2, 34, W - 4, H - 38, wall)
    c.vline(W - 5, 37, H - 41, (204, 184, 166, 255))
    hip_roof(c, 0, 10, W, 26, (98, 108, 88, 255))
    c.rect(18, 22, 56, 14, (52, 48, 52, 255))
    c.rect(19, 23, 54, 12, (246, 238, 220, 255))
    sign_board(c, 62, 20, 18, 16, (246, 238, 220, 255), icon="cup")
    # awning hijau tua
    c.rect(4, 38, W - 8, 10, (70, 92, 72, 255))
    c.rect(4, 46, W - 8, 2, (54, 72, 56, 255))
    # jendela hangat + pintu
    window(c, 12, 56, 28, 24, lit=True, frame=(110, 80, 56, 255))
    door(c, 48, 54, 18, 38, (110, 80, 56, 255))
    window(c, 74, 56, 26, 24, lit=True, frame=(110, 80, 56, 255))
    # tanaman pot
    for px in (6, 92):
        c.rect(px, H - 14, 10, 8, (172, 120, 80, 255))
        blob(c, px + 5, H - 20, 6, P["leaf"], random.Random(px), squash=0.9)
        c.set(px + 3, H - 24, P["leaf_l"])
    c.outline()
    return c


def building_kos():
    W, H = 160, 128
    c = C(W, H)
    wall = P["wall_blue"]
    # lantai 2
    c.rect(2, 34, W - 4, 44, wall)
    hip_roof(c, 0, 8, W, 28, P["roof_d"])
    # lantai 1
    c.rect(2, 78, W - 4, H - 82, shade(wall, 0.94))
    c.hline(2, 76, W - 4, (200, 176, 196, 255))
    c.hline(2, 78, W - 4, P["outline_soft"])
    # jendela lantai 2
    for wx in (16, 52, 88, 124):
        window(c, wx, 44, 20, 18, lit=True, frame=(80, 92, 116, 255))
    # papan nama kos
    c.rect(58, 82, 44, 12, (94, 70, 52, 255))
    c.rect(59, 83, 42, 10, (238, 228, 206, 255))
    # pintu kamar lantai 1 + tangga samping
    door(c, 20, 88, 18, 36, (96, 66, 44, 255))
    door(c, 46, 88, 18, 36, (96, 66, 44, 255))
    # tangga luar ke lantai 2 (kanan)
    for i in range(6):
        c.rect(118 + (5 - i) * 3, 82 + i * 7, 24, 7, shade(P["metal"], 0.9 + i * 0.02))
    c.rect(140, 60, 4, 20, (110, 116, 126, 255))
    # jendela lantai 1
    window(c, 76, 90, 20, 16, frame=(80, 92, 116, 255))
    c.outline()
    return c


def building_house(wall, roof, seed):
    W, H = 96, 84
    rng = random.Random(seed)
    c = C(W, H)
    c.rect(2, 34, W - 4, H - 38, wall)
    c.vline(W - 5, 37, H - 41, shade(wall, 0.88))
    hip_roof(c, 0, 8, W, 28, roof)
    window(c, 12, 48, 20, 18, lit=rng.random() < 0.5, frame=(120, 88, 62, 255))
    door(c, 42, 44, 18, 36)
    window(c, 66, 48, 20, 18, lit=rng.random() < 0.5, frame=(120, 88, 62, 255))
    c.outline()
    return c


def building_house_small(wall, roof, seed):
    """Rumah mungil (64x64) untuk gang perumahan — variasi baru."""
    W, H = 64, 64
    rng = random.Random(seed)
    c = C(W, H)
    c.rect(2, 26, W - 4, H - 30, wall)
    c.vline(W - 5, 29, H - 33, shade(wall, 0.88))
    hip_roof(c, 0, 4, W, 24, roof)
    door(c, 26, 30, 16, 30)
    window(c, 6, 34, 14, 14, lit=rng.random() < 0.5, frame=(120, 88, 62, 255))
    window(c, 46, 34, 14, 14, lit=rng.random() < 0.6, frame=(120, 88, 62, 255))
    c.outline()
    return c


def building_gazebo():
    W, H = 96, 76
    c = C(W, H)
    # pilar
    for px in (6, 40, 74):
        c.rect(px, 24, 10, H - 30, (196, 148, 96, 255))
        c.vline(px, 24, H - 30, (220, 176, 120, 255))
    # atap runcing
    for i in range(26):
        wdt = 10 + i * 3
        c.rect((W - wdt) // 2, 0 + i, wdt, 1, P["roof_d"] if i % 4 < 2 else shade(P["roof_d"], 0.9))
    # lantai
    c.rect(2, H - 12, W - 4, 10, (176, 136, 92, 255))
    c.hline(2, H - 12, W - 4, (150, 112, 74, 255))
    # bangku duduk melingkar
    c.rect(6, H - 24, 14, 6, P["wood"])
    c.rect(76, H - 24, 14, 6, P["wood"])
    c.outline()
    return c


# ---------- Props ----------
def prop_tree(seed, wide=True):
    W, H = (44, 60) if wide else (36, 64)
    rng = random.Random(seed)
    c = C(W, H)
    cx = W // 2
    c.rect(cx - 3, H - 22, 6, 20, P["wood_d"])
    c.rect(cx - 3, H - 22, 2, 20, shade(P["wood_d"], 1.25))
    c.rect(cx - 6, H - 16, 3, 6, P["wood_d"])  # akar
    c.rect(cx + 4, H - 14, 3, 5, P["wood_d"])
    blob(c, cx, 20, 15 if wide else 11, P["leaf"], rng)
    blob(c, cx - 8, 26, 8, P["leaf_d"], rng)
    blob(c, cx + 9, 16, 7, shade(P["leaf"], 1.12), rng)
    c.noise(4, 6, W - 8, 30, [P["leaf_l"]], 0.05, rng)
    c.outline(soft=True)
    return c


def prop_bush(seed):
    rng = random.Random(seed)
    c = C(26, 18)
    blob(c, 9, 10, 7, P["leaf_d"], rng)
    blob(c, 17, 9, 7, P["leaf"], rng)
    blob(c, 13, 6, 5, P["leaf_l"], rng)
    c.outline(soft=True)
    return c


def prop_lamp():
    c = C(16, 52)
    c.rect(7, 10, 2, 40, P["metal_d"])
    c.rect(5, 48, 6, 3, P["metal_d"])
    c.rect(4, 6, 8, 5, (70, 72, 80, 255))
    c.rect(5, 2, 6, 5, (250, 236, 160, 255))
    c.rect(6, 0, 4, 2, (70, 72, 80, 255))
    c.outline(soft=True)
    return c


def prop_bench():
    c = C(34, 20)
    c.rect(2, 4, 30, 6, P["wood"])   # sandaran
    c.rect(2, 12, 30, 5, P["wood"])  # dudukan
    for lx in (4, 26):
        c.rect(lx, 17, 3, 3, P["wood_d"])
        c.vline(lx + 1, 10, 8, P["wood_d"])
    c.hline(2, 4, 30, shade(P["wood"], 1.2))
    c.hline(2, 12, 30, shade(P["wood"], 1.2))
    c.outline(soft=True)
    return c


def prop_trash(seed):
    rng = random.Random(seed)
    c = C(16, 22)
    c.rect(3, 4, 10, 16, (86, 100, 92, 255))
    c.rect(4, 5, 8, 14, (110, 126, 114, 255))
    c.rect(2, 2, 12, 3, (70, 82, 76, 255))
    c.noise(4, 6, 8, 11, [(90, 104, 94, 255)], 0.1, rng)
    c.set(7, 0, (110, 126, 114, 255))
    c.set(8, 1, (90, 104, 94, 255))
    c.outline()
    return c


def prop_chair_plastic(col):
    c = C(14, 20)
    c.rect(2, 0, 10, 8, col)     # sandaran
    c.rect(3, 8, 8, 2, shade(col, 0.8))
    c.rect(1, 10, 12, 3, col)    # dudukan
    c.rect(2, 13, 2, 6, shade(col, 0.85))
    c.rect(10, 13, 2, 6, shade(col, 0.85))
    c.outline(soft=True)
    return c


def prop_table_plastic():
    c = C(26, 18)
    c.rect(0, 2, 26, 5, (240, 238, 232, 255))
    c.rect(0, 2, 26, 2, P["white"])
    c.rect(11, 7, 4, 8, (210, 208, 202, 255))
    c.rect(8, 14, 10, 3, (200, 198, 192, 255))
    c.outline(soft=True)
    return c


def prop_motor():
    c = C(38, 26)
    c.ellipse(9, 18, 7, 7, (40, 40, 46, 255))
    c.ellipse(9, 18, 3, 3, (110, 110, 118, 255))
    c.ellipse(29, 18, 7, 7, (40, 40, 46, 255))
    c.ellipse(29, 18, 3, 3, (110, 110, 118, 255))
    c.rect(8, 8, 20, 7, (60, 90, 150, 255))
    c.rect(10, 6, 10, 4, (80, 110, 170, 255))
    c.rect(16, 4, 8, 5, (50, 52, 58, 255))  # jok
    c.rect(6, 6, 4, 4, (120, 124, 132, 255))  # setang
    c.rect(28, 7, 5, 4, (120, 124, 132, 255))
    c.outline()
    return c


def prop_fountain():
    c = C(84, 52)
    c.ellipse(42, 34, 40, 15, (170, 164, 152, 255))
    c.ellipse(42, 32, 36, 12, P["water"])
    c.ellipse(42, 32, 36, 12, P["water"])
    c.ellipse(42, 31, 34, 10, shade(P["water"], 1.08))
    c.rect(38, 12, 8, 20, (190, 184, 172, 255))
    c.ellipse(42, 12, 10, 4, (190, 184, 172, 255))
    c.ellipse(42, 10, 7, 3, shade(P["water"], 1.2))
    for dx, dy in ((-10, 2), (10, 2), (-6, 6), (6, 6), (0, 7)):
        c.rect(41 + dx, 14 + dy, 2, 3, P["water_l"])
    c.outline(soft=True)
    return c


def prop_gerobak():
    c = C(52, 42)
    # kanopi
    for i in range(0, 52, 13):
        c.rect(2 + i, 2, 13, 10, P["red"] if (i // 13) % 2 == 0 else P["white"])
        c.rect(2 + i, 2, 13, 2, shade(P["white"], 1.0))
    c.rect(2, 10, 48, 2, (60, 52, 52, 255))
    c.rect(4, 12, 2, 14, P["wood_d"])
    c.rect(46, 12, 2, 14, P["wood_d"])
    # kotak kayu
    c.rect(6, 18, 40, 16, P["wood"])
    c.rect(6, 18, 40, 3, P["wood_l"])
    c.vline(16, 21, 13, P["wood_d"])
    c.vline(26, 21, 13, P["wood_d"])
    c.vline(36, 21, 13, P["wood_d"])
    # kaca toples di atas
    c.rect(12, 12, 8, 7, P["glass"])
    c.rect(30, 12, 8, 7, P["glass"])
    # roda
    c.ellipse(14, 38, 5, 5, (52, 46, 46, 255))
    c.ellipse(14, 38, 2, 2, (120, 110, 110, 255))
    c.ellipse(38, 38, 5, 5, (52, 46, 46, 255))
    c.ellipse(38, 38, 2, 2, (120, 110, 110, 255))
    c.outline()
    return c


def prop_crate():
    c = C(22, 18)
    c.rect(1, 3, 20, 14, P["wood"])
    c.rect(1, 3, 20, 3, P["wood_l"])
    c.vline(1, 3, 14, P["wood_d"])
    c.vline(20, 3, 14, P["wood_d"])
    c.hline(1, 9, 20, P["wood_d"])
    c.outline(soft=True)
    return c


def prop_sign():
    c = C(18, 30)
    c.rect(8, 8, 2, 22, P["metal_d"])
    c.rect(2, 2, 14, 12, (60, 62, 70, 255))
    c.rect(3, 3, 12, 10, (230, 190, 80, 255))
    c.rect(6, 6, 6, 2, (60, 62, 70, 255))
    c.rect(8, 8, 2, 3, (60, 62, 70, 255))
    c.outline(soft=True)
    return c


def prop_fence():
    c = C(32, 18)
    for px in range(0, 32, 8):
        c.rect(px + 1, 2, 4, 14, P["wood"])
        c.rect(px + 1, 2, 1, 14, shade(P["wood"], 1.2))
        c.set(px + 4, 15, P["wood_d"])
    c.hline(0, 5, 32, P["wood_d"])
    c.hline(0, 11, 32, P["wood_d"])
    c.outline(soft=True)
    return c


# ---------- Furnitur ----------
def furn_bed():
    c = C(42, 58)
    c.rect(2, 0, 38, 56, P["wood_d"])       # rangka
    c.rect(4, 2, 34, 52, (238, 234, 226, 255))  # kasur
    c.rect(4, 2, 34, 8, P["white"])          # bantal
    c.rect(4, 2, 34, 2, (255, 255, 252, 255))
    c.rect(4, 14, 34, 22, (150, 178, 220, 255))  # selimut
    c.hline(4, 20, 34, shade((150, 178, 220, 255), 1.15))
    c.hline(4, 28, 34, shade((150, 178, 220, 255), 0.9))
    c.rect(4, 44, 34, 10, (238, 234, 226, 255))
    c.rect(0, 0, 42, 3, P["wood"])           # kepala ranjang
    c.rect(0, 54, 42, 4, P["wood"])
    c.outline()
    return c


def furn_wardrobe():
    c = C(30, 46)
    c.rect(1, 0, 28, 46, P["wood"])
    c.rect(1, 0, 28, 3, P["wood_l"])
    c.vline(14, 3, 42, P["wood_d"])
    c.rect(3, 3, 11, 40, shade(P["wood"], 1.08))
    c.rect(16, 3, 11, 40, shade(P["wood"], 1.08))
    c.set(12, 22, P["yellow"])
    c.set(17, 22, P["yellow"])
    c.outline()
    return c


def furn_desk():
    c = C(42, 26)
    c.rect(0, 6, 42, 6, P["wood"])
    c.rect(0, 6, 42, 2, P["wood_l"])
    c.rect(2, 12, 5, 14, P["wood_d"])
    c.rect(35, 12, 5, 14, P["wood_d"])
    c.rect(7, 12, 12, 10, shade(P["wood"], 0.9))  # laci
    c.set(12, 16, P["yellow"])
    c.outline(soft=True)
    return c


def furn_pc():
    c = C(24, 22)
    c.rect(2, 2, 20, 14, (52, 52, 58, 255))
    c.rect(4, 4, 16, 10, (90, 200, 230, 255))
    c.rect(4, 4, 16, 4, (130, 220, 240, 255))
    c.rect(8, 16, 8, 3, (70, 70, 78, 255))
    c.rect(6, 19, 12, 2, (52, 52, 58, 255))
    c.rect(18, 17, 5, 4, (140, 140, 148, 255))  # keyboard kecil
    c.outline(soft=True)
    return c


def furn_chair():
    c = C(16, 22)
    c.rect(3, 0, 10, 9, P["wood"])
    c.rect(3, 0, 10, 2, P["wood_l"])
    c.rect(2, 9, 12, 4, P["wood"])
    c.rect(3, 13, 2, 9, P["wood_d"])
    c.rect(11, 13, 2, 9, P["wood_d"])
    c.outline(soft=True)
    return c


def furn_fan():
    c = C(20, 24)
    c.ellipse(10, 8, 8, 8, (150, 156, 166, 255))
    c.ellipse(10, 8, 6, 6, (190, 196, 204, 255))
    for a in range(0, 360, 90):
        import math

        x2 = 10 + 5 * math.cos(math.radians(a + 45))
        y2 = 8 + 5 * math.sin(math.radians(a + 45))
        c.ellipse(x2, y2, 1.6, 1.6, (120, 126, 136, 255))
    c.ellipse(10, 8, 2, 2, (70, 74, 82, 255))
    c.rect(9, 16, 2, 5, (120, 126, 136, 255))
    c.ellipse(10, 22, 5, 2, (100, 106, 116, 255))
    c.outline(soft=True)
    return c


def furn_rug():
    c = C(58, 38)
    c.ellipse(29, 19, 28, 17, (196, 100, 90, 255))
    c.ellipse(29, 19, 22, 12, (222, 130, 110, 255))
    c.ellipse(29, 19, 14, 7, (196, 100, 90, 255))
    c.ellipse(29, 19, 6, 3, (240, 200, 150, 255))
    c.outline(soft=True)
    return c


def furn_plant():
    c = C(20, 30)
    c.rect(5, 20, 10, 8, (172, 120, 80, 255))
    c.rect(5, 20, 10, 2, (190, 140, 96, 255))
    c.rect(9, 14, 2, 8, (74, 110, 58, 255))
    for dx, dy in ((-5, 6), (5, 5), (-3, 1), (4, 0)):
        c.ellipse(10 + dx, 12 + dy, 4, 2.4, P["leaf"])
    blob(c, 10, 10, 5, P["leaf_l"], random.Random(5))
    c.outline(soft=True)
    return c


def furn_lamp():
    c = C(16, 34)
    c.rect(7, 14, 2, 16, P["metal_d"])
    c.ellipse(8, 32, 5, 2, P["metal_d"])
    c.rect(4, 4, 8, 10, (240, 210, 130, 255))
    c.rect(3, 2, 10, 3, (220, 180, 100, 255))
    c.outline(soft=True)
    return c


def furn_neon():
    c = C(44, 24)
    c.rect(2, 4, 40, 16, (30, 32, 40, 255))
    c.rect(4, 6, 36, 12, (22, 24, 30, 255))
    # teks neon stilasi (garis)
    for i, (x, y, w2, h2) in enumerate([(8, 8, 2, 8), (12, 8, 5, 2), (12, 12, 3, 2), (12, 16, 5, 2), (20, 8, 2, 8), (24, 8, 5, 2), (31, 8, 2, 8), (35, 8, 2, 5), (35, 14, 2, 2)]):
        c.rect(x, y, w2, h2, P["cyan"] if i % 2 == 0 else P["violet"])
    c.rect(2, 2, 40, 1, (60, 64, 76, 255))
    c.outline(soft=True)
    return c


def furn_minifan():
    c = C(16, 20)
    c.ellipse(8, 7, 6, 6, (240, 200, 120, 255))
    c.ellipse(8, 7, 4, 4, (250, 226, 170, 255))
    c.ellipse(8, 7, 1.4, 1.4, (140, 110, 70, 255))
    c.rect(7, 13, 2, 4, (180, 150, 100, 255))
    c.ellipse(8, 18, 4, 2, (160, 132, 88, 255))
    c.outline(soft=True)
    return c


def main():
    import os

    os.makedirs(OUT, exist_ok=True)

    buildings = {
        "b_warung.png": building_warung(),
        "b_minimarket.png": building_minimarket(),
        "b_bengkel.png": building_bengkel(),
        "b_kafe.png": building_kafe(),
        "b_kos.png": building_kos(),
        "b_house_a.png": building_house(P["wall_cream"], P["roof"], 31),
        "b_house_b.png": building_house(P["wall_green"], shade(P["roof"], 0.92), 32),
        "b_house_c.png": building_house(P["wall_pink"], shade(P["roof_d"], 1.05), 33),
        # 6 rumah warga baru (permintaan: rumah diperbanyak)
        "b_house_d.png": building_house((232, 214, 178, 255), (168, 106, 78, 255), 34),
        "b_house_e.png": building_house((176, 196, 178, 255), (120, 92, 88, 255), 35),
        "b_house_f.png": building_house((208, 178, 190, 255), (96, 108, 134, 255), 36),
        "b_house_g.png": building_house_small((226, 200, 150, 255), (150, 96, 70, 255), 37),
        "b_house_h.png": building_house_small((178, 188, 200, 255), (90, 100, 118, 255), 38),
        "b_house_i.png": building_house_small((198, 210, 178, 255), (110, 96, 78, 255), 39),
        "b_gazebo.png": building_gazebo(),
    }
    props = {
        "p_tree1.png": prop_tree(41, wide=True),
        "p_tree2.png": prop_tree(42, wide=False),
        "p_bush1.png": prop_bush(43),
        "p_bush2.png": prop_bush(44),
        "p_lamp.png": prop_lamp(),
        "p_bench.png": prop_bench(),
        "p_trash1.png": prop_trash(45),
        "p_trash2.png": prop_trash(46),
        "p_chair_red.png": prop_chair_plastic(P["red"]),
        "p_chair_blue.png": prop_chair_plastic((70, 120, 200, 255)),
        "p_table.png": prop_table_plastic(),
        "p_motor.png": prop_motor(),
        "p_fountain.png": prop_fountain(),
        "p_gerobak.png": prop_gerobak(),
        "p_crate.png": prop_crate(),
        "p_sign.png": prop_sign(),
        "p_fence.png": prop_fence(),
    }
    furn = {
        "f_bed.png": furn_bed(),
        "f_wardrobe.png": furn_wardrobe(),
        "f_desk.png": furn_desk(),
        "f_pc.png": furn_pc(),
        "f_chair.png": furn_chair(),
        "f_fan.png": furn_fan(),
        "f_rug.png": furn_rug(),
        "f_plant.png": furn_plant(),
        "f_lamp.png": furn_lamp(),
        "f_neon.png": furn_neon(),
        "f_minifan.png": furn_minifan(),
    }
    for name, img in {**buildings, **props, **furn}.items():
        save(img.img, f"{OUT}/{name}")
    print(f"Total: {len(buildings)} bangunan, {len(props)} props, {len(furn)} furnitur")


if __name__ == "__main__":
    main()
