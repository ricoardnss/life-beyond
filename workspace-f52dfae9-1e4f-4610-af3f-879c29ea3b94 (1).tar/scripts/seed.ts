// Seed database KOTA KITA: admin + katalog paket Gems awal.
// Jalankan: bun run scripts/seed.ts
// Catatan: harga Rupiah adalah HARGA AWAL yang dapat diubah admin via panel —
// belum harga final sebelum ditentukan pemilik proyek.
import { PrismaClient } from "@prisma/client";
import { hashPassword } from "../src/lib/password";

const db = new PrismaClient();

const PRODUCTS = [
  {
    id: "starter-gems",
    name: "Starter Gems",
    gems: 100,
    priceIdr: 15000,
    description: "Paket awal untuk mempercantik kamar kosmu: skin kecil, dekorasi ringan.",
    promoLabel: null as string | null,
    sortOrder: 1,
  },
  {
    id: "adventurer-gems",
    name: "Adventurer Gems",
    gems: 250,
    priceIdr: 35000,
    description: "Cukup untuk satu outfit premium atau beberapa dekorasi kamar.",
    promoLabel: "Populer",
    sortOrder: 2,
  },
  {
    id: "explorer-gems",
    name: "Explorer Gems",
    gems: 600,
    priceIdr: 75000,
    description: "Untuk penjelajah sosial: outfit, skin, dan dekorasi sekaligus.",
    promoLabel: null,
    sortOrder: 3,
  },
  {
    id: "city-builder-gems",
    name: "City Builder Gems",
    gems: 1200,
    priceIdr: 140000,
    description: "Paket besar untuk membentuk kamar kos impian di Kota Arunika.",
    promoLabel: "Hemat",
    sortOrder: 4,
  },
  {
    id: "arunika-elite",
    name: "Arunika Elite",
    gems: 2500,
    priceIdr: 275000,
    description: "Paket tertinggi: semua kosmetik premium dan sisa untuk masa depan.",
    promoLabel: "Best Value",
    sortOrder: 5,
  },
];

async function main() {
  const adminEmail = process.env.ADMIN_EMAIL || "admin@kotakita.dev";
  const adminPassword = process.env.ADMIN_PASSWORD || "kotakita-admin";
  const adminName = "Admin Arunika";

  const admin = await db.user.upsert({
    where: { email: adminEmail },
    update: { role: "admin" },
    create: {
      email: adminEmail,
      passwordHash: hashPassword(adminPassword),
      displayName: adminName,
      role: "admin",
    },
  });
  await db.premiumWallet.upsert({
    where: { userId: admin.id },
    update: {},
    create: { userId: admin.id, balance: 0 },
  });
  console.log(`Admin siap: ${adminEmail} (password via ADMIN_PASSWORD, default "kotakita-admin" — SEGERA GANTI)`);

  for (const p of PRODUCTS) {
    await db.product.upsert({
      where: { id: p.id },
      update: {
        name: p.name,
        gems: p.gems,
        priceIdr: p.priceIdr,
        description: p.description,
        promoLabel: p.promoLabel,
        sortOrder: p.sortOrder,
      },
      create: { ...p },
    });
  }
  console.log(`Katalog produk ter-seed: ${PRODUCTS.length} paket Gems.`);
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(() => db.$disconnect());
