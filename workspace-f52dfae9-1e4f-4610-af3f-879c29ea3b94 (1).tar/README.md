# KOTA KITA: Life Beyond

> *A little life. A thousand possibilities.*

Game simulasi kehidupan pixel-art top-down di **Kota Arunika** + **KOTA KITA STORE** (top-up Arunika Gems) — satu proyek web terintegrasi, dibangun dengan Next.js 16, TypeScript, Phaser 3, Prisma, dan Tailwind CSS.

---

## 1. Ikhtisar

| Komponen | Teknologi | Lokasi |
|---|---|---|
| Game (dunia, sistem, scene) | Phaser 3.90 + TypeScript | `src/game/` |
| UI Game (HUD, panel, minigame) | React 19 + Tailwind | `src/components/game/` |
| Situs + Store (SPA) | Next.js App Router (hash routing) | `src/components/store/` |
| Admin Panel | React + API terlindungi server | `src/components/admin/` |
| Backend API | Next.js Route Handlers | `src/app/api/` |
| Payment | Adapter: MockPay (DEVELOPMENT ONLY) + Midtrans Snap | `src/lib/payment/` |
| Database | Prisma + SQLite (runtime) / PostgreSQL+Supabase (produksi) | `prisma/schema.prisma` |
| Aset pixel-art & audio | Dibuat programatik (Python/PIL + synth) — 100% bebas hak cipta | `scripts/gen_*.py`, `public/game/` |

**Kenapa TypeScript di semua lapisan?** (permintaan: gunakan bila diperlukan)
1. Lingkungan deployment ini mewajibkan Next.js 16 + TypeScript.
2. Game, store, dan backend berbagi tipe (ID item, status order, saldo) — tipe mencegah bug mahal seperti ID salah ketik atau status order tidak valid.
3. Phaser 3 menyediakan tipe resmi yang mengurangi error runtime saat pengembangan.

**Kenapa satu route `/` dengan hash routing?** Lingkungan preview proyek hanya mengekspos route `/`; seluruh halaman (beranda, game, store, admin) adalah view SPA di atasnya. API tetap berupa Route Handler `/api/*`. Bonus: navigasi game ↔ store instan tanpa reload.

## 2. Menjalankan

```bash
# 1) Dependensi
bun install            # atau npm install

# 2) Database (SQLite lokal)
bun run db:push        # terapkan skema Prisma
bun run scripts/seed.ts  # admin + katalog paket Gems

# 3) Aset (sudah tersedia di public/game — regenerasi bila diubah)
python3 scripts/gen_characters.py && python3 scripts/gen_tiles.py \
  && python3 scripts/gen_props.py && python3 scripts/gen_fixtures.py \
  && python3 scripts/gen_icons.py && python3 scripts/gen_audio.py

# 4) Pengembangan
bun run dev            # http://localhost:3000

# 5) Kualitas
bun run lint           # ESLint
bunx tsc --noEmit      # tipe
bun test tests/        # 39 uji (logika game + keamanan API, server harus jalan)
```

**Akun admin bawaan** (SEGERA ganti passwordnya): `admin@kotakita.dev` / `kotakita-admin`

## 3. Peta Halaman (hash routes)

| Route | Isi |
|---|---|
| `#/` | Beranda resmi KOTA KITA |
| `#/play` | Game (menu utama → 3 slot save + sinkron server) |
| `#/store` | KOTA KITA STORE — katalog paket Gems |
| `#/store/product/:id` | Detail paket + beli |
| `#/store/gems` | Katalog kosmetik premium (belanja Gems) |
| `#/store/login`, `#/store/register`, `#/store/profile` | Akun |
| `#/store/transactions`, `#/store/transactions/:id` | Riwayat & status transaksi (polling otomatis) |
| `#/store/pay/:orderId` | Halaman "gateway" MockPay — **DEVELOPMENT ONLY** |
| `#/faq`, `#/store/help`, `#/store/terms`, `#/store/privacy` | Halaman informatif |
| `#/admin` | Panel admin (ringkasan, produk, order, ledger, audit, refund) |

## 4. Game — Fitur Utama

- **Dunia**: distrik Arunika Tengah (60×40 tile) — kos, 3 rumah warga, warung, minimarket, bengkel, kafe, taman dengan air mancur & kolam, gang, basis kurir. 5 interior dapat dimasuki dengan transisi fade.
- **Kontrol**: WASD/panah (8 arah, dinormalisasi), Shift lari (boros energi), E interaksi, I/J/M/P/Esc panel. Joystick virtual otomatis di layar sentuh.
- **Waktu**: 1 hari = 18 menit nyata. NPC punya jadwal per jam (pathfinding BFS, tidak menembus collision). Toko punya jam buka. Tidur memajukan ke 07.00.
- **Kebutuhan**: lapar/energi/kebersihan/mood — peluruhan per jam, efek bertahap (tidak ada game over permanen).
- **Ekonomi**: gaji shift, tip performa, sewa kos mingguan (Rp25.000, mulai hari ke-8), beli/jual barang, semua tercatat di ledger dompet.
- **Pekerjaan** (minigame interaktif): Pegawai Warung (sajikan pesanan), Kurir (antar paket ke marker), Pegawai Minimarket (hafalkan urutan rak). Skill 1–5 menaikkan upah.
- **Sosial**: 10 NPC dengan kepribadian, selera hadiah, dialog kontekstual (waktu/cuaca/kedekatan), 5 tahap relasi, batas interaksi harian anti-grinding.
- **Misi**: 5 tutorial berantai + 7 misi sampingan (termasuk Oyen si kucing hilang & malam minggu tiap hari ke-7). 14 achievement + statistik.
- **Kamar kos**: beli & tempatkan furnitur (validasi collision), ganti outfit di lemari, mandi di kamar mandi.
- **Ponsel**: pesan dari event nyata (misi, kerja, pengumuman), kontak & status relasi.
- **Cuaca & siang-malam**: cerah/berawan/hujan (partikel + suara), tint pagi→senja→malam, glow lampu jalan.
- **Save**: 3 slot lokal + sinkron ke akun (tersimpan otomatis saat tidur), tahan data korup & migrasi skema.

## 5. Keamanan Transaksi (Bagian F-5)

Semua prinsip wajib diimplementasikan dan **diuji otomatis** (`tests/api.test.ts`, 20 kasus):

1. **Harga ditentukan server** — client hanya mengirim `productId`; `gems` & `amountIdr` diambil dari tabel `products`. ✅ uji: manipulasi klien diabaikan.
2. **Order unik & terikat pemilik** — ID `KK-ORD-…`; akses detail hanya pemilik/admin. ✅ uji: user lain → 403.
3. **Webhook diverifikasi backend** — HMAC (MockPay) / SHA512 Midtrans. Signature salah → 403, tanpa perubahan saldo. ✅ uji.
4. **Idempotensi** — `payment_events.provider_event_id` unik + `premium_ledger(reason, refId)` unik; webhook duplikat tidak menggandakan Gems. ✅ uji.
5. **Kredit atomik** — `$transaction`: order→paid, wallet increment, ledger insert, order→fulfilled. Nominal mismatch → 400 tanpa kredit. ✅ uji.
6. **Saldo tidak negatif** — refund memotong `min(gems, saldo)` + catatan audit. Refund ganda → ditolak. ✅ uji.
7. **Rate limiting** — endpoint sensitif per-IP (bucket di `globalThis` agar lintas route).
8. **Audit log** — register/login/product_*/gems_spend/refund tercatat; dilihat admin.
9. **Admin terverifikasi server** — role dibaca dari DB di setiap endpoint admin; UI biasa → 403. ✅ uji.
10. **Rahasia tidak pernah ke klien** — ServerKey/SESSION_SECRET hanya env server; log webhook tanpa rahasia.
11. **RLS Supabase** — lihat `docs/supabase-migration.sql` (panduan produksi).

## 6. Struktur Proyek

```
kota-kita/
  src/
    app/                    # layout + halaman "/" + semua API routes
    components/
      game/                 # GamePage (menu) + GameUI (HUD & panel)
      store/                # Landing, StoreApp, StoreAccount, StaticPage, AuthContext
      admin/                # AdminApp (5 tab)
    game/
      core/                 # types, constants, bus, state, save
      data/                 # items, npcs, jobs, quests, dialogs, mapdata
      systems/              # time/needs/economy, inventory, social, quests,
      |                     # jobs, furniture, pathfind, achievements
      scenes/               # Boot, Base, World, Interior (Phaser)
      start.ts              # konfigurasi Phaser + pause/joystick API
    lib/                    # auth sesi, password scrypt, rate-limit, payment/*, gems-catalog
  public/game/              # aset PNG + WAV (generated) + manifest.json
  scripts/                  # generator aset (Python) + seed.ts
  tests/                    # api.test.ts (20) + game.test.ts (19)
  docs/                     # supabase-migration.sql, production-checklist.md
  prisma/schema.prisma      # 9 tabel sesuai spesifikasi
```

## 7. Database

Tabel: `users`, `game_saves`, `products`, `orders`, `payment_events`, `premium_wallets`, `premium_ledgers`, `entitlements`, `audit_logs` (detail relasi/index/constraint di `prisma/schema.prisma`; versi PostgreSQL + RLS di `docs/supabase-migration.sql`).

Aturan akses (ditegakkan di API sekarang, RLS saat pindah ke Supabase):
- Produk aktif: baca publik; ubah: admin.
- Order/save/ledger/entitlement: hanya pemilik (dan admin untuk order/ledger).
- Saldo premium: tidak pernah ditulis langsung dari request klien.
- Role admin: divalidasi dari DB per-request, tidak dari metadata klien.

## 8. Pembayaran

- **MockPay** (default, `PAYMENT_PROVIDER=mockpay`): mensimulasikan gateway END-TO-END melalui jalur produksi yang sama — halaman checkout berlabel **DEVELOPMENT ONLY** membangun webhook tersignature → `/api/payment/webhook` → verifikasi → idempotensi → kredit atomik. Tidak pernah dianggap pembayaran nyata.
- **Midtrans Snap** (`PAYMENT_PROVIDER=midtrans` + `MIDTRANS_SERVER_KEY`/`MIDTRANS_CLIENT_KEY`): create token `POST /snap/v1/transactions` (Basic Auth ServerKey), webhook `signature_key = SHA512(order_id+status_code+gross_amount+ServerKey)`, memetakan `settlement/capture(accept)→paid`, `deny/cancel/failure→failed`, `expire→expired`, `refund→refund`. **Aktifkan hanya setelah kredensial tersedia dan dokumentasi resmi diverifikasi ulang** (lihat `docs/production-checklist.md`).

## 9. Pengujian

```bash
bun test tests/game.test.ts   # 19 uji logika murni (inventory anti-duplikat, misi, gaji,
                              # relasi, furnitur collision, save roundtrip & korup, dll)
bun test tests/api.test.ts    # 20 uji keamanan (harga server, idempotensi webhook,
                              # signature palsu, akses order, admin deny, refund, dll)
bun run lint && bunx tsc --noEmit
```

Verifikasi manual yang sudah dilakukan (agent-browser): beranda render, registrasi → login, katalog dari DB, order → gateway mock → status fulfilled, saldo naik di profil, riwayat transaksi, game: gerak + collision dinding, NPC berkeliling, masuk/keluar interior, tidur → hari maju + autosave, load slot, dialog NPC, panel admin menolak user biasa.

## 10. Batasan & Langkah Pemilik Proyek

- Harga paket adalah **harga awal** — finalisasi via Admin Panel (tercatat audit).
- Pembayaran nyata butuh: akun gateway + kredensial + verifikasi dokumen resmi + uji sandbox (checklist di `docs/`).
- Audio/PNG digenerate programatik; kualitas bisa ditingkatkan dengan mengganti file di `public/game/assets` tanpa mengubah kode.
