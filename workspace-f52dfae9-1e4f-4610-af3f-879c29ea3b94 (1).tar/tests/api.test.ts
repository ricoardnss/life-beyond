// Uji keamanan & integritas API store — sesuai daftar pengujian Bagian J.
// Jalankan: bun test tests/api.test.ts  (dev server harus jalan di :3000)
import { describe, expect, test, beforeAll } from "bun:test";

const BASE = "http://localhost:3000";
const stamp = Date.now();

beforeAll(async () => {
  await fetch(BASE + "/api/devtools/reset-limits", { method: "POST" }).catch(() => {});
});

async function api(path: string, opts: RequestInit & { cookie?: string } = {}) {
  const headers = new Headers(opts.headers);
  if (opts.body && !headers.has("Content-Type")) headers.set("Content-Type", "application/json");
  if (opts.cookie) headers.set("Cookie", opts.cookie);
  const res = await fetch(BASE + path, { ...opts, headers, credentials: "omit" });
  const setCookie = res.headers.get("set-cookie");
  const cookie = setCookie?.split(";")[0];
  let data: unknown = null;
  try {
    data = await res.json();
  } catch { /* non-json */ }
  return { status: res.status, data, cookie };
}

async function registerUser(email: string, name: string) {
  const r = await api("/api/auth/register", {
    method: "POST",
    body: JSON.stringify({ email, password: "password-aman-123", displayName: name }),
  });
  return r;
}

describe("Auth", () => {
  test("registrasi + sesi", async () => {
    const r = await registerUser(`alice${stamp}@test.id`, "Alice");
    expect(r.status).toBe(201);
    expect(r.cookie).toContain("kk_session=");
    const me = await api("/api/auth/me", { cookie: r.cookie });
    expect(me.status).toBe(200);
    expect((me.data as { gems: number }).gems).toBe(0);
  });

  test("password lemah ditolak", async () => {
    const r = await api("/api/auth/register", {
      method: "POST",
      body: JSON.stringify({ email: `weak${stamp}@test.id`, password: "123", displayName: "Weak" }),
    });
    expect(r.status).toBe(400);
  });

  test("login salah → 401", async () => {
    const r = await api("/api/auth/login", {
      method: "POST",
      body: JSON.stringify({ email: `alice${stamp}@test.id`, password: "salah-banget" }),
    });
    expect(r.status).toBe(401);
  });

  test("tanpa sesi → /api/auth/me 401", async () => {
    const r = await api("/api/auth/me");
    expect(r.status).toBe(401);
  });
});

describe("Store & Order", () => {
  test("katalog publik 5 paket", async () => {
    const r = await api("/api/products");
    expect(r.status).toBe(200);
    expect((r.data as { products: unknown[] }).products.length).toBe(5);
  });

  test("order dibuat dengan harga dari SERVER (bukan client)", async () => {
    const reg = await registerUser(`bob${stamp}@test.id`, "Bob");
    const r = await api("/api/orders", {
      method: "POST",
      cookie: reg.cookie,
      body: JSON.stringify({ productId: "starter-gems", gems: 99999, amountIdr: 1 }), // manipulasi klien
    });
    expect(r.status).toBe(201);
    const d = r.data as { amountIdr: number; gems: number; status: string };
    expect(d.amountIdr).toBe(15000); // harga resmi DB
    expect(d.gems).toBe(100);
    expect(d.status).toBe("pending");
  });

  test("produk tidak ada → 404", async () => {
    const reg = await registerUser(`bob2${stamp}@test.id`, "Bob2");
    const r = await api("/api/orders", { method: "POST", cookie: reg.cookie, body: JSON.stringify({ productId: "tidak-ada" }) });
    expect(r.status).toBe(404);
  });

  test("order tanpa login → 401", async () => {
    const r = await api("/api/orders", { method: "POST", body: JSON.stringify({ productId: "starter-gems" }) });
    expect(r.status).toBe(401);
  });
});

describe("Pembayaran & Idempotensi", () => {
  test("alur lengkap: order → mock checkout → fulfilled → gems masuk", async () => {
    const reg = await registerUser(`carl${stamp}@test.id`, "Carl");
    const ord = await api("/api/orders", { method: "POST", cookie: reg.cookie, body: JSON.stringify({ productId: "adventurer-gems" }) });
    const orderId = (ord.data as { orderId: string }).orderId;

    const pay = await api("/api/payment/mock/checkout", {
      method: "POST",
      cookie: reg.cookie,
      body: JSON.stringify({ orderId, result: "sukses" }),
    });
    expect(pay.status).toBe(200);

    const me = await api("/api/auth/me", { cookie: reg.cookie });
    expect((me.data as { gems: number }).gems).toBe(250);
  });

  test("webhook duplikat TIDAK menggandakan saldo (idempoten)", async () => {
    const { MockPayProvider } = await import("../src/lib/payment/mock");
    const reg = await registerUser(`dup${stamp}@test.id`, "Dup");
    const ord = await api("/api/orders", { method: "POST", cookie: reg.cookie, body: JSON.stringify({ productId: "starter-gems" }) });
    const orderId = (ord.data as { orderId: string }).orderId;
    const eventId = `evt_test_${orderId}_1`;
    const raw = MockPayProvider.buildSignedWebhook(eventId, orderId, "paid", 15000);

    const r1 = await api("/api/payment/webhook", { method: "POST", body: raw });
    expect(r1.status).toBe(200);
    const r2 = await api("/api/payment/webhook", { method: "POST", body: raw });
    expect(r2.status).toBe(200);
    expect((r2.data as { message: string }).message).toContain("idempoten");

    const me = await api("/api/auth/me", { cookie: reg.cookie });
    expect((me.data as { gems: number }).gems).toBe(100); // tetap 100, bukan 200
  });

  test("webhook palsu (signature salah) ditolak, saldo berubah", async () => {
    const reg = await registerUser(`fake${stamp}@test.id`, "Fake");
    const before = await api("/api/auth/me", { cookie: reg.cookie });
    const gemsBefore = (before.data as { gems: number }).gems;

    const fake = JSON.stringify({ event_id: `fake_${stamp}`, order_id: "KK-ORD-PALSU", outcome: "paid", amount_idr: 15000, currency: "IDR", signature: "deadbeef" });
    const r = await api("/api/payment/webhook", { method: "POST", body: fake });
    expect(r.status).toBe(403);

    const after = await api("/api/auth/me", { cookie: reg.cookie });
    expect((after.data as { gems: number }).gems).toBe(gemsBefore);
  });

  test("nominal webhook yang dimodifikasi → 400", async () => {
    const { MockPayProvider } = await import("../src/lib/payment/mock");
    const reg = await registerUser(`amt${stamp}@test.id`, "Amt");
    const ord = await api("/api/orders", { method: "POST", cookie: reg.cookie, body: JSON.stringify({ productId: "starter-gems" }) });
    const orderId = (ord.data as { orderId: string }).orderId;
    // tanda tangan valid tapi nominal BEDA dari order
    const raw = MockPayProvider.buildSignedWebhook(`evt_amt_${stamp}`, orderId, "paid", 1);
    const r = await api("/api/payment/webhook", { method: "POST", body: raw });
    expect(r.status).toBe(400);
    const me = await api("/api/auth/me", { cookie: reg.cookie });
    expect((me.data as { gems: number }).gems).toBe(0);
  });

  test("order gagal TIDAK menambah saldo", async () => {
    const reg = await registerUser(`fail${stamp}@test.id`, "Fail");
    const ord = await api("/api/orders", { method: "POST", cookie: reg.cookie, body: JSON.stringify({ productId: "starter-gems" }) });
    const orderId = (ord.data as { orderId: string }).orderId;
    await api("/api/payment/mock/checkout", { method: "POST", cookie: reg.cookie, body: JSON.stringify({ orderId, result: "gagal" }) });
    const me = await api("/api/auth/me", { cookie: reg.cookie });
    expect((me.data as { gems: number }).gems).toBe(0);
  });

  test("checkout milik orang lain → 403", async () => {
    const a = await registerUser(`own1${stamp}@test.id`, "Own1");
    const b = await registerUser(`own2${stamp}@test.id`, "Own2");
    const ord = await api("/api/orders", { method: "POST", cookie: a.cookie, body: JSON.stringify({ productId: "starter-gems" }) });
    const orderId = (ord.data as { orderId: string }).orderId;
    const r = await api("/api/payment/mock/checkout", { method: "POST", cookie: b.cookie, body: JSON.stringify({ orderId, result: "sukses" }) });
    expect(r.status).toBe(403);
  });
});

describe("Kontrol akses", () => {
  test("user A tidak bisa lihat order milik user B", async () => {
    const a = await registerUser(`acc1${stamp}@test.id`, "Acc1");
    const b = await registerUser(`acc2${stamp}@test.id`, "Acc2");
    const ord = await api("/api/orders", { method: "POST", cookie: b.cookie, body: JSON.stringify({ productId: "starter-gems" }) });
    const orderId = (ord.data as { orderId: string }).orderId;
    const r = await api(`/api/orders/${orderId}`, { cookie: a.cookie });
    expect(r.status).toBe(403);
  });

  test("API admin ditolak untuk user biasa", async () => {
    const a = await registerUser(`nonadmin${stamp}@test.id`, "NonAdmin");
    for (const p of ["/api/admin/stats", "/api/admin/orders", "/api/admin/ledger", "/api/admin/audit"]) {
      const r = await api(p, { cookie: a.cookie });
      expect(r.status).toBe(403);
    }
    const rCreate = await api("/api/admin/products", { method: "POST", cookie: a.cookie, body: JSON.stringify({ id: "hack", name: "Hack", gems: 1, priceIdr: 1, description: "hack" }) });
    expect(rCreate.status).toBe(403);
  });

  test("save game: owner-only & upsert", async () => {
    const a = await registerUser(`savea${stamp}@test.id`, "SaveA");
    const b = await registerUser(`saveb${stamp}@test.id`, "SaveB");
    const post = await api("/api/saves", { method: "POST", cookie: a.cookie, body: JSON.stringify({ slot: 1, data: JSON.stringify({ day: 3, money: 123000 }) }) });
    expect(post.status).toBe(200);
    const getA = await api("/api/saves?slot=1", { cookie: a.cookie });
    expect(getA.status).toBe(200);
    expect(JSON.parse((getA.data as { data: string }).data).money).toBe(123000);
    // save milik A tidak bocor ke B
    const getB = await api("/api/saves?slot=1", { cookie: b.cookie });
    expect(getB.status).toBe(404);
    // slot invalid
    const bad = await api("/api/saves?slot=9", { cookie: a.cookie });
    expect(bad.status).toBe(400);
  });
});

describe("Gems spend", () => {
  test("saldo kurang → 400; beli sukses → entitlement + ledger; nonce sama → 409", async () => {
    const a = await registerUser(`spend${stamp}@test.id`, "Spender");
    const poor = await api("/api/gems/spend", { method: "POST", cookie: a.cookie, body: JSON.stringify({ sku: "outfit.cyber", nonce: `n${stamp}0001` }) });
    expect(poor.status).toBe(400);

    // top-up dulu
    const ord = await api("/api/orders", { method: "POST", cookie: a.cookie, body: JSON.stringify({ productId: "explorer-gems" }) });
    const orderId = (ord.data as { orderId: string }).orderId;
    await api("/api/payment/mock/checkout", { method: "POST", cookie: a.cookie, body: JSON.stringify({ orderId, result: "sukses" }) });

    const ok = await api("/api/gems/spend", { method: "POST", cookie: a.cookie, body: JSON.stringify({ sku: "outfit.cyber", nonce: `n${stamp}0002` }) });
    expect(ok.status).toBe(200);
    const ent = await api("/api/gems/entitlements", { cookie: a.cookie });
    expect((ent.data as { entitlements: string[] }).entitlements).toContain("outfit.cyber");

    // double-spend dengan nonce sama
    const dup = await api("/api/gems/spend", { method: "POST", cookie: a.cookie, body: JSON.stringify({ sku: "outfit.cyber", nonce: `n${stamp}0002` }) });
    expect(dup.status).toBe(409);
  });
});

describe("Admin & refund", () => {
  test("admin stats OK; refund mengurangi Gems; refund ganda ditolak", async () => {
    const adm = await api("/api/auth/login", { method: "POST", body: JSON.stringify({ email: "admin@kotakita.dev", password: "kotakita-admin" }) });
    expect(adm.status).toBe(200);

    const stats = await api("/api/admin/stats", { cookie: adm.cookie });
    expect(stats.status).toBe(200);

    const victim = await registerUser(`refund${stamp}@test.id`, "Refundee");
    const ord = await api("/api/orders", { method: "POST", cookie: victim.cookie, body: JSON.stringify({ productId: "arunika-elite" }) });
    const orderId = (ord.data as { orderId: string }).orderId;
    await api("/api/payment/mock/checkout", { method: "POST", cookie: victim.cookie, body: JSON.stringify({ orderId, result: "sukses" }) });
    const me1 = await api("/api/auth/me", { cookie: victim.cookie });
    expect((me1.data as { gems: number }).gems).toBe(2500);

    const refund = await api("/api/admin/refund", { method: "POST", cookie: adm.cookie, body: JSON.stringify({ orderId }) });
    expect(refund.status).toBe(200);
    const me2 = await api("/api/auth/me", { cookie: victim.cookie });
    expect((me2.data as { gems: number }).gems).toBe(0);

    const again = await api("/api/admin/refund", { method: "POST", cookie: adm.cookie, body: JSON.stringify({ orderId }) });
    expect(again.status).toBe(400);

    // refund oleh non-admin ditolak
    const evil = await registerUser(`evil${stamp}@test.id`, "Evil");
    const notAllowed = await api("/api/admin/refund", { method: "POST", cookie: evil.cookie, body: JSON.stringify({ orderId: "KK-ORD-x" }) });
    expect(notAllowed.status).toBe(403);
  });

  test("admin bisa ubah harga produk (audit tercatat)", async () => {
    const adm = await api("/api/auth/login", { method: "POST", body: JSON.stringify({ email: "admin@kotakita.dev", password: "kotakita-admin" }) });
    const r = await api("/api/admin/products/explorer-gems", {
      method: "PATCH",
      cookie: adm.cookie,
      body: JSON.stringify({ priceIdr: 79000 }),
    });
    expect(r.status).toBe(200);
    const audit = await api("/api/admin/audit", { cookie: adm.cookie });
    const rows = (audit.data as { audit: { action: string }[] }).audit;
    expect(rows.some((x) => x.action === "product_update")).toBe(true);
  });
});
