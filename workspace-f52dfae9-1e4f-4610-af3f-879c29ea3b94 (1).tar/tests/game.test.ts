// Uji logika game murni — tanpa jaringan, tanpa DOM.
// Jalankan: bun test tests/game.test.ts
import { describe, expect, test, beforeEach } from "bun:test";

// stub localStorage untuk modul yang memakainya
const store = new Map<string, string>();
(globalThis as { localStorage?: unknown }).localStorage = {
  getItem: (k: string) => store.get(k) ?? null,
  setItem: (k: string, v: string) => store.set(k, v),
  removeItem: (k: string) => store.delete(k),
};

import { state as gamestate, newGameState } from "../src/game/core/state";
import { addItem, removeItem, countItem, useItem, moveSlot, dropSlot } from "../src/game/systems/inventory";
import { spendMoney, earnMoney, sleepUntilMorning, currentHour, checkAchievements } from "../src/game/systems/systems";
import { chatWith, giveGift, confess, goOnDate, breakUp, isDating, canConfess, pacarOf } from "../src/game/systems/social";
import { activateQuest, checkQuestObjective, questReady, objectiveDone, refreshAvailability } from "../src/game/systems/quests";
import { startShift, finishShift, jobAvailable } from "../src/game/systems/jobs";
import { canPlace, placeFurniture, moveFurniture, removeFurniture } from "../src/game/systems/furniture";
import { stageOf } from "../src/game/core/constants";
import { serializeSlot, deserializeSlot } from "../src/game/core/save";
import { joyVector, knobOffset } from "../src/game/core/joy";
import { seasonOf, dayOfSeason, rollWeather } from "../src/game/core/constants";
import { onNewDay } from "../src/game/systems/systems";
import { NPCS } from "../src/game/data/npcs";
import { NPC_KEYS } from "../src/game/sprites";
import { POI, INTERIOR_WORKSPOT, INTERIORS } from "../src/game/data/mapdata";
import { DIALOGS } from "../src/game/data/dialogs";

function fresh() {
  gamestate.set(newGameState("Tester"));
}

describe("Inventory", () => {
  beforeEach(fresh);

  test("tambah & hitung tanpa duplikasi klik ganda", () => {
    expect(addItem("es_teh", 3)).toBe(true);
    expect(countItem("es_teh")).toBe(3);
    // klik ganda pada aksi yang sama: add lagi menambah jumlah, TAPI remove balanced tetap konsisten
    addItem("es_teh", 1);
    expect(removeItem("es_teh", 1)).toBe(true);
    expect(countItem("es_teh")).toBe(3);
  });

  test("stok tidak cukup -> remove gagal", () => {
    addItem("roti", 2);
    expect(removeItem("roti", 5)).toBe(false);
    expect(countItem("roti")).toBe(2);
  });

  test("useItem menghabiskan stok dan memberi efek", () => {
    addItem("kopi", 1);
    const before = gamestate.get().needs.energi;
    expect(useItem(0)).toBe(true);
    expect(countItem("kopi")).toBe(0);
    expect(gamestate.get().needs.energi).toBeGreaterThan(before);
    expect(useItem(0)).toBe(false); // sudah habis
  });

  test("pindah slot & tumpukan menyatu", () => {
    addItem("es_teh", 2);
    addItem("es_teh", 2);
    expect(moveSlot(0, 1)).toBe(true); // stack 4 di slot 1
    expect(countItem("es_teh")).toBe(4);
  });

  test("item quest tidak bisa dibuang", () => {
    addItem("paket", 1);
    expect(dropSlot(0)).toBe(false);
    expect(countItem("paket")).toBe(1);
  });
});

describe("Ekonomi", () => {
  beforeEach(fresh);

  test("belanja ditolak bila uang kurang; ledger tercatat", () => {
    gamestate.get().money = 5000;
    expect(spendMoney(10000, "Test beli")).toBe(false);
    expect(gamestate.get().money).toBe(5000);
    earnMoney(20000, "Test gaji");
    expect(spendMoney(10000, "Test beli")).toBe(true);
    expect(gamestate.get().money).toBe(15000);
    expect(gamestate.get().ledger.length).toBe(2);
  });
});

describe("Waktu & tidur", () => {
  beforeEach(fresh);

  test("jam & tidur memajukan hari", () => {
    gamestate.get().timeMin = 22 * 60;
    expect(currentHour()).toBe(22);
    const r = sleepUntilMorning();
    expect(gamestate.get().timeMin).toBe(7 * 60);
    expect(gamestate.get().day).toBe(2);
    expect(r.skipped).toBeGreaterThan(0);
    expect(gamestate.get().needs.energi).toBeGreaterThan(80);
  });
});

describe("Relasi", () => {
  beforeEach(fresh);

  test("chat memberi skor dan terbatas harian", () => {
    for (let i = 0; i < 5; i++) {
      const r = chatWith("mas_tony");
      if (i < 3) expect(r.ok).toBe(true);
      else expect(r.ok).toBe(false);
    }
    expect(gamestate.get().relationships["mas_tony"].score).toBeGreaterThan(0);
    expect(stageOf(gamestate.get().relationships["mas_tony"].score).id).toBe("kenalan");
  });

  test("hadiah disukai > netral, dan batas 1/hari", () => {
    addItem("kopi", 2); // disukai mas_tony
    const r1 = giveGift("mas_tony", "kopi");
    expect(r1.ok).toBe(true);
    const scoreLike = gamestate.get().relationships["mas_tony"].score;
    const r2 = giveGift("mas_tony", "kopi");
    expect(r2.ok).toBe(false); // batas harian
    const neutral = gamestate.get().relationships;
    void neutral;
    expect(scoreLike).toBeGreaterThan(10);
  });
});

describe("Pacaran", () => {
  beforeEach(fresh);

  test("NPC non-romanceable tidak bisa ditembak", () => {
    gamestate.get().relationships["mas_tony"] = { score: 100, stage: "sahabat", chatToday: 0, giftToday: 0, lastDay: 1 };
    expect(canConfess("mas_tony").ok).toBe(false);
    expect(confess("mas_tony").ok).toBe(false);
    expect(isDating("mas_tony")).toBe(false);
  });

  test("nembak ditolak bila kedekatan belum cukup", () => {
    gamestate.get().relationships["dinda"] = { score: 60, stage: "teman_dekat", chatToday: 0, giftToday: 0, lastDay: 1 };
    const r = confess("dinda");
    expect(r.ok).toBe(false);
    expect(isDating("dinda")).toBe(false);
    expect(pacarOf(gamestate.get())).toBeNull();
  });

  test("jadian bila skor cukup; hanya satu pacar (eksklusif)", () => {
    const s = gamestate.get();
    s.relationships["dinda"] = { score: 90, stage: "sahabat", chatToday: 0, giftToday: 0, lastDay: 1 };
    const r = confess("dinda");
    expect(r.ok).toBe(true);
    expect(isDating("dinda")).toBe(true);
    expect(pacarOf(s)).toBe("dinda");
    expect(s.flags["pacar_dinda"]).toBe(true);
    // mencoba nembak orang lain saat punya pacar -> gagal
    s.relationships["maya"] = { score: 99, stage: "sahabat", chatToday: 0, giftToday: 0, lastDay: 1 };
    expect(canConfess("maya").reason).toBe("punya_pacar");
    expect(confess("maya").ok).toBe(false);
    expect(isDating("maya")).toBe(false);
  });

  test("date butuh status pacar, sekali sehari, biaya dipotong via ledger", () => {
    const s = gamestate.get();
    // belum pacaran -> ditolak
    expect(goOnDate("dinda", "kafe").ok).toBe(false);
    s.relationships["dinda"] = { score: 90, stage: "sahabat", chatToday: 0, giftToday: 0, lastDay: 1 };
    confess("dinda");
    const money = s.money;
    const ledgerLen = s.ledger.length;
    const d1 = goOnDate("dinda", "kafe");
    expect(d1.ok).toBe(true);
    expect(s.money).toBe(money - 35000);
    expect(s.ledger.length).toBe(ledgerLen + 1);
    expect(s.ledger[0].amount).toBe(-35000);
    expect(s.stats.datesGone).toBe(1);
    // batas 1x per hari
    const d2 = goOnDate("dinda", "santai");
    expect(d2.ok).toBe(false);
    // date dengan non-pacar ditolak
    expect(goOnDate("mas_tony", "santai").ok).toBe(false);
  });

  test("date gratis tidak memotong uang; opsi tak dikenal ditolak", () => {
    const s = gamestate.get();
    s.relationships["rian"] = { score: 88, stage: "sahabat", chatToday: 0, giftToday: 0, lastDay: 1 };
    confess("rian");
    const money = s.money;
    expect(goOnDate("rian", "santai").ok).toBe(true);
    expect(s.money).toBe(money);
    expect(goOnDate("rian", "mewek").ok).toBe(false);
  });

  test("date ditolak bila uang tidak cukup", () => {
    const s = gamestate.get();
    s.relationships["sinta"] = { score: 92, stage: "sahabat", chatToday: 0, giftToday: 0, lastDay: 1 };
    confess("sinta");
    s.money = 1000;
    expect(goOnDate("sinta", "kafe").ok).toBe(false);
    expect(s.stats.datesGone).toBe(0);
  });

  test("putus: status hilang, skor dipotong, mood turun", () => {
    const s = gamestate.get();
    s.relationships["sinta"] = { score: 90, stage: "sahabat", chatToday: 0, giftToday: 0, lastDay: 1 };
    confess("sinta");
    const mood = s.needs.mood;
    const b = breakUp("sinta");
    expect(b.ok).toBe(true);
    expect(isDating("sinta")).toBe(false);
    expect(s.flags["pacar_sinta"]).toBeUndefined();
    expect(s.needs.mood).toBeLessThan(mood);
    expect(s.relationships["sinta"].score).toBeLessThan(90);
    expect(pacarOf(s)).toBeNull();
  });

  test("putus otomatis saat skor pacar di bawah ambang ketika ganti hari", () => {
    const s = gamestate.get();
    s.relationships["dinda"] = { score: 88, stage: "sahabat", chatToday: 0, giftToday: 0, lastDay: 1, dating: true, sinceDay: 1, dateToday: 0 };
    s.timeMin = 22 * 60;
    sleepUntilMorning(); // decay -2 -> 86, masih pacaran
    expect(isDating("dinda")).toBe(true);
    s.relationships["dinda"].score = 20;
    s.timeMin = 22 * 60;
    sleepUntilMorning(); // di bawah ambang -> putus otomatis
    expect(isDating("dinda")).toBe(false);
    expect(s.flags["pacar_dinda"]).toBeUndefined();
  });

  test("skor pacar meluruh per hari tanpa interaksi (tidak sampai 0)", () => {
    const s = gamestate.get();
    s.relationships["maya"] = { score: 50, stage: "teman_dekat", chatToday: 0, giftToday: 0, lastDay: 1, dating: true, sinceDay: 1, dateToday: 0 };
    s.timeMin = 22 * 60;
    sleepUntilMorning();
    expect(s.relationships["maya"].score).toBe(48);
    expect(isDating("maya")).toBe(true);
  });

  test("mengobrol dengan pacar memakai pool romantis & mood bonus lebih besar", () => {
    const s = gamestate.get();
    s.relationships["dinda"] = { score: 90, stage: "sahabat", chatToday: 0, giftToday: 0, lastDay: 1, dating: true, sinceDay: 1, dateToday: 0 };
    const mood = s.needs.mood;
    const r = chatWith("dinda");
    expect(r.ok).toBe(true);
    expect(s.needs.mood).toBe(mood + 10); // 4 + CHAT_MOOD_BONUS(6)
    expect(s.relationships["dinda"].lastDay).toBe(s.day);
  });

  test("data save lama tanpa field pacaran tetap dimuat", () => {
    const s = gamestate.get();
    s.relationships["dinda"] = { score: 42, stage: "teman", chatToday: 1, giftToday: 0, lastDay: 12 };
    const raw = serializeSlot(s);
    const parsed = deserializeSlot(raw)!;
    expect(parsed.relationships["dinda"].dating).toBeUndefined();
    expect(parsed.stats.datesGone).toBe(0);
    // dan relasi pacar tetap tersimpan setelah save-load
    s.relationships["dinda"].dating = true;
    s.relationships["dinda"].sinceDay = 5;
    const parsed2 = deserializeSlot(serializeSlot(s))!;
    expect(parsed2.relationships["dinda"].dating).toBe(true);
    expect(parsed2.relationships["dinda"].sinceDay).toBe(5);
  });
});

describe("Misi", () => {
  beforeEach(() => {
    fresh();
    refreshAvailability();
  });

  test("tutorial t1: bicara Mas Tony -> selesai & hadiah", () => {
    const s = gamestate.get();
    expect(s.quests["t1_hari_pertama"].status).toBe("tersedia");
    activateQuest("t1_hari_pertama");
    expect(objectiveDone("t1_hari_pertama", "talk_mas_tony")).toBe(false);
    checkQuestObjective("talk_mas_tony", 1);
    expect(questReady("t1_hari_pertama")).toBe(true);
    expect(s.quests["t1_hari_pertama"].status).toBe("selesai");
    expect(s.money).toBe(150000 + 5000);
    // t2 otomatis tersedia
    expect(s.quests["t2_isi_perut"].status).toBe("tersedia");
  });

  test("misi sampingan muncul sesuai hari", () => {
    gamestate.get().day = 3;
    refreshAvailability();
    expect(gamestate.get().quests["q_paket_menggunung"].status).toBe("tersedia");
    expect(gamestate.get().quests["q_menu_baru"].status).toBe("tersedia");
    // q_kopi_segar butuh hari 4
    expect(gamestate.get().quests["q_kopi_segar"]).toBeUndefined();
  });
});

describe("Pekerjaan", () => {
  beforeEach(fresh);

  test("shift di luar jam ditolak", () => {
    gamestate.get().timeMin = 2 * 60; // jam 02:00
    const r = jobAvailable("warung");
    expect(r.ok).toBe(false);
    expect(startShift("warung")).toBe(false);
  });

  test("shift warung selesai -> gaji + skill exp", () => {
    gamestate.get().timeMin = 8 * 60; // dalam jam kerja
    expect(startShift("warung")).toBe(true);
    const before = gamestate.get().money;
    finishShift({ correctServe: 5 });
    expect(gamestate.get().money).toBe(before + 18000 + 5 * 500);
    expect(gamestate.get().jobs.warung.shiftsDone).toBe(1);
    expect(gamestate.get().shift).toBeNull();
  });

  test("minimarket butuh 2 shift warung", () => {
    gamestate.get().timeMin = 16 * 60;
    expect(jobAvailable("minimarket").ok).toBe(false);
    gamestate.get().jobs.warung.shiftsDone = 2;
    expect(jobAvailable("minimarket").ok).toBe(true);
  });
});

describe("Furnitur", () => {
  beforeEach(fresh);

  test("penempatan tumpang tindih ditolak; pindah valid", () => {
    const s = gamestate.get();
    // kasur default di (2,2) ukuran 2x2
    expect(canPlace("furn_chair", 2, 2)).toBe(false); // bentrok kasur
    expect(canPlace("furn_chair", 9, 5)).toBe(true);
    expect(placeFurniture("furn_chair", 2, 2)).toBe(false); // tidak punya item
    addItem("furn_chair", 1);
    expect(placeFurniture("furn_chair", 9, 5)).toBe(true);
    const uid = s.furniture[s.furniture.length - 1].uid;
    expect(moveFurniture(uid, 9, 6)).toBe(true);
    expect(moveFurniture(uid, 0, 0)).toBe(false); // dinding
    expect(removeFurniture(uid)).toBe(true);
    expect(countItem("furn_chair")).toBe(1); // kembali ke inventory
  });
});

describe("Save", () => {
  beforeEach(fresh);

  test("roundtrip serialize/deserialize", () => {
    const s = gamestate.get();
    s.money = 999999;
    s.day = 12;
    addItem("nasi_goreng", 2);
    s.relationships["dinda"] = { score: 42, stage: "teman", chatToday: 1, giftToday: 0, lastDay: 12 };
    const raw = serializeSlot(s);
    const parsed = deserializeSlot(raw)!;
    expect(parsed.money).toBe(999999);
    expect(parsed.day).toBe(12);
    expect(parsed.relationships["dinda"].score).toBe(42);
    expect(parsed.inventory.filter(Boolean).length).toBe(1);
  });

  test("data korup -> null, tidak crash", () => {
    expect(deserializeSlot("{korup!!")).toBeNull();
    expect(deserializeSlot("")).toBeNull();
    expect(deserializeSlot("null")).toBeNull();
  });

  test("migrasi field baru: data lama tetap valid", () => {
    const s = gamestate.get();
    s.money = 5000;
    const raw = JSON.parse(serializeSlot(s));
    delete raw.stats; // simulasi skema lama tanpa field baru
    const parsed = deserializeSlot(JSON.stringify(raw))!;
    expect(parsed.money).toBe(5000);
    expect(parsed.stats.mealsEaten).toBe(0); // diisi default
  });
});

describe("Achievement", () => {
  beforeEach(fresh);

  test("uang 500rb membuka pencapaian", () => {
    gamestate.get().money = 600000;
    checkAchievements();
    expect(gamestate.get().achievements).toContain("rich");
  });
});

describe("Joystick virtual (kontrol sentuh)", () => {
  const base = { cx: 0, cy: 0, radius: 60 };

  test("di dalam deadzone -> nol (tak jalan sendiri)", () => {
    expect(joyVector({ ...base, x: 4, y: 2 })).toEqual({ x: 0, y: 0 });
  });

  test("arah penuh di tepi -> ternormalisasi maksimal 1", () => {
    const v = joyVector({ ...base, x: 200, y: 0, deadzone: 0 });
    expect(v.x).toBeCloseTo(1);
    expect(v.y).toBeCloseTo(0);
  });

  test("diagonal tidak melebihi 1 (kecepatan diagonal konsisten)", () => {
    const v = joyVector({ ...base, x: 60, y: 60, deadzone: 0 });
    expect(Math.hypot(v.x, v.y)).toBeCloseTo(1);
  });

  test("setengah dorong -> kecepatan proporsional di atas deadzone", () => {
    const v = joyVector({ ...base, x: 30, y: 0, deadzone: 0 });
    expect(v.x).toBeGreaterThan(0.4);
    expect(v.x).toBeLessThan(0.6);
  });

  test("knob visual tidak keluar dari radius", () => {
    const k = knobOffset({ ...base, x: 500, y: -500 });
    expect(Math.hypot(k.x, k.y)).toBeCloseTo(60);
  });
});

// ---------- Musim & cuaca (fitur baru) ----------
describe("Musim & cuaca", () => {
  beforeEach(fresh);

  test("musim berganti tiap 7 hari: semi->panas->gugur->dingin->semi", () => {
    expect(seasonOf(1)).toBe("semi");
    expect(seasonOf(7)).toBe("semi");
    expect(seasonOf(8)).toBe("panas");
    expect(seasonOf(14)).toBe("panas");
    expect(seasonOf(15)).toBe("gugur");
    expect(seasonOf(22)).toBe("dingin");
    expect(seasonOf(29)).toBe("semi"); // siklus ulang
    expect(dayOfSeason(8)).toBe(1);
    expect(dayOfSeason(10)).toBe(3);
  });

  test("rollWeather hanya menghasilkan cuaca yang valid per musim", () => {
    const valid = ["cerah", "berawan", "hujan", "badai", "kabut", "salju"];
    for (const season of ["semi", "panas", "gugur", "dingin"] as const) {
      for (let i = 0; i < 60; i++) {
        const w = rollWeather(season);
        expect(valid.includes(w)).toBe(true);
        if (season !== "dingin") expect(w).not.toBe("salju"); // salju hanya di musim dingin
      }
    }
  });

  test("onNewDay memperbarui musim otomatis mengikuti hari", () => {
    const s = gamestate.get();
    s.day = 7; // hari terakhir musim semi
    onNewDay(); // -> hari 8, musim panas
    expect(s.day).toBe(8);
    expect(s.season).toBe("panas");
  });
});

// ---------- Percakapan berurutan (nyambung) ----------
describe("Percakapan berurutan", () => {
  beforeEach(fresh);

  test("obrolan berulang memakai topik berikutnya secara berurutan", () => {
    const s = gamestate.get();
    // pastikan relasi cukup dekat agar pool stabil
    s.relationships["mas_tony"] = { score: 85, stage: "sahabat", chatToday: 0, giftToday: 0, lastDay: s.day, chatTotal: 0 };
    const seen: string[] = [];
    for (let i = 0; i < 3; i++) {
      s.relationships["mas_tony"].chatToday = 0; // reset batas harian antar obrolan
      const r = chatWith("mas_tony");
      expect(r.ok).toBe(true);
      seen.push(r.line);
    }
    // tiga baris berbeda => topik maju, tidak mengulang yang sama terus-menerus
    expect(new Set(seen).size).toBeGreaterThan(1);
    expect(s.relationships["mas_tony"].chatTotal).toBe(3);
  });
});

// ---------- Integritas data 38 NPC ----------
describe("Integritas data NPC (38 warga)", () => {
  test("total 38 NPC dan semua tex terdaftar di NPC_KEYS", () => {
    expect(NPCS.length).toBe(38);
    expect(NPC_KEYS.length).toBe(38);
    for (const n of NPCS) expect(NPC_KEYS.includes(n.id)).toBe(true);
  });

  test("semua POI jadwal & rumah terdefinisi", () => {
    for (const n of NPCS) {
      expect(POI[n.homePoi] !== undefined).toBe(true);
      for (const b of n.schedule) {
        if (b.poi.startsWith("in:")) continue;
        expect(POI[b.poi] !== undefined).toBe(true);
      }
    }
  });

  test("semua workspot interior NPC 'in:' terdefinisi", () => {
    for (const n of NPCS) {
      for (const b of n.schedule) {
        if (!b.poi.startsWith("in:")) continue;
        const id = b.poi.slice(3);
        expect(INTERIORS[id] !== undefined).toBe(true);
        expect(INTERIOR_WORKSPOT[id]?.[n.id] !== undefined).toBe(true);
      }
    }
  });

  test("semua NPC punya dialog pool chat yang cukup", () => {
    for (const n of NPCS) {
      expect(DIALOGS[n.id] !== undefined).toBe(true);
      expect(DIALOGS[n.id].chat.length).toBeGreaterThanOrEqual(5);
      expect(DIALOGS[n.id].sapa.length).toBeGreaterThanOrEqual(1);
    }
  });

  test("save lama (tanpa season) dimigrasi ke musim semi otomatis", () => {
    const raw = JSON.stringify({ ...newGameState("Lama"), season: undefined, version: 1 });
    const parsed = deserializeSlot(raw);
    expect(parsed).not.toBeNull();
    expect(parsed!.season).toBe("semi");
    expect(parsed!.weather).toBe("cerah");
  });
});
