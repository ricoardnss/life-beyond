# Checklist Produksi & Deployment — KOTA KITA: Life Beyond

Bagian ini adalah langkah yang **memerlukan tindakan pemilik proyek** sebelum peluncuran komersial. Semua kode pendukung sudah siap.

---

## A. Deployment aplikasi

1. **Build**: `bun run build` (output standalone di `.next/standalone`). Jalankan dengan `NODE_ENV=production`.
2. **Database**: pindah ke PostgreSQL Supabase — set `DATABASE_URL` ke connection string, jalankan `docs/supabase-migration.sql`, lalu `bun run db:generate` (Prisma `provider` diubah ke `"postgresql"` bila memakai migrate).
3. **Seed awal**: `bun run scripts/seed.ts` dengan `ADMIN_EMAIL`/`ADMIN_PASSWORD` kuat.
4. **Environment** (lihat `.env.example`): `SESSION_SECRET` acak ≥32 karakter; `MOCKPAY_SECRET` diganti; jangan pernah commit `.env`.
5. **Backup**: aktifkan PITR Supabase; ledger & audit_logs adalah data keuangan — jangan pernah dihapus manual.

## B. Mengaktifkan pembayaran nyata (Midtrans Snap)

1. Daftar Midtrans → ambil **Server Key** & **Client Key** sandbox.
2. Set `PAYMENT_PROVIDER=midtrans`, `MIDTRANS_SERVER_KEY`, `MIDTRANS_CLIENT_KEY`, `MIDTRANS_IS_PRODUCTION=false`.
3. Daftarkan **Payment Notification URL** di dashboard Midtrans → `https://<domain-anda>/api/payment/webhook`.
4. **Verifikasi ulang dokumen resmi** (wajib sebelum go-live): endpoint create token `POST /snap/v1/transactions`, formula signature `SHA512(order_id+status_code+gross_amount+ServerKey)`, pemetaan `transaction_status` di `src/lib/payment/midtrans.ts` — sesuaikan bila ada perubahan API.
5. Uji sandbox: simulator.sandbox.midtrans.com (VA/QRIS), kartu test sukses/deny, uji expire notification.
6. Uji keamanan: kirim webhook dengan signature salah (harus 403), kirim dua kali event sama (harus idempoten), ubah nominal (harus 400).
7. Go-live: ganti kunci produksi, `MIDTRANS_IS_PRODUCTION=true`, daftarkan ulang notification URL produksi, dan jalankan seluruh suite `bun test tests/api.test.ts` sekali lagi.
8. Selama apapun `PAYMENT_PROVIDER=mockpay`, UI otomatis menampilkan label **DEVELOPMENT ONLY** — jangan pernah menerima dana di mode ini.

## C. Keamanan

- [ ] `SESSION_SECRET` & `MOCKPAY_SECRET` unik per lingkungan.
- [ ] Password admin diganti dari default; 2FA pada akun gateway/email.
- [ ] Rate limiting in-memory cukup untuk single-instance; untuk multi-instance pakai store bersama (Redis/Upstash) — kelas di `src/lib/rate-limit.ts` tinggal diganti implementasinya.
- [ ] Log webhook tidak menyimpan secret (sudah dipastikan — payload JSON gateway saja).
- [ ] Aktifkan RLS Supabase (`docs/supabase-migration.sql`) bila klien mengakses Supabase langsung.
- [ ] Review audit_logs mingguan (refund, product_update, gems_spend).

## D. Harga & konten

- [ ] Finalisasi harga paket Gems via **Admin Panel** (ubah harga → tercatat di audit log; katalog langsung berubah).
- [ ] Nonaktifkan paket yang tidak dijual (jangan hapus jika sudah punya riwayat order).
- [ ] Tinjau `docs` halaman S&K/Privasi — masih draft; lengkapi identitas legal pemilik.

## E. Pemeliharaan aset

- Aset digenerate oleh skrip Python (`scripts/gen_*.py`). Untuk mengganti gaya visual: edit palet/skrip → jalankan ulang → PNG/WAV di `public/game/` tertimpa. Tidak ada aset pihak ketiga yang dipakai.
- Versi Phaser dipin `3.90.0` di `package.json` — naikkan versi secara teruji saja.

## F. Scaling lanjutan (opsional)

- Pindahkan bucket rate-limit ke Redis bila memakai >1 instance.
- Simpan snapshot save besar ke object storage bila melebihi ~400KB.
- Tambahkan CDN di depan `public/game/` (aset statis ~4MB total).
