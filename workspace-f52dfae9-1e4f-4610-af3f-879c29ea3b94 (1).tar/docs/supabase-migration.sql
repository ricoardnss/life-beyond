-- ============================================================
-- KOTA KITA: Life Beyond — Migration PostgreSQL (Supabase)
-- Versi produksi dari prisma/schema.prisma + kebijakan RLS.
-- Jalankan di Supabase SQL Editor atau via migration CLI.
-- ============================================================

create extension if not exists "pgcrypto";

-- ============ AKUN ============
create table if not exists users (
  id            uuid primary key default gen_random_uuid(),
  email         text not null unique,
  password_hash text not null,
  display_name  text not null,
  role          text not null default 'user' check (role in ('user','admin')),
  created_at    timestamptz not null default now(),
  updated_at    timestamptz not null default now()
);

-- ============ GAME ============
create table if not exists game_saves (
  id         uuid primary key default gen_random_uuid(),
  user_id    uuid not null references users(id) on delete cascade,
  slot       int  not null check (slot between 1 and 3),
  version    int  not null default 1,
  data       text not null,
  played_at  timestamptz not null default now(),
  unique (user_id, slot)
);
create index if not exists idx_game_saves_user on game_saves(user_id);

-- ============ STORE ============
create table if not exists products (
  id          text primary key,
  name        text not null,
  gems        int  not null check (gems > 0),
  price_idr   int  not null check (price_idr >= 0),
  description text not null,
  image_url   text,
  active      boolean not null default true,
  promo_label text,
  sort_order  int not null default 0,
  created_at  timestamptz not null default now(),
  updated_at  timestamptz not null default now()
);

create table if not exists orders (
  id           text primary key,               -- "KK-ORD-xxxx"
  user_id      uuid not null references users(id) on delete cascade,
  product_id   text not null references products(id),
  gems         int  not null,                  -- salinan harga resmi saat order dibuat
  amount_idr   int  not null,
  currency     text not null default 'IDR',
  status       text not null default 'pending'
               check (status in ('pending','paid','failed','expired','refunded','fulfilled')),
  provider     text not null default 'mockpay',
  provider_ref text,
  expires_at   timestamptz,
  paid_at      timestamptz,
  fulfilled_at timestamptz,
  created_at   timestamptz not null default now(),
  updated_at   timestamptz not null default now()
);
create index if not exists idx_orders_user   on orders(user_id);
create index if not exists idx_orders_status on orders(status);

create table if not exists payment_events (
  id                uuid primary key default gen_random_uuid(),
  provider_event_id text not null unique,       -- kunci idempotensi event gateway
  order_id          text references orders(id) on delete set null,
  provider          text not null,
  event_type        text not null,
  signature_valid   boolean not null,
  payload           text not null,              -- TANPA rahasia/secret key
  created_at        timestamptz not null default now()
);
create index if not exists idx_payment_events_order on payment_events(order_id);

-- ============ DOMPET PREMIUM ============
create table if not exists premium_wallets (
  id         uuid primary key default gen_random_uuid(),
  user_id    uuid not null unique references users(id) on delete cascade,
  balance    int  not null default 0 check (balance >= 0),  -- Arunika Gems
  updated_at timestamptz not null default now()
);

create table if not exists premium_ledgers (
  id            uuid primary key default gen_random_uuid(),
  user_id       uuid not null references users(id) on delete cascade,
  delta         int  not null,
  balance_after int  not null,
  reason        text not null check (reason in ('topup','spend','refund','admin_grant','admin_deduct')),
  ref_type      text not null,                  -- order | game_sku | admin
  ref_id        text not null,
  note          text,
  created_at    timestamptz not null default now(),
  unique (reason, ref_id)                       -- idempotensi kredit/debit per transaksi
);
create index if not exists idx_ledger_user on premium_ledgers(user_id, created_at);

create table if not exists entitlements (
  id         uuid primary key default gen_random_uuid(),
  user_id    uuid not null references users(id) on delete cascade,
  sku        text not null,
  created_at timestamptz not null default now(),
  unique (user_id, sku)
);

-- ============ AUDIT ============
create table if not exists audit_logs (
  id          uuid primary key default gen_random_uuid(),
  actor_id    uuid,
  actor_email text,
  action      text not null,
  target_type text not null,
  target_id   text,
  meta        jsonb,
  created_at  timestamptz not null default now()
);
create index if not exists idx_audit_created on audit_logs(created_at);

-- ============================================================
-- ROW LEVEL SECURITY (RLS)
-- Prinsip: API server memakai service-role dan tetap memvalidasi;
-- RLS melindungi akses langsung klien (anon/authenticated) via Supabase.
-- ============================================================

alter table users            enable row level security;
alter table game_saves       enable row level security;
alter table products         enable row level security;
alter table orders           enable row level security;
alter table payment_events   enable row level security;
alter table premium_wallets  enable row level security;
alter table premium_ledgers  enable row level security;
alter table entitlements     enable row level security;
alter table audit_logs       enable row level security;

-- Helper: id pemanggil sesuai Supabase Auth (sub = user id)
create or replace function auth_uid() returns uuid
language sql stable as $$ select nullif(auth.jwt() ->> 'sub','')::uuid $$;

create or replace function is_admin() returns boolean
language sql stable security definer as $$
  select exists (select 1 from users u where u.id = auth_uid() and u.role = 'admin')
$$;

-- users: tiap orang melihat/mengubah dirinya; admin melihat semua
drop policy if exists users_self on users;
create policy users_self on users
  for all using (id = auth_uid() or is_admin())
  with check (id = auth_uid());

-- game_saves: milik sendiri
drop policy if exists saves_owner on game_saves;
create policy saves_owner on game_saves
  for all using (user_id = auth_uid()) with check (user_id = auth_uid());

-- products: publik boleh BACA yang aktif; tulis hanya admin
drop policy if exists products_read on products;
create policy products_read on products
  for select using (active = true or is_admin());
drop policy if exists products_admin on products;
create policy products_admin on products
  for all using (is_admin()) with check (is_admin());

-- orders: pemilik baca; admin penuh. TIDAK ADA insert dari klien (order dibuat server)
drop policy if exists orders_owner_read on orders;
create policy orders_owner_read on orders
  for select using (user_id = auth_uid() or is_admin());

-- payment_events: hanya admin (audit gateway)
drop policy if exists events_admin on payment_events;
create policy events_admin on payment_events
  for select using (is_admin());

-- premium_wallets: pemilik hanya BACA; perubahan saldo lewat server
drop policy if exists wallet_owner_read on premium_wallets;
create policy wallet_owner_read on premium_wallets
  for select using (user_id = auth_uid() or is_admin());

-- premium_ledgers: pemilik baca riwayatnya; admin baca semua; tidak ada tulis klien
drop policy if exists ledger_owner_read on premium_ledgers;
create policy ledger_owner_read on premium_ledgers
  for select using (user_id = auth_uid() or is_admin());

-- entitlements: pemilik baca; pemberian lewat server (spend backend)
drop policy if exists ent_owner on entitlements;
create policy ent_owner on entitlements
  for select using (user_id = auth_uid() or is_admin());

-- audit_logs: hanya admin
drop policy if exists audit_admin on audit_logs;
create policy audit_admin on audit_logs
  for select using (is_admin());

-- ============================================================
-- Catatan:
-- 1) Saat memakai Next.js API + Prisma, koneksi memakai user database
--    (bypass RLS via service role / direct connection) — otorisasi tetap
--    divalidasi di setiap endpoint (requireUser/requireAdmin).
-- 2) Jangan pernah mengekspos SUPABASE_SERVICE_ROLE_KEY ke klien.
-- 3) Mapping auth: jika memakai Supabase Auth, sesuaikan auth_uid() dengan
--    relasi users.id = auth.users.id saat provisioning akun.
-- ============================================================
