# Worklog — KOTA KITA: Life Beyond

---
Task ID: 1
Agent: main (Z.ai)
Task: Inisialisasi lingkungan, keputusan arsitektur, skema database, seed

Work Log:
- Memuat skill fullstack-dev, menjalankan init script (Next.js 16 + TS + Prisma + shadcn/ui)
- Memasang phaser@3.90.0 (versi terpin)
- Verifikasi dokumentasi resmi Midtrans Snap via WebSearch: webhook signature SHA512(order_id+status_code+gross_amount+ServerKey), endpoint POST /snap/v1/transactions (Basic Auth ServerKey), status settlement/capture/deny/expire, idempotensi wajib
- Keputusan arsitektur:
  * TypeScript di seluruh proyek (lingkungan wajib Next+TS; tipe mencegah bug ID/status; Phaser punya tipe resmi)
  * SPA satu-route "/" dengan hash routing (#/play, #/store, #/admin) karena preview hanya mengekspos "/"; backend via /api/*
  * Prisma+SQLite runtime; migration SQL + RLS Supabase disediakan di docs untuk produksi
  * Aset pixel-art & audio digenerate programatik (Python PIL + synth) — legal, konsisten
  * Payment: adapter pattern; MockPay default (DEVELOPMENT ONLY) + adapter Midtrans Snap siap-konfigurasi

Stage Summary:
- Fondasi keputusan teknis terkunci; lanjut ke skema Prisma & seed

---
Task ID: 2-3
Agent: main (Z.ai)
Task: Generate aset pixel-art + audio programatik

Work Log:
- scripts/pixel.py: helper kanvas, palet kota Indonesia, outline, dither, blob organik
- scripts/gen_characters.py: 6 outfit pemain + 10 NPC (rambut/aksesori unik: hijab, sanggul+celemek, topi jerami, beret, vest kurir) frame 32x48 x 4 arah x 4 frame + kucing oren
- scripts/gen_tiles.py: tileset outdoor 16 tile + interior 8 tile (keramik, kayu, beton, dinding, mat)
- scripts/gen_props.py: 9 bangunan (warung awning, minimarket kaca, bengkel rol, kafe, kos 2 lantai+tangga, 3 rumah, gazebo), 17 props (pohon, lampu, bangku, air mancur, gerobak, motor), 11 furnitur (termasuk neon premium + minifan premium)
- scripts/gen_icons.py: 24 ikon item 24x24 + manifest.json untuk React
- scripts/gen_audio.py: musik lo-fi siang (27s loop) & malam, hujan 14s, 10 SFX
- Semua PNG diverifikasi visual via Read tool — kualitas outline/shading baik

Stage Summary:
- public/game/assets/*.png (43 file) + public/game/audio/*.wav (13 file) siap dipakai
- Aset 100% buatan sendiri, bebas hak cipta

---
Task ID: 4-6
Agent: main (Z.ai)
Task: Game core TS + sistem + scene Phaser

Work Log:
- core: types, constants (tuning terpusat), bus event, state singleton + subscribe React
- data: items (30 item + 5 katalog toko), npcs (10 + jadwal 24 jam), jobs (3 pekerjaan), quests (5 tutorial + 7 sampingan), dialogs (kontekstual per NPC: waktu/cuaca/stage), mapdata (peta 60x40 programatik + 9 bangunan + 5 interior + POI + walkability)
- systems: systems (waktu 1 hari=18 menit, kebutuhan decay, ekonomi+ledger, tidur, sewa mingguan, cuaca harian, achievement, ponsel), inventory (anti-duplikasi), social (chat/gift limit harian, stage 5 tingkat), quests (objektif + turn-in NPC + reward), jobs (shift 2 jam game, skill 5 level, kurir per-paket), furniture (validasi collision kamar kos), pathfind BFS NPC
- scenes: BootScene (preload+texture glow/rain/shadow+anims), BaseScene (gerak 8 arah+slide collision AABB kaki, kamera lerp+roundPixels, overlay siang-malam, partikel hujan, glow lampu, interaksi [E]), WorldScene (tilemap dari grid, air beranimasi, NPC BFS+jadwal, kurir delivery marker, bangunan/props depth-sort Y), InteriorScene (5 interior, fixture, NPC kerja, placement furnitur klik-tile, exit fade)
- start.ts: config Phaser 480x270 pixelArt FIT integer-friendly
- save.ts: 3 slot LocalStorage + sinkron server, migrasi skema merge-default, korup -> pesan

Stage Summary:
- Sistem game lengkap & saling terhubung; siap integrasi UI React

---
Task ID: 7
Agent: main (Z.ai)
Task: Backend API + payment + keamanan

Work Log:
- lib/auth: sesi cookie HMAC-SHA256 httpOnly 14 hari; lib/password: scrypt+salt; rate-limit in-memory
- lib/payment: provider.ts (interface+registry), mock.ts (MockPay DEVELOPMENT ONLY, HMAC signature), midtrans.ts (Snap sesuai docs resmi: SHA512(order_id+status_code+gross_amount+ServerKey), Basic Auth ServerKey, disabled tanpa env), process.ts (prosesor webhook: verifikasi signature, idempotensi PaymentEvent unique, validasi nominal vs DB, transisi status, kredit ATOMIK $transaction order+wallet+ledger, refund tanpa saldo negatif)
- API: auth (register/login/logout/me), products (publik aktif; all=1 admin), orders (POST harga dari DB + GET mine + [id] owner/admin), payment/webhook, payment/mock/checkout (simulasi gateway tersignature lewat jalur webhook asli), gems catalog/spend(nonce idempoten)/entitlements, saves (GET/POST/upsert, owner-only), admin (stats/products CRUD/orders/ledger/audit/refund)
- Audit log untuk register/login/product_*/gems_spend/refund
- api/route.ts -> health check

Stage Summary:
- Semua perubahan saldo premium melalui backend tervalidasi; frontend tidak pernah menentukan harga

---
Task ID: 8-12
Agent: main (Z.ai)
Task: SPA/store/admin UI, pengujian, verifikasi browser, dokumentasi

Work Log:
- UI: AppRouter hash-routing, AuthContext (refresh on nav), Landing, StoreApp (katalog/detail/gems), StoreAccount (login/register/profil/riwayat/detail/gateway mock), StaticPage (FAQ/Bantuan/S&K/Privasi), AdminApp (5 tab + refund), GamePage (menu/slot) + GameUI (HUD, inventory, ponsel, jurnal, peta, dialog, toko, wardrobe, tidur, 2 minigame, joystick sentuh)
- Perbaikan bug hasil verifikasi browser (agent-browser):
  * Phaser ESM: default export tidak ada di Turbopack -> namespace import + lazy scene import (SSR aman)
  * charTex double prefix "player_player_*" -> animasi npc/pemain benar
  * Sewa kos terpotong di hari 1 -> mulai hari ke-8
  * Scene restart memakai instance sama -> npcs map berisi sprite destroy (NPC hilang + throw) -> clear state transien di create()
  * Auth badge stale setelah pembayaran -> refresh on hashchange
  * ESLint set-state-in-effect / refs rules -> restructure (lazy init, ref via effect)
  * Saves API: validasi slot + 404
- Pengujian: tests/game.test.ts 19 pass; tests/api.test.ts 20 pass (idempotensi webhook, signature palsu 403, nominal mismatch 400, akses order 403, admin deny 403, refund ganda, nonce spend, save owner-only). Bun test 39/39 PASS. Rate limit bucket dibagikan via globalThis + endpoint devtools/reset-limits (dev-only) untuk stabil.
- Verifikasi browser end-to-end: landing, katalog (harga DB live), registrasi->order->gateway mock->fulfilled->saldo 100 Gems->riwayat; game: gerak+collision, NPC BFS keliling, masuk/keluar interior, tidur->hari 2+autosave->load slot, dialog Mas Tony (chat kontekstual), admin ditolak utk user biasa. Console bersih (0 missing asset/animation).
- Dokumentasi: README.md lengkap, .env.example, docs/supabase-migration.sql (PostgreSQL + RLS penuh), docs/production-checklist.md (deploy, Midtrans go-live, keamanan)

Stage Summary:
- Proyek sesuai Bagian L standar hasil akhir; siap demo; langkah pemilik: finalisasi harga, kredensial gateway, ubah S&K/privasi

---
Task ID: 13
Agent: main (Z.ai)
Task: Fix bug render saat mulai + tambah fitur pacaran

Work Log:
- Reproduksi bug via agent-browser: canvas Phaser tampil 480x270 (native) di tengah layar hitam; CSS `[&_canvas]:!w-auto !h-auto` di GameRunner menimpa inline style Scale.FIT (1025x577) dengan !important
- Fix render: hapus override CSS, ganti image-rendering pixelated, tambah scale.refresh() saat game ready
- Temuan & perbaikan tambahan selama verifikasi:
  * ensureFreeSpot() di BaseScene: safety valve pemain spawn terjebak tile solid (dicek via kotak collision asli, BFS ring radius 6, koreksi juga state.scene) — dipanggil di WorldScene & InteriorScene create
  * Interaksi NPC outdoor yang hilang: updateNpcInteract() di WorldScene — target dinamis npc_* mengikuti NPC terdekat (radius 60)
  * Konflik tile interior: fixture job/shop selalu menang jarak dari NPC yang sedang kerja (tile interaksi NPC lebih jauh). Fix: tile interaksi NPC = baris depan workspot (spot+2, fallback spot+1/spot), job warung digeser (5,3)->(6,3), job minimarket (5,6)->(6,6), counter tanpa interact dipisah, fixture "job" ilegal di kafe dihapus
  * Race npc_talk: event dipancarkan sebelum DialogPanel ter-mount -> panel selalu buka Mas Tony. Fix: variabel modul lastTalkNpc dibaca saat mount + turnIn saat init
  * Crash scale.refresh(): listener resize BaseScene menumpuk antar restart scene dan merujuk overlay destroyed (geom null) -> refresh selalu gagal -> canvas tak pernah ikut resize. Fix: off("resize") via events.once("shutdown") + guard overlay.active; handler bus interact_press/sfx/outfit_changed/furniture_mode ikut dilepas di shutdown
  * Resize tertinggal 1 frame: refresh eksplisit window resize dengan double-RAF (tunggu layout) di start.ts
- Fitur pacaran (romansa) lengkap:
  * Data: Relationship.dating/sinceDay/dateToday, GameStats.datesGone, NpcDef.romanceable (dinda, rian, maya, sinta), ROMANCE & DATE_OPTIONS (santai gratis/jajanan 15rb/kafe 35rb) di constants, pool dialog "pacar" 5 baris x 4 NPC
  * Logika social.ts: canConfess (skor>=85, mood>=40, eksklusif 1 pacar), confess (jadian: +4 skor, flag pacar_*, pesan ponsel, toast), goOnDate (1x/hari, biaya via spendMoney+ledger, gain, mood/energi/lapar, event hati skor>=95, pesan ponsel), breakUp (skor*0.4, mood -18, flag dibersihkan), chatWith memakai pool pacar + mood bonus
  * systems.ts: tickRomance di onNewDay & sleepUntilMorning — decay 2/hari tanpa interaksi, putus otomatis bila skor <30 (pesan ponsel + toast)
  * UI GameUI: badge "Pacar" pink + bar pink, tombol "Sampaikan Perasaan"/"Ajak Date" (submenu 3 opsi berlabel harga)/"Putus" (konfirmasi 2 langkah), hint romansa, badge hati di kontak ponsel
  * Pencapaian baru: first_love, date_five, true_love
- Pengujian: 11 test unit pacaran baru (nembak ditolak/diterima, eksklusivitas, date biaya+batas+ledger, putus, putus otomatis, decay, chat pacar, migrasi save) — total 50/50 PASS; lint bersih
- Verifikasi browser end-to-end: render penuh di 3 viewport (1600x900, 1280x720, portrait 900x506 letterbox), gerak pemain, nembak Dinda -> jadian (toast+pencapaian), date jajanan (Rp300.000->Rp285.000), badge Pacar di dialog+ponsel, pesan romantis, batas date harian ("Besok lagi, ya?"), dialog romantis muncul, console bersih

Stage Summary:
- Bug render utama (canvas kecil tak ter-scale) + 5 bug lanjutan (spawn terjebak, NPC interior tak bisa diajak bicara, race panel dialog, crash resize, resize telat 1 frame) diperbaiki dan diverifikasi browser
- Fitur pacaran lengkap end-to-end: nembak, jadian eksklusif, date berbayar, event hati, putus, decay/auto-putus, dialog & pencapaian

---
Task ID: 14
Agent: main (Z.ai)
Task: Kontrol layar lengkap untuk perangkat sentuh (mobile gamepad)

Work Log:
- Diagnosa kondisi awal: kontrol sentuh lama hanya joystick + tombol E minimalis, joystick rusak saat jari keluar lingkaran (tanpa pointer capture), tidak ada tombol lari, tombol HUD 36px terlalu kecil untuk jempol, panel kebutuhan bertabrakan dengan joystick
- Baru: src/game/core/joy.ts — joyVector() (deadzone halus 0.12, normalisasi, magnitudo proporsional) + knobOffset() (clamp visual knob); diuji unit 5 kasus
- Baru: src/hooks/use-touch.ts — useIsTouch() via useSyncExternalStore (SSR-safe, tanpa setState-in-effect) + useMediaQuery() generik; override ?touch=1 / ?touch=0 di URL untuk pengujian desktop
- start.ts: ekspor setRun(v) -> registry "touchRun"; BaseScene: lari = Shift ATAU touchRun; hint interaksi kini memancarkan label mentah (UI menyematkan prefix [E] desktop / pill di tombol E sentuh)
- GameUI TouchControls ditulis ulang: joystick 144px dengan setPointerCapture (gerak tetap terlacak walau jari keluar), knob visual mengikuti jari, multi-pointer guard (pointerId), LARI hold-to-run (oranye saat aktif), tombol E 80px dengan state aktif/redup + pill label aksi terdekat, reset aman setJoy/setRun saat unmount (panel terbuka/ganti scene)
- Layout mobile: bar kebutuhan pindah ke kiri-atas (di bawah jam) agar tak menabrak joystick; tombol HUD 44px saat sentuh; tombol layar penuh (⛶) baru; gamepad disembunyikan otomatis saat panel terbuka; hint desktop vs sentuh dipisah; saran putar lanskap (chip di area letterbox, auto-hilang saat rotate)
- Safe-area iPhone (env(safe-area-inset-*)) di HUD, gamepad, dan panel; viewport userScalable:false + viewportFit:cover; #game-root touch-none (anti pull-to-refresh)
- Bug ditemukan & diperbaiki saat verifikasi: (1) magnitudo joyVector salah skala (dinormalisasi dua kali) -> ditulis ulang benar; (2) NeedBars kehilangan posisi absolute saat refactor -> desktop kembali bottom-left
- Teks bantuan (Cara Bermain) & FAQ diperbarui (info kontrol sentuh + ?touch=1)
- Pengujian: bun test 55/55 PASS (5 test joystick baru); eslint bersih
- Verifikasi browser (agent-browser, device iPhone 14 + ?touch=1): gamepad tampil; drag joystick -> pemain bergerak sesuai arah (delta [-36,+78] untuk dorong kiri-bawah, kecepatan analog proporsional); LARI hold -> touchRun true/false; E aktif + pill "Bicara dengan Mas Tony" saat dekat NPC, tap E -> dialog terbuka; panel I buka/tutup -> gamepad hilang/kembali + pause benar; orientasi lanskap 844x390 rapi tanpa chip; desktop (?touch=0) tanpa gamepad, tombol HUD 36px, hint [E] normal; console bersih 0 error

Stage Summary:
- Perangkat sentuh kini punya kontrol layar lengkap: joystick analog 8 arah + LARI + E berlabel + HUD 44px + layar penuh; desktop tak berubah
- Seluruh fitur lama tetap terverifikasi (55/55 test, lint bersih, console bersih)
---
Task ID: 15
Agent: main (Z.ai)
Task: UI/UX kalem, fix login/daftar (iframe), lanskap auth, percakapan nyambung, rumah baru, sistem malam, semua cuaca & musim, +28 warga

Work Log:
- BUG LOGIN/DAFTAR (root cause): preview dijalankan dalam iframe lintas-situs; cookie SameSite=Lax tidak dikirim browser → register/login 201/200 tapi /api/auth/me selalu 401.
  * Server: sessionFromRequest kini menerima fallback header X-Session-Token; cookie di HTTPS memakai SameSite=None; Secure; Partitioned (x-forwarded-proto); login/register mengembalikan sessionToken di body.
  * Client: lib/client-session.ts (localStorage kk_session_token + authHeaders()); AuthContext simpan token; semua fetch terautentikasi (StoreApp/StoreAccount/AdminApp/GamePage/save.ts) memakai header.
  * Verifikasi browser: daftar akun baru → sukses; HAPUS semua cookie → reload → tetap login via header.
- UI/UX kalem & rapi: palet baru (sage #a9c2a2, sand #d9c4a0, rose #d9a0ac, ink #12141a, panel #191c23) mengganti neon cyan/violet/orange di Landing, StoreApp, StoreAccount, StaticPage, AdminApp, GamePage, GameUI; kelas komponen .kk-card/.kk-input/.kk-btn-primary/.kk-btn-soft (CSS murni — @layer components @apply dibuang Tailwind v4/Turbopack); badge promo di-store diperhalus.
- Auth responsif lanskap: AuthLayout (min-h-[100dvh], landscape:py-3, landscape:max-h-[94dvh] overflow-y-auto), autofill attribute, placeholder diperbaiki.
- +28 warga baru (Chelsea, Rico, Akbar, Virly, Zaki, Pijar, Andini, Rahma, Aulia, Agata, Andika, Coco, Defriska, Vanesa, Yami, Asta, Yuno, Riski, Alip, Amar, Abi, Ali, Eka, Deka, Celyin, Sandra, Cindy, Syifa):
  * gen_characters.py: 28 definisi unik + 2 gaya rambut baru (pony, afro); 38 spritesheet NPC final; inspeksi kontak-sheet 2 lembar OK.
  * npcs.ts: 28 NpcDef (kepribadian, jadwal per jam, selera hadiah, rumah); 6 romanceable baru (chelsea, zaki, defriska, vanesa, yuno).
  * dialogs.ts: pool utk 38 NPC; percakapan SEQUENSIAL antar hari via Relationship.chatTotal (topik ke-N = pool[N % len]) — cerita nyambung (Alip vs resep sambal Bu Sari, Akbar magang, dll); pool baru salju/badai/kabut utk 10 NPC utama; chatWith/social.ts memakai chatTotal.
- +6 rumah warga: gen_props.py building_house_small (64x64) + 6 varian (b_house_d..i); mapdata: penempatan tanpa konflik + jalur tapak + POI; rumah_d & rumah_f BISA dimasuki (2 interior baru: furnitur, fixture, exit); INTERIOR_WORKSPOT utk 15 NPC interior; BootScene interiors list diperbarui.
- Semua cuaca: cerah/berawan/hujan/badai/kabut/salju (Weather type); WEATHER_TABLE per musim + rollWeather; partikel salju (snow_tex runtime), kabut 2 lapis mengambang, badai = hujan deras + kilat tween + thunder.wav (gen_audio_extra.py); rain emitter param dinamis.
- Semua musim: semi/panas/gugur/dingin tiap 7 hari (seasonOf/dayOfSeason); SEASON_LOOK tint tanah+dedaunan pohon+udara; state.season + migrasi save lama (default semi); toast + pesan ponsel saat ganti musim; HUD menampilkan "❀ Musim Semi • Cerah" dst.
- Sistem malam: bintang (46 titik berkelip, hanya malam), cahaya jendela rumah (glow ADD per bangunan, alpha ikut jam), lampu jalan glow tetap; overlay malam lebih dalam; NPC pulang/istirahat sesuai jadwal (sudah ada) + dialog malam.
- HUD: jam + hari + musim + cuaca + lokasi; shift chip warna kalem; need bar warna di-soften.
- Debug hook ?debug=1 (setWeather/setSeason/setDay/setTime) untuk verifikasi browser; tidak aktif tanpa param.
- Test: +9 test (siklus musim, rollWeather per musim, onNewDay ganti musim, topik berurutan chatTotal, integritas 38 NPC [POI/workspot/dialog/save migrasi]) → 64/64 PASS; lint bersih; tsc bersih.
- Verifikasi browser end-to-end: landing/store kalem rapi; login lanskap 844x390 OK; daftar→login persist tanpa cookie; game render, 22 NPC outdoor jam 10:00 (warga baru aktif), masuk Rumah Villa D (Virly+Eka di spot), chat Virly 3x topik berurutan (skor 0→23), salju+musim dingin, badai+musim gugur (tanah oranye gugur), kabut, malam 21:00 (bintang+cahaya jendela+NPC), mobile touch (?touch=1) joystick+LARI+E OK; console bersih 0 error.

Stage Summary:
- Login/daftar KINI TERSIMPAN di lingkungan iframe (fallback token header) — root cause cookie lintas-situs ditemukan & diperbaiki.
- UI seluruh situs kalem-warna & konsisten; auth mendukung lanskap.
- Dunia Arunika kini: 38 warga hidup, 15 bangunan (6 rumah baru, 2 bisa dimasuki), 6 cuaca × 4 musim dengan tampilan mengikuti, malam berbintang bercahaya jendela, percakapan berkelanjutan antar hari.

---
Task ID: 16
Agent: main (Z.ai)
Task: UI/UX "game nyata" + tombol mobile overlay di atas canvas (gaya eFootball Mobile)

Work Log:
- Konsep: semua elemen HUD & gamepad kini dihitung dari RECT CANVAS PHASER (bukan sudut layar browser) via hook useCanvasRect() (ResizeObserver canvas + window resize/orientationchange/fullscreenchange, double-timeout setelah scale.refresh) — saat ada letterbox, tombol tetap menempel DI ATAS layar game, persis eFootball.
- Gamepad sentuh gaya eFootball: joystick kaca (ring gradient + knob radial + tick arah + ring sage saat aktif) kiri-bawah; tombol LARI (arc kiri-atas) + tombol E besar (kanan-bawah, menyala is-live + label aksi melayang di atasnya); semua .kk-joy-base/.kk-pad-btn (CSS murni); ukuran lanskap besar (148/86/58), portrait ramping (100/60/46) + safe-area env() tetap berlaku.
- Gerbang lanskap ala eFootball: portrait + perangkat sentuh -> layar penuh "Putar HP kamu" (mock HP animasi rotate, tombol "Tetap main di mode portrait"); game di-pause selama gerbang.
- HUD gaya game: kartu status kaca (jam besar + hari + chip musim/cuaca + lokasi uppercase), pil dompet dengan ikon koin SVG, tombol HUD bulat ikon SVG (inventory/jurnal/peta/ponsel/fullscreen/menu) dengan badge tombol keyboard di desktop, bar kebutuhan micro-label + bar glow; toast & hint [E] di-restyle; semua di-anchor ke rect canvas.
- Portrait: bar kebutuhan diganti baris "kebutuhan terendah" (LowestNeed) di kartu status, tombol HUD grid 3x2 ukuran kecil, pil Gems disembunyikan — tak ada lagi tumpang-tindih dengan gamepad.
- Panel gaya jendela game: PanelShell baru (strip aksen sage->sand, judul uppercase, tombol close ikon), animasi kk-pop, scrollbar kk-scroll; DialogPanel kini menampilkan POTRET PIXEL NPC (crop frame hadap-depan dari spritesheet, bg-size 400%) + papan nama + bar relasi; ResultView tanpa emoji.
- Title screen gaya game: aurora kalem beranimasi, skyline pixel Arunika (bangunan asli game) di bawah, logo besar + gradasi sand->sage, MenuButton gaya game (aksen kiri + chevron), footer versi; GameRunner diberi ambience radial + vignette kk-vignette supaya letterbox terasa bagian dari game.
- Temuan verifikasi: agent-browser keydown tidak membawa keyCode yang cocok utk Phaser (React yang match e.key tetap bekerja) -> pengujian gerak memakai dispatchEvent KeyboardEvent via eval (isDown terbukti true, pemain bergerak; artefak NaN kamera akibat teleport test dipulihkan via centerOn+startFollow — bukan bug game).
- Verifikasi browser end-to-end: title screen rapi; desktop murni tanpa gamepad; mobile lanskap 844x390 ?touch=1: gamepad menempel di canvas, drag joystick -> pemain geser kiri 79px (kecepatan analog), LARI hold -> touchRun true/false, tap E -> dialog terbuka, tutup panel -> gamepad kembali; portrait 390x844: gerbang lanskap tampil, skip -> layout portrait ramping tanpa overlap; dialog NPC + potret + obrolan (skor 0->7) OK; console bersih 0 error.
- bunx tsc bersih; eslint bersih; bun test 64/64 PASS.

Stage Summary:
- Seluruh UI game kini bernuansa "game nyata": HUD & kontrol overlay di atas canvas (eFootball-style), gerbang lanskap, panel jendela game berpotret NPC, title screen dengan skyline Arunika. Palet tetap kalem (sage/sand/ink).
